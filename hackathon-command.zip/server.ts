import 'dotenv/config';
import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { parseMessagePackText } from './src/core/parser';
import { summarizeTokens } from './src/core/validation';
import { runFullPlanningPipeline, runIncrementalUpdatePipeline } from './src/server/orchestrator';
import { createEmptyState, loadState, readSamplePackFile, resetState, saveState } from './src/server/store';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '5mb' }));
  app.use(express.text({ limit: '5mb' }));

  // Health & state inspection
  app.get('/api/state', (_req, res) => {
    const state = loadState();
    res.json(state);
  });

  // Load sample .txt file directly from disk without hardcoding facts in logic
  app.post('/api/sample/load', (_req, res) => {
    try {
      const rawText = readSamplePackFile();
      const messages = parseMessagePackText(rawText, {
        startingIndex: 1,
        batchId: `sample_${Date.now()}`,
      });
      const fresh = createEmptyState();
      fresh.messages = messages;
      saveState(fresh);
      res.json(fresh);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to load sample message pack',
      });
    }
  });

  // Ingest raw .txt message pack (uploaded file content or pasted text)
  app.post('/api/messages/ingest', (req, res) => {
    try {
      const rawText =
        typeof req.body === 'string' ? req.body : String(req.body?.rawText ?? '');
      const replaceExisting = Boolean(req.body?.replaceExisting ?? true);

      if (!rawText.trim()) {
        return res.status(400).json({ error: 'Message pack text cannot be empty.' });
      }

      const current = replaceExisting ? createEmptyState() : loadState();
      const startingIndex = replaceExisting ? 1 : current.messages.length + 1;
      const parsed = parseMessagePackText(rawText, {
        startingIndex,
        batchId: `ingest_${Date.now()}`,
      });

      const nextState = {
        ...current,
        messages: replaceExisting ? parsed : [...current.messages, ...parsed],
        status: current.plan ? current.status : ('idle' as const),
        errorMessage: null,
      };
      saveState(nextState);
      res.json(nextState);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to ingest message pack',
      });
    }
  });

  // Reset workspace
  app.post('/api/reset', (_req, res) => {
    const empty = resetState();
    res.json(empty);
  });

  // Run full multi-agent planning pipeline with SSE streaming
  app.post('/api/plan/run', async (_req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const sendEvent = (data: unknown) => {
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    try {
      const state = loadState();
      if (state.messages.length === 0) {
        sendEvent({
          type: 'error',
          error: 'No messages loaded. Please upload a .txt message pack or load the sample pack first.',
        });
        res.end();
        return;
      }

      await runFullPlanningPipeline(state, (event) => {
        sendEvent(event);
      });
    } catch (err) {
      sendEvent({
        type: 'error',
        error: err instanceof Error ? err.message : 'Planning pipeline failed',
      });
    } finally {
      res.end();
    }
  });

  // Incremental update with <= 5 model calls and SSE streaming
  app.post('/api/plan/update', async (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();

    const sendEvent = (data: unknown) => {
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    try {
      const rawText =
        typeof req.body === 'string' ? req.body : String(req.body?.rawText ?? '');
      if (!rawText.trim()) {
        sendEvent({ type: 'error', error: 'Update message text cannot be empty.' });
        res.end();
        return;
      }

      const state = loadState();
      await runIncrementalUpdatePipeline(state, rawText, (event) => {
        sendEvent(event);
      });
    } catch (err) {
      sendEvent({
        type: 'error',
        error: err instanceof Error ? err.message : 'Incremental update failed',
      });
    } finally {
      res.end();
    }
  });

  // Export plain-text execution trace
  app.get('/api/trace/export', (_req, res) => {
    const state = loadState();
    const summary = summarizeTokens(state.executionTrace);
    const lines: string[] = [
      'HACKATHON MULTI-AGENT EXECUTION TRACE',
      `Exported: ${new Date().toISOString()}`,
      `Total Model Calls: ${summary.totalCalls}`,
      `Total Input Tokens: ${summary.inputTokens}`,
      `Total Output Tokens: ${summary.outputTokens}`,
      `Total Tokens: ${summary.totalTokens}`,
      '',
    ];

    for (const entry of state.executionTrace) {
      lines.push(`====================================================================`);
      lines.push(`CALL #${entry.callNumber} | AREA: ${entry.areaTag} | MODEL: ${entry.model}`);
      lines.push(`PURPOSE: ${entry.purpose}`);
      lines.push(`TIMESTAMP: ${entry.timestamp} | DURATION: ${entry.durationMs}ms | RETRY: ${entry.isRetry}`);
      lines.push(
        `TOKENS: ${
          entry.tokenAvailability === 'reported'
            ? `input=${entry.inputTokens}, output=${entry.outputTokens}, total=${entry.totalTokens}`
            : 'unavailable'
        }`
      );
      lines.push(`--- EXACT INPUT ---\n${entry.input}`);
      lines.push(`--- COMPLETE OUTPUT ---\n${entry.output}\n`);
    }

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="hackathon-execution-trace.txt"');
    res.send(lines.join('\n'));
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Hackathon Command server running on http://localhost:${PORT}`);
  });
}

startServer();
