import { useRef, type ChangeEvent } from 'react';
import { FileText, FileUp, Play, RotateCcw, Sparkles } from 'lucide-react';
import type { WorkspaceState } from '../core/types';
import type { NavTab } from './TopBar';

interface WorkspaceToolbarProps {
  state: WorkspaceState;
  isBusy: boolean;
  onUploadFile: (rawText: string) => void;
  onOpenPasteModal: () => void;
  onLoadSample: () => void;
  onRunPlanner: () => void;
  onOpenUpdateModal: () => void;
  onReset: () => void;
  onSelectTab: (tab: NavTab) => void;
}

export function WorkspaceToolbar({
  state,
  isBusy,
  onUploadFile,
  onOpenPasteModal,
  onLoadSample,
  onRunPlanner,
  onOpenUpdateModal,
  onReset,
}: WorkspaceToolbarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    onUploadFile(text);
    e.target.value = '';
  };

  const params = state.plan?.parameters;
  const location = params?.location ?? 'Islamabad, Pakistan';
  const participants = params?.participants ?? 150;
  const teams = params?.teams ?? 50;
  const hours = params ? (params.durationMinutes / 60).toFixed(params.durationMinutes % 60 === 0 ? 0 : 1) : '4';

  return (
    <div className="border-b border-slate-200 bg-slate-50/80">
      <div className="mx-auto flex max-w-[1380px] flex-wrap items-center justify-between gap-4 px-6 py-3">
        {/* Clean unboxed baseline metadata */}
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
          <span className="font-semibold text-slate-900">Physical Hackathon</span>
          <span aria-hidden="true">·</span>
          <span>{location}</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">{participants} Students</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">{teams} Teams</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">{hours} Hours</span>
          {state.messages.length > 0 && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-slate-700 tabular-nums">
                {state.messages.length} Messages Loaded
              </span>
            </>
          )}
        </div>

        {/* Interactive Workspace Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,text/plain"
            onChange={handleFileChange}
            className="hidden"
            aria-label="Upload message pack text file"
          />

          <button
            type="button"
            disabled={isBusy}
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileUp className="h-3.5 w-3.5 text-slate-500" />
            <span>Upload .txt</span>
          </button>

          <button
            type="button"
            disabled={isBusy}
            onClick={onOpenPasteModal}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileText className="h-3.5 w-3.5 text-slate-500" />
            <span>Paste Messages</span>
          </button>

          <button
            type="button"
            disabled={isBusy}
            onClick={onLoadSample}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5 text-blue-600" />
            <span>Load Sample Pack</span>
          </button>

          {state.messages.length > 0 && (
            <button
              type="button"
              disabled={isBusy}
              onClick={onRunPlanner}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Play className="h-3.5 w-3.5" />
              <span>{state.plan ? 'Re-Run Full Plan' : 'Run Planner'}</span>
            </button>
          )}

          {state.plan && (
            <button
              type="button"
              disabled={isBusy}
              onClick={onOpenUpdateModal}
              className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800 transition-colors hover:bg-emerald-100 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Add Update Message</span>
            </button>
          )}

          {(state.messages.length > 0 || state.plan) && (
            <button
              type="button"
              disabled={isBusy}
              onClick={onReset}
              aria-label="Reset workspace"
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-600 transition-colors hover:border-red-200 hover:bg-red-50 hover:text-red-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
