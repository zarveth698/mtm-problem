import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Clock, Loader2, XCircle } from 'lucide-react';
import type { ExecutionTraceEntry, TraceAreaTag } from '../core/types';

export interface PipelineStepState {
  stepId: string;
  label: string;
  areaTag: TraceAreaTag;
  status: 'pending' | 'running' | 'completed' | 'failed';
  detail: string;
}

interface PipelineRunnerProps {
  mode: 'initial' | 'incremental_update';
  steps: PipelineStepState[];
  liveTraces: ExecutionTraceEntry[];
  startedAt: number;
}

export function PipelineRunner({ mode, steps, liveTraces, startedAt }: PipelineRunnerProps) {
  const [elapsedMs, setElapsedMs] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => {
      setElapsedMs(Date.now() - startedAt);
    }, 100);
    return () => window.clearInterval(id);
  }, [startedAt]);

  const totalLiveTokens = liveTraces.reduce((acc, t) => acc + (t.totalTokens ?? 0), 0);

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -6 }}
      transition={{ duration: 0.12, ease: [0.16, 1, 0.3, 1] }}
      aria-label="Multi-Agent Pipeline Execution"
      className="mb-6 rounded-xl border border-blue-200 bg-white p-5 shadow-sm"
    >
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h2 className="font-display text-base font-semibold text-slate-900">
            {mode === 'initial'
              ? 'Multi-Agent Planning Pipeline Running'
              : 'Incremental Update Pipeline Running'}
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            {mode === 'initial'
              ? 'Coordinating reading, conflict resolution, 5 specialized planning agents, and deterministic validation.'
              : 'Analyzing new message impact under the 5-call / 60-second competition budget.'}
          </p>
        </div>

        <div className="flex items-center gap-5 font-mono text-xs text-slate-700 tabular-nums">
          <div className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-blue-600" />
            <span>{(elapsedMs / 1000).toFixed(1)}s</span>
          </div>
          <div>
            Calls: <span className="font-semibold text-slate-900">{liveTraces.length}</span>
            {mode === 'incremental_update' && <span className="text-slate-400"> / 5 max</span>}
          </div>
          <div>
            Tokens: <span className="font-semibold text-slate-900">{totalLiveTokens.toLocaleString()}</span>
          </div>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step, idx) => {
          const isRunning = step.status === 'running';
          const isDone = step.status === 'completed';
          const isFailed = step.status === 'failed';

          return (
            <motion.div
              key={step.stepId}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.03, duration: 0.18 }}
              className={`rounded-lg border p-3.5 transition-colors ${
                isRunning
                  ? 'border-blue-300 bg-blue-50/50'
                  : isDone
                  ? 'border-emerald-200 bg-emerald-50/40'
                  : isFailed
                  ? 'border-red-200 bg-red-50/50'
                  : 'border-slate-200 bg-slate-50/60'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-900 truncate">{step.label}</span>
                {isRunning && <Loader2 className="h-4 w-4 shrink-0 animate-spin text-blue-600" />}
                {isDone && <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />}
                {isFailed && <XCircle className="h-4 w-4 shrink-0 text-red-600" />}
                {step.status === 'pending' && (
                  <span className="h-2 w-2 shrink-0 rounded-full bg-slate-300" />
                )}
              </div>
              <p className="mt-1.5 text-xs text-slate-600 line-clamp-2">{step.detail}</p>
              <div className="mt-2 font-mono text-[11px] text-slate-400">
                area: {step.areaTag}
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.section>
  );
}
