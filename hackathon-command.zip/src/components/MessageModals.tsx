import { useState, type ChangeEvent, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileUp, X } from 'lucide-react';

interface PastePackModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (rawText: string, replaceExisting: boolean) => void;
}

export function PastePackModal({ isOpen, onClose, onSubmit }: PastePackModalProps) {
  const [text, setText] = useState('');
  const [replaceExisting, setReplaceExisting] = useState(true);
  const [error, setError] = useState('');

  const handleFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setText(await file.text());
    setError('');
    e.target.value = '';
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      setError('Please paste or upload at least one message before continuing.');
      return;
    }
    onSubmit(text, replaceExisting);
    setText('');
    setError('');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="paste-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-xl"
          >
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h2 id="paste-modal-title" className="font-display text-lg font-bold text-slate-900">
                  Ingest Raw Message Pack
                </h2>
                <p className="mt-1 text-xs text-slate-500">
                  Paste raw English or Roman Urdu emails, WhatsApp threads, or notices—or load a .txt file directly. No manual tagging required.
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close modal"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label htmlFor="raw-pack-textarea" className="text-xs font-semibold text-slate-700">
                    Raw Message Text
                  </label>
                  <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer">
                    <FileUp className="h-3.5 w-3.5" />
                    <span>Load .txt File</span>
                    <input type="file" accept=".txt,text/plain" onChange={handleFile} className="hidden" />
                  </label>
                </div>
                <textarea
                  id="raw-pack-textarea"
                  rows={10}
                  value={text}
                  onChange={(e) => {
                    setText(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="Paste messages separated by --- or numbered headers ([MSG 1], WhatsApp timestamps, Email headers)..."
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:bg-white focus:outline-none"
                />
                {error && <p className="mt-1.5 text-xs font-medium text-red-600">{error}</p>}
              </div>

              <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={replaceExisting}
                  onChange={(e) => setReplaceExisting(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span>Replace existing messages and start a fresh planning pack</span>
              </label>

              <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
                >
                  Ingest Messages
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

interface UpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (rawText: string) => void;
}

export function UpdateModal({ isOpen, onClose, onSubmit }: UpdateModalProps) {
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  const handleFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setText(await file.text());
    setError('');
    e.target.value = '';
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      setError('Please enter or upload an update message.');
      return;
    }
    onSubmit(text);
    setText('');
    setError('');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="update-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-xs"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-xl rounded-xl border border-slate-200 bg-white p-6 shadow-xl"
          >
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h2 id="update-modal-title" className="font-display text-lg font-bold text-slate-900">
                  Submit Incremental Update
                </h2>
                <p className="mt-1 text-xs text-slate-500">
                  Processes new English or Roman Urdu messages against the existing plan, preserves unaffected areas, and runs within 5 model calls and 60 seconds.
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close update modal"
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label htmlFor="update-message-input" className="text-xs font-semibold text-slate-700">
                    New Message or Notice
                  </label>
                  <label className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer">
                    <FileUp className="h-3.5 w-3.5" />
                    <span>Upload .txt</span>
                    <input type="file" accept=".txt,text/plain" onChange={handleFile} className="hidden" />
                  </label>
                </div>
                <textarea
                  id="update-message-input"
                  rows={6}
                  value={text}
                  onChange={(e) => {
                    setText(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="Example: Urgent update from Finance: Food budget ab maximum PKR 65,000 hai aur 30 vegetarian boxes zaroori hain."
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:bg-white focus:outline-none"
                />
                {error && <p className="mt-1.5 text-xs font-medium text-red-600">{error}</p>}
              </div>

              <div className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-600">
                Constraints enforced: Max 5 model calls · Max 60s · Automatic conflict arbitration & full plan revalidation.
              </div>

              <div className="flex items-center justify-end gap-3 border-t border-slate-100 pt-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
                >
                  Apply Incremental Update
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
