import { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { AlertCircle, CheckCircle2, HelpCircle, Search, XCircle } from 'lucide-react';
import type { MessageDispositionStatus, WorkspaceState } from '../core/types';

interface MessagesViewProps {
  state: WorkspaceState;
}

type FilterMode = 'all' | 'accepted' | 'rejected' | 'superseded' | 'irrelevant';

const STATUS_META: Record<
  MessageDispositionStatus,
  { label: string; colorClass: string; icon: typeof CheckCircle2 }
> = {
  accepted: { label: 'Accepted', colorClass: 'text-emerald-700', icon: CheckCircle2 },
  partially_accepted: { label: 'Partially Accepted', colorClass: 'text-blue-700', icon: CheckCircle2 },
  rejected: { label: 'Rejected', colorClass: 'text-red-700', icon: XCircle },
  outdated: { label: 'Outdated', colorClass: 'text-amber-700', icon: AlertCircle },
  superseded: { label: 'Superseded', colorClass: 'text-amber-700', icon: AlertCircle },
  irrelevant: { label: 'Irrelevant', colorClass: 'text-slate-500', icon: HelpCircle },
};

export function MessagesView({ state }: MessagesViewProps) {
  const [filter, setFilter] = useState<FilterMode>('all');
  const [query, setQuery] = useState('');

  const dispositionMap = useMemo(
    () => new Map(state.dispositions.map((d) => [d.messageId, d])),
    [state.dispositions]
  );

  const constraintsByMsg = useMemo(() => {
    const map = new Map<string, typeof state.constraints>();
    for (const c of state.constraints) {
      const list = map.get(c.sourceMessageId) ?? [];
      list.push(c);
      map.set(c.sourceMessageId, list);
    }
    return map;
  }, [state.constraints]);

  const filteredMessages = useMemo(() => {
    const q = query.trim().toLowerCase();
    return state.messages.filter((msg) => {
      const disp = dispositionMap.get(msg.id);
      if (filter !== 'all' && disp) {
        if (filter === 'accepted' && disp.status !== 'accepted' && disp.status !== 'partially_accepted') {
          return false;
        }
        if (filter === 'rejected' && disp.status !== 'rejected') {
          return false;
        }
        if (filter === 'superseded' && disp.status !== 'outdated' && disp.status !== 'superseded') {
          return false;
        }
        if (filter === 'irrelevant' && disp.status !== 'irrelevant') {
          return false;
        }
      }
      if (!q) return true;
      return (
        msg.id.toLowerCase().includes(q) ||
        msg.rawText.toLowerCase().includes(q) ||
        (disp?.reason.toLowerCase().includes(q) ?? false) ||
        (disp?.senderOrSource.toLowerCase().includes(q) ?? false)
      );
    });
  }, [state.messages, dispositionMap, filter, query]);

  if (state.messages.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
        <h2 className="font-display text-lg font-bold text-slate-900">No Messages Loaded</h2>
        <p className="mt-1 text-sm text-slate-600">
          Upload a .txt pack, paste raw messages, or load the sample pack from the toolbar above.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="inline-flex flex-wrap items-center gap-1 rounded-xl border border-slate-200 bg-slate-100 p-1">
          {(
            [
              ['all', `All (${state.messages.length})`],
              ['accepted', 'Accepted'],
              ['rejected', 'Rejected'],
              ['superseded', 'Outdated / Superseded'],
              ['irrelevant', 'Irrelevant'],
            ] as Array<[FilterMode, string]>
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setFilter(id)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                filter === id ? 'bg-white text-slate-950 shadow-xs' : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter by message ID, text, or reason..."
            aria-label="Filter messages"
            className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-8 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Message Cards */}
      <div className="space-y-4">
        {filteredMessages.map((msg) => {
          const disp = dispositionMap.get(msg.id);
          const msgConstraints = constraintsByMsg.get(msg.id) ?? [];
          const statusMeta = disp ? STATUS_META[disp.status] : null;
          const StatusIcon = statusMeta?.icon ?? HelpCircle;

          return (
            <motion.article
              key={msg.id}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.15 }}
              className="rounded-xl border border-slate-200 bg-white p-5"
            >
              {/* Unboxed Metadata Header */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <span className="font-mono font-bold text-slate-950">{msg.id}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-medium text-slate-800">
                    {disp?.senderOrSource || msg.sourceLabel || 'Raw Source'}
                  </span>
                  {disp && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>
                        {disp.language === 'roman_urdu'
                          ? 'Roman Urdu'
                          : disp.language === 'mixed'
                          ? 'English + Roman Urdu'
                          : 'English'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{disp.relevance === 'relevant' ? 'Relevant' : 'Irrelevant'}</span>
                    </>
                  )}
                </div>

                {statusMeta && (
                  <div className={`inline-flex items-center gap-1.5 text-xs font-semibold ${statusMeta.colorClass}`}>
                    <StatusIcon className="h-4 w-4" />
                    <span>{statusMeta.label}</span>
                  </div>
                )}
              </div>

              {/* Raw Original Message Text (Traceability) */}
              <div className="mt-3 rounded-lg bg-slate-50 p-3.5 font-mono text-xs leading-relaxed text-slate-800 whitespace-pre-wrap">
                {msg.rawText}
              </div>

              {/* Resolution / Rejection Reasoning */}
              {disp && (
                <div className="mt-3 text-xs text-slate-700">
                  <span className="font-semibold text-slate-900">Arbitration Decision: </span>
                  {disp.reason}
                  {disp.supersededByMessageId && (
                    <span className="ml-2 font-mono text-amber-700">
                      (Superseded by {disp.supersededByMessageId})
                    </span>
                  )}
                </div>
              )}

              {/* Extracted Constraints Table */}
              {msgConstraints.length > 0 && (
                <div className="mt-4 border-t border-slate-100 pt-3">
                  <div className="text-[11px] font-semibold text-slate-500">
                    Extracted Constraints ({msgConstraints.length})
                  </div>
                  <div className="mt-2 divide-y divide-slate-100">
                    {msgConstraints.map((c) => (
                      <div key={c.id} className="flex flex-wrap items-start justify-between gap-3 py-2 text-xs">
                        <div>
                          <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                            <span className="font-mono font-semibold text-slate-900">{c.id}</span>
                            <span aria-hidden="true">·</span>
                            <span>{c.isHard ? 'Hard' : 'Soft'}</span>
                            <span aria-hidden="true">·</span>
                            <span>{c.category}</span>
                            <span aria-hidden="true">·</span>
                            <span>Areas: {c.affectedAreas.join(', ')}</span>
                          </div>
                          <div className="mt-0.5 text-slate-800">{c.summary}</div>
                          {c.resolutionReason && (
                            <div className="mt-0.5 text-[11px] text-slate-500">
                              Reason: {c.resolutionReason}
                            </div>
                          )}
                        </div>
                        <span
                          className={`font-semibold text-[11px] ${
                            c.status === 'active'
                              ? 'text-emerald-700'
                              : c.status === 'rejected' || c.status === 'impossible'
                              ? 'text-red-700'
                              : 'text-amber-700'
                          }`}
                        >
                          {c.status.toUpperCase()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.article>
          );
        })}
      </div>
    </div>
  );
}
