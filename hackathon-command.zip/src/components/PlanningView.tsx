import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Building2,
  CalendarClock,
  CheckCircle2,
  Gavel,
  ShieldCheck,
  Utensils,
  Wallet,
} from 'lucide-react';
import type { HackathonPlan, PlanningArea, ScheduleBlock } from '../core/types';

interface PlanningViewProps {
  plan: HackathonPlan | null;
  activeArea: PlanningArea;
  onSelectArea: (area: PlanningArea) => void;
  onRunSamplePrompt: () => void;
}

const AREA_TABS: Array<{ id: PlanningArea; label: string; icon: typeof Building2 }> = [
  { id: 'venue', label: 'Venue', icon: Building2 },
  { id: 'schedule', label: 'Schedule', icon: CalendarClock },
  { id: 'food', label: 'Food', icon: Utensils },
  { id: 'judging', label: 'Judging', icon: Gavel },
  { id: 'budget', label: 'Budget', icon: Wallet },
];

const PHASE_COLORS: Record<ScheduleBlock['phase'], string> = {
  registration: 'bg-slate-700 text-white',
  opening: 'bg-blue-600 text-white',
  hacking: 'bg-emerald-600 text-white',
  food: 'bg-amber-500 text-slate-950',
  judging: 'bg-indigo-600 text-white',
  closing: 'bg-slate-900 text-white',
  buffer: 'bg-slate-300 text-slate-900',
};

export function PlanningView({
  plan,
  activeArea,
  onSelectArea,
  onRunSamplePrompt,
}: PlanningViewProps) {
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null);

  if (!plan) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
        <h2 className="font-display text-lg font-bold text-slate-900">No Plan Generated Yet</h2>
        <p className="mt-1 text-sm text-slate-600">
          Load a message pack and run the multi-agent planner to inspect Venue, Schedule, Food, Judging, and Budget decisions.
        </p>
        <button
          type="button"
          onClick={onRunSamplePrompt}
          className="mt-5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 cursor-pointer"
        >
          Go to Overview
        </button>
      </div>
    );
  }

  const activeBlock =
    plan.schedule.blocks.find((b) => b.id === selectedBlockId) ?? plan.schedule.blocks[0];

  return (
    <div className="space-y-6">
      {/* Segmented Area Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div
          role="tablist"
          aria-label="Planning Areas"
          className="inline-flex flex-wrap items-center gap-1 rounded-xl border border-slate-200 bg-slate-100 p-1"
        >
          {AREA_TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeArea === tab.id;
            return (
              <button
                key={tab.id}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => onSelectArea(tab.id)}
                className={`relative inline-flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <div className="text-xs text-slate-500 font-mono tabular-nums">
          Plan v{plan.version} · {plan.parameters.participants} Students · {plan.parameters.teams} Teams
        </div>
      </div>

      {/* Animated Tab Body */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeArea}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
        >
          {activeArea === 'venue' && (
            <div className="space-y-6">
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-5">
                  <div>
                    <div className="text-xs text-slate-500">
                      Selected Venue · {plan.venue.addressOrSector}
                    </div>
                    <h2 className="mt-1 font-display text-2xl font-bold text-slate-950">
                      {plan.venue.venueName}
                    </h2>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-500">Rental Cost</div>
                    <div className="font-mono text-xl font-bold text-slate-950 tabular-nums">
                      {plan.venue.estimatedCost.toLocaleString()} {plan.budget.currency}
                    </div>
                  </div>
                </div>

                <div className="mt-5 grid grid-cols-1 gap-6 md:grid-cols-3">
                  <div>
                    <div className="text-xs font-medium text-slate-500">Capacity vs Required</div>
                    <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums">
                      {plan.venue.capacity} / {plan.parameters.participants} seats
                    </div>
                    <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-full bg-emerald-600 transition-all"
                        style={{
                          width: `${Math.min(100, (plan.parameters.participants / Math.max(1, plan.venue.capacity)) * 100)}%`,
                        }}
                      />
                    </div>
                    <div className="mt-1 text-xs text-slate-500">
                      Headroom: {plan.venue.capacity - plan.parameters.participants} buffer seats
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-medium text-slate-500">Seating Arrangement</div>
                    <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums">
                      {plan.venue.teamTables} Tables ({plan.venue.seatsPerTable}/table)
                    </div>
                    <p className="mt-1 text-xs text-slate-600">{plan.venue.seatingArrangement}</p>
                  </div>

                  <div>
                    <div className="text-xs font-medium text-slate-500">Accessibility</div>
                    <p className="mt-1 text-xs leading-relaxed text-slate-700">
                      {plan.venue.accessibilityNotes}
                    </p>
                  </div>
                </div>

                {/* Visual 50-Team Seating Grid */}
                <div className="mt-6 border-t border-slate-100 pt-5">
                  <div className="mb-3 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">
                      Team Table Allocation Grid ({plan.parameters.teams} Active Team Pods + Buffer)
                    </span>
                    <span className="font-mono text-slate-500 tabular-nums">
                      {plan.venue.teamTables} tables total
                    </span>
                  </div>
                  <div className="grid grid-cols-10 gap-1.5 sm:grid-cols-15 md:grid-cols-20">
                    {Array.from({ length: Math.min(plan.venue.teamTables, 60) }).map((_, i) => {
                      const isTeam = i < plan.parameters.teams;
                      return (
                        <div
                          key={i}
                          title={isTeam ? `Team ${i + 1} (${plan.parameters.teamSize} students)` : `Buffer Table ${i + 1}`}
                          className={`flex h-7 items-center justify-center rounded border font-mono text-[10px] tabular-nums ${
                            isTeam
                              ? 'border-blue-200 bg-blue-50 text-blue-800 font-semibold'
                              : 'border-slate-200 bg-slate-50 text-slate-400'
                          }`}
                        >
                          {isTeam ? `T${i + 1}` : 'BUF'}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-1 gap-6 border-t border-slate-100 pt-5 md:grid-cols-2">
                  <div>
                    <h3 className="text-xs font-semibold text-slate-900">Facilities & Equipment</h3>
                    <ul className="mt-2 space-y-1.5">
                      {plan.venue.facilities.map((fac, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-slate-700">
                          <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-600" />
                          <span>{fac}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-xs font-semibold text-slate-900">Restrictions Respected</h3>
                    <ul className="mt-2 space-y-1.5">
                      {plan.venue.restrictionsRespected.map((res, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-slate-700">
                          <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-blue-600" />
                          <span>{res}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-5 border-t border-slate-100 pt-4 text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">Agent Rationale: </span>
                  {plan.venue.rationale}
                  <span className="ml-2 font-mono text-slate-400">
                    [Sources: {plan.venue.sourceMessageIds.join(', ') || 'Baseline'}]
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeArea === 'schedule' && (
            <div className="space-y-6">
              {/* Interactive 240-Minute Timeline Bar */}
              <div className="rounded-xl border border-slate-200 bg-white p-6">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 className="font-display text-xl font-bold text-slate-950">
                      Interactive {plan.schedule.totalDurationMinutes}-Minute Timeline
                    </h2>
                    <p className="text-xs text-slate-500">
                      {plan.schedule.startTime} – {plan.schedule.endTime} · Click any timeline segment to inspect dependencies
                    </p>
                  </div>
                  <div className="font-mono text-xs text-slate-600 tabular-nums">
                    {plan.schedule.blocks.length} contiguous phases
                  </div>
                </div>

                <div className="mt-5 flex h-12 w-full overflow-hidden rounded-lg border border-slate-200 bg-slate-100">
                  {plan.schedule.blocks.map((block) => {
                    const span = Math.max(1, block.endMinute - block.startMinute);
                    const widthPct = (span / Math.max(1, plan.schedule.totalDurationMinutes)) * 100;
                    const isSelected = activeBlock?.id === block.id;
                    return (
                      <button
                        key={block.id}
                        type="button"
                        onClick={() => setSelectedBlockId(block.id)}
                        style={{ width: `${widthPct}%` }}
                        title={`${block.title} (${block.clockTimeRange})`}
                        className={`relative flex flex-col items-center justify-center border-r border-white/30 px-1.5 text-center transition-all last:border-r-0 cursor-pointer ${
                          PHASE_COLORS[block.phase]
                        } ${isSelected ? 'ring-2 ring-inset ring-slate-950 brightness-105' : 'opacity-90 hover:opacity-100'}`}
                      >
                        <span className="w-full truncate text-[11px] font-semibold">
                          {block.title}
                        </span>
                        <span className="font-mono text-[10px] opacity-85 tabular-nums">
                          {span}m
                        </span>
                      </button>
                    );
                  })}
                </div>

                {activeBlock && (
                  <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-sm font-bold text-slate-900">{activeBlock.title}</div>
                      <div className="font-mono text-xs text-slate-600 tabular-nums">
                        {activeBlock.clockTimeRange} ({activeBlock.startMinute}–{activeBlock.endMinute}m)
                      </div>
                    </div>
                    <p className="mt-1 text-xs text-slate-700">{activeBlock.description}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
                      <span>Phase: {activeBlock.phase}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Dependencies:{' '}
                        {activeBlock.dependencies.length > 0
                          ? activeBlock.dependencies.join(', ')
                          : 'None'}
                      </span>
                    </div>
                  </div>
                )}

                {/* Full Schedule Table */}
                <div className="mt-6 overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500">
                        <th className="py-2.5 pr-4 font-semibold">Clock Time</th>
                        <th className="py-2.5 pr-4 font-semibold">Minutes</th>
                        <th className="py-2.5 pr-4 font-semibold">Activity</th>
                        <th className="py-2.5 pr-4 font-semibold">Phase</th>
                        <th className="py-2.5 font-semibold">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {plan.schedule.blocks.map((block) => (
                        <tr
                          key={block.id}
                          onClick={() => setSelectedBlockId(block.id)}
                          className="hover:bg-slate-50 cursor-pointer"
                        >
                          <td className="py-3 pr-4 font-mono text-slate-700 whitespace-nowrap tabular-nums">
                            {block.clockTimeRange}
                          </td>
                          <td className="py-3 pr-4 font-mono text-slate-500 whitespace-nowrap tabular-nums">
                            {block.startMinute}–{block.endMinute}m ({block.endMinute - block.startMinute}m)
                          </td>
                          <td className="py-3 pr-4 font-semibold text-slate-900">{block.title}</td>
                          <td className="py-3 pr-4 text-slate-600 capitalize">{block.phase}</td>
                          <td className="py-3 text-slate-600">{block.description}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mt-5 border-t border-slate-100 pt-4 text-xs text-slate-600">
                  <span className="font-semibold text-slate-800">Agent Rationale: </span>
                  {plan.schedule.rationale}
                  <span className="ml-2 font-mono text-slate-400">
                    [Sources: {plan.schedule.sourceMessageIds.join(', ') || 'Baseline'}]
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeArea === 'food' && (
            <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-6">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <div className="text-xs text-slate-500">
                    Distribution Window · {plan.food.distributionWindow}
                  </div>
                  <h2 className="mt-1 font-display text-2xl font-bold text-slate-950">
                    {plan.food.servingsPlanned} Participant Servings Planned
                  </h2>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Total Food Cost</div>
                  <div className="font-mono text-xl font-bold text-slate-950 tabular-nums">
                    {plan.food.totalFoodCost.toLocaleString()} {plan.budget.currency}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div>
                  <h3 className="text-xs font-semibold text-slate-900">Dietary Accommodations</h3>
                  <ul className="mt-2 space-y-1.5">
                    {plan.food.dietaryAccommodations.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-600" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-xs font-semibold text-slate-900">Distribution & Prohibitions</h3>
                  <p className="mt-2 text-xs text-slate-700">{plan.food.distributionStrategy}</p>
                  <ul className="mt-2 space-y-1">
                    {plan.food.prohibitionsRespected.map((p, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs text-slate-600">
                        <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-blue-600" />
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="overflow-x-auto border-t border-slate-100 pt-5">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="py-2.5 pr-4 font-semibold">Item</th>
                      <th className="py-2.5 pr-4 font-semibold">Category</th>
                      <th className="py-2.5 pr-4 text-right font-semibold">Quantity</th>
                      <th className="py-2.5 pr-4 text-right font-semibold">Unit Cost</th>
                      <th className="py-2.5 text-right font-semibold">Total Cost</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {plan.food.items.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-3 pr-4 font-semibold text-slate-900">
                          <div>{item.name}</div>
                          {item.notes && <div className="font-normal text-slate-500">{item.notes}</div>}
                        </td>
                        <td className="py-3 pr-4 text-slate-600 capitalize">
                          {item.category.replace('_', ' ')}
                        </td>
                        <td className="py-3 pr-4 text-right font-mono text-slate-700 tabular-nums">
                          {item.quantity} {item.unit}
                        </td>
                        <td className="py-3 pr-4 text-right font-mono text-slate-700 tabular-nums">
                          {item.unitCost.toLocaleString()}
                        </td>
                        <td className="py-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                          {item.totalCost.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="border-t border-slate-100 pt-4 text-xs text-slate-600">
                <span className="font-semibold text-slate-800">Agent Rationale: </span>
                {plan.food.rationale}
                <span className="ml-2 font-mono text-slate-400">
                  [Sources: {plan.food.sourceMessageIds.join(', ') || 'Baseline'}]
                </span>
              </div>
            </div>
          )}

          {activeArea === 'judging' && (
            <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-6">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <div className="text-xs text-slate-500">
                    Evaluation Throughput · {plan.judging.totalTeams} Teams
                  </div>
                  <h2 className="mt-1 font-display text-2xl font-bold text-slate-950">
                    {plan.judging.parallelTracks} Parallel Tracks · {plan.judging.judgeCount} Judges
                  </h2>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Judging Cost</div>
                  <div className="font-mono text-xl font-bold text-slate-950 tabular-nums">
                    {plan.judging.estimatedJudgingCost.toLocaleString()} {plan.budget.currency}
                  </div>
                </div>
              </div>

              {/* Throughput Feasibility Proof */}
              <div className="grid grid-cols-1 gap-4 rounded-lg border border-slate-200 bg-slate-50 p-4 sm:grid-cols-3">
                <div>
                  <div className="text-xs text-slate-500">Available Capacity</div>
                  <div className="mt-1 font-mono text-base font-bold text-slate-900 tabular-nums">
                    {plan.judging.parallelTracks} × {plan.judging.judgingWindowMinutes}m ={' '}
                    {plan.judging.parallelTracks * plan.judging.judgingWindowMinutes} team-min
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Required Time</div>
                  <div className="mt-1 font-mono text-base font-bold text-slate-900 tabular-nums">
                    {plan.judging.totalTeams} × {plan.judging.minutesPerTeam}m ={' '}
                    {plan.judging.totalTeams * plan.judging.minutesPerTeam} team-min
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Schedule Buffer</div>
                  <div className="mt-1 font-mono text-base font-bold text-emerald-700 tabular-nums">
                    +
                    {plan.judging.parallelTracks * plan.judging.judgingWindowMinutes -
                      plan.judging.totalTeams * plan.judging.minutesPerTeam}{' '}
                    team-min
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div>
                  <h3 className="text-xs font-semibold text-slate-900">Format & Scoring Procedure</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-700">
                    {plan.judging.formatDescription}
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-slate-600">
                    {plan.judging.scoringProcedure}
                  </p>
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-slate-900">Tie-Breaker & Restrictions</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-700">
                    {plan.judging.tieBreakerRule}
                  </p>
                  <ul className="mt-2 space-y-1">
                    {plan.judging.restrictionsRespected.map((r, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs text-slate-600">
                        <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-blue-600" />
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Rubric Criteria Breakdown */}
              <div className="border-t border-slate-100 pt-5">
                <h3 className="text-xs font-semibold text-slate-900">
                  Evaluation Rubric (Total:{' '}
                  {plan.judging.criteria.reduce((a, c) => a + c.weightPercent, 0)}%)
                </h3>
                <div className="mt-3 space-y-3">
                  {plan.judging.criteria.map((c, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-800">{c.name}</span>
                        <span className="font-mono font-bold text-slate-900 tabular-nums">
                          {c.weightPercent}%
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
                        <div
                          className="h-full bg-blue-600"
                          style={{ width: `${c.weightPercent}%` }}
                        />
                      </div>
                      {c.description && <p className="text-[11px] text-slate-500">{c.description}</p>}
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4 text-xs text-slate-600">
                <span className="font-semibold text-slate-800">Agent Rationale: </span>
                {plan.judging.rationale}
                <span className="ml-2 font-mono text-slate-400">
                  [Sources: {plan.judging.sourceMessageIds.join(', ') || 'Baseline'}]
                </span>
              </div>
            </div>
          )}

          {activeArea === 'budget' && (
            <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-6">
              <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <div className="text-xs text-slate-500">
                    Consolidated Ledger · {plan.budget.lineItems.length} Unique Line Items
                  </div>
                  <h2 className="mt-1 font-display text-2xl font-bold text-slate-950 tabular-nums">
                    {plan.budget.totalEstimatedCost.toLocaleString()} {plan.budget.currency}
                  </h2>
                </div>
                {plan.budget.budgetCap != null && (
                  <div className="text-right">
                    <div className="text-xs text-slate-500">
                      Cap: {plan.budget.budgetCap.toLocaleString()} {plan.budget.currency}
                    </div>
                    <div className="font-mono text-sm font-bold text-emerald-700 tabular-nums">
                      Buffer: {(plan.budget.remainingBuffer ?? 0).toLocaleString()} {plan.budget.currency}
                    </div>
                  </div>
                )}
              </div>

              {/* Area Cost Breakdown Strip */}
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                {Object.entries(plan.budget.areaTotals).map(([key, val]) => (
                  <div key={key} className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                    <div className="text-[11px] font-medium text-slate-500 capitalize">{key}</div>
                    <div className="mt-1 font-mono text-sm font-bold text-slate-900 tabular-nums">
                      {val.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>

              {/* Full Itemized Table */}
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="py-2.5 pr-4 font-semibold">Area</th>
                      <th className="py-2.5 pr-4 font-semibold">Line Item</th>
                      <th className="py-2.5 pr-4 text-right font-semibold">Qty</th>
                      <th className="py-2.5 pr-4 text-right font-semibold">Unit Cost</th>
                      <th className="py-2.5 text-right font-semibold">Total ({plan.budget.currency})</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {plan.budget.lineItems.map((li) => (
                      <tr key={li.id} className="hover:bg-slate-50">
                        <td className="py-3 pr-4 font-mono text-[11px] text-slate-500 uppercase">
                          {li.area}
                        </td>
                        <td className="py-3 pr-4 font-semibold text-slate-900">
                          <div>{li.item}</div>
                          {li.notes && <div className="font-normal text-slate-500">{li.notes}</div>}
                        </td>
                        <td className="py-3 pr-4 text-right font-mono text-slate-700 tabular-nums">
                          {li.quantity}
                        </td>
                        <td className="py-3 pr-4 text-right font-mono text-slate-700 tabular-nums">
                          {li.unitCost.toLocaleString()}
                        </td>
                        <td className="py-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                          {li.totalCost.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-slate-200 font-bold text-slate-950">
                      <td colSpan={4} className="py-3 pr-4 text-right">
                        Total Estimated Budget
                      </td>
                      <td className="py-3 text-right font-mono tabular-nums">
                        {plan.budget.totalEstimatedCost.toLocaleString()} {plan.budget.currency}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              <div className="rounded-lg border border-emerald-200 bg-emerald-50/50 p-3.5 text-xs text-emerald-950">
                <span className="font-semibold">Double-Counting Audit: </span>
                {plan.budget.doubleCountingAudit}
              </div>

              <div className="border-t border-slate-100 pt-4 text-xs text-slate-600">
                <span className="font-semibold text-slate-800">Agent Rationale: </span>
                {plan.budget.rationale}
                <span className="ml-2 font-mono text-slate-400">
                  [Sources: {plan.budget.sourceMessageIds.join(', ') || 'Baseline'}]
                </span>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
