import { motion } from 'motion/react';
import {
  AlertTriangle,
  ArrowRight,
  Building2,
  CalendarClock,
  CheckCircle2,
  FileUp,
  Gavel,
  Play,
  ShieldAlert,
  Sparkles,
  Utensils,
  Wallet,
  XCircle,
} from 'lucide-react';
import type { PlanningArea, WorkspaceState } from '../core/types';
import { summarizeTokens } from '../core/validation';
import type { NavTab } from './TopBar';

interface OverviewViewProps {
  state: WorkspaceState;
  isBusy: boolean;
  onLoadSample: () => void;
  onOpenPaste: () => void;
  onRunPlanner: () => void;
  onOpenUpdate: () => void;
  onNavigatePlanning: (area: PlanningArea) => void;
  onNavigateTab: (tab: NavTab) => void;
}

export function OverviewView({
  state,
  isBusy,
  onLoadSample,
  onOpenPaste,
  onRunPlanner,
  onOpenUpdate,
  onNavigatePlanning,
  onNavigateTab,
}: OverviewViewProps) {
  const tokenSummary = summarizeTokens(state.executionTrace);

  // State 1: Empty workspace (no messages yet)
  if (state.messages.length === 0 && !state.plan) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="mx-auto max-w-4xl py-8"
      >
        <div className="rounded-2xl border border-slate-200 bg-white p-8 md:p-10 shadow-xs">
          <p className="text-xs font-semibold tracking-wide text-blue-600">
            Autonomous Multi-Agent Event Solver
          </p>
          <h1 className="mt-2 font-display text-3xl font-bold tracking-tight text-slate-950 text-balance">
            Plan an Islamabad Hackathon Directly from Unstructured Messages
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-slate-600">
            Ingest any raw <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">.txt</code> pack of emails, WhatsApp threads, and official notices in English or Roman Urdu. Specialized agents extract constraints, arbitrate contradictions, generate coordinated plans across all five areas, and log every real model call and token count.
          </p>

          <div className="mt-6 grid grid-cols-2 gap-4 border-y border-slate-100 py-5 sm:grid-cols-4">
            <div>
              <div className="text-xs text-slate-500">Default Location</div>
              <div className="mt-1 text-sm font-semibold text-slate-900">Islamabad, PK</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Participants</div>
              <div className="mt-1 font-mono text-sm font-semibold text-slate-900 tabular-nums">150 Students</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Teams</div>
              <div className="mt-1 font-mono text-sm font-semibold text-slate-900 tabular-nums">50 Teams × 3</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Event Duration</div>
              <div className="mt-1 font-mono text-sm font-semibold text-slate-900 tabular-nums">4 Hours (240m)</div>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              disabled={isBusy}
              onClick={onLoadSample}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white transition-all hover:bg-slate-800 active:scale-[0.98] cursor-pointer"
            >
              <Sparkles className="h-4 w-4 text-blue-400" />
              <span>Load Sample Message Pack</span>
            </button>
            <button
              type="button"
              disabled={isBusy}
              onClick={onOpenPaste}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-50 cursor-pointer"
            >
              <FileUp className="h-4 w-4 text-slate-500" />
              <span>Paste or Upload Unseen .txt Pack</span>
            </button>
          </div>
        </div>
      </motion.div>
    );
  }

  // State 2: Messages loaded, plan not generated yet
  if (!state.plan && state.status !== 'impossible') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className="space-y-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-6">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-950">
              {state.messages.length} Raw Messages Ready for Processing
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Messages are preserved verbatim without pre-classification. Launch the multi-agent solver to extract English and Roman Urdu constraints, resolve conflicts, and generate the full 5-area plan.
            </p>
          </div>
          <button
            type="button"
            disabled={isBusy}
            onClick={onRunPlanner}
            className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-blue-700 active:scale-[0.98] disabled:opacity-50 cursor-pointer"
          >
            <Play className="h-4 w-4" />
            <span>Run Multi-Agent Planner</span>
          </button>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white">
          <div className="border-b border-slate-100 px-5 py-3.5 text-xs font-semibold text-slate-700">
            Ingested Raw Message Preview
          </div>
          <div className="divide-y divide-slate-100">
            {state.messages.map((msg) => (
              <div key={msg.id} className="px-5 py-4">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="font-mono font-semibold text-slate-900">{msg.id}</span>
                  {msg.sourceLabel && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>{msg.sourceLabel}</span>
                    </>
                  )}
                </div>
                <p className="mt-1.5 whitespace-pre-wrap text-xs leading-relaxed text-slate-700">
                  {msg.rawText}
                </p>
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    );
  }

  // State 3: Unresolvable Impossible Requirements Reported
  if (state.status === 'impossible') {
    return (
      <div className="space-y-6">
        <div className="rounded-xl border border-red-300 bg-red-50 p-6">
          <div className="flex items-start gap-3">
            <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-red-700" />
            <div>
              <h1 className="font-display text-xl font-bold text-red-950">
                Unresolvable Hard Constraint Conflict Detected
              </h1>
              <p className="mt-1 text-sm text-red-900">
                The planning system refused to invent a solution that silently violates a hard constraint. Resolve the conflicting requirements below via an incremental update or a corrected message pack.
              </p>
            </div>
          </div>

          <div className="mt-5 space-y-3">
            {state.impossibleConflicts.map((ic) => (
              <div key={ic.id} className="rounded-lg border border-red-200 bg-white p-4">
                <div className="flex items-center gap-2 text-xs text-red-700 font-semibold">
                  <span className="font-mono">{ic.id}</span>
                  <span aria-hidden="true">·</span>
                  <span>Areas: {ic.areas.join(', ')}</span>
                  <span aria-hidden="true">·</span>
                  <span>Sources: {ic.conflictingMessageIds.join(', ')}</span>
                </div>
                <p className="mt-1.5 text-sm text-slate-800">{ic.description}</p>
              </div>
            ))}
          </div>

          <div className="mt-5 flex gap-3">
            <button
              type="button"
              onClick={() => onNavigateTab('messages')}
              className="rounded-lg border border-red-300 bg-white px-4 py-2 text-xs font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
            >
              Inspect Conflict Messages
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('trace')}
              className="rounded-lg border border-red-300 bg-white px-4 py-2 text-xs font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
            >
              View Execution Trace
            </button>
          </div>
        </div>
      </div>
    );
  }

  const plan = state.plan!;
  const validation = state.validation;
  const latestUpdate = state.updateHistory[0];

  const areaCards: Array<{
    area: PlanningArea;
    title: string;
    icon: typeof Building2;
    headline: string;
    subline: string;
  }> = [
    {
      area: 'venue',
      title: 'Venue',
      icon: Building2,
      headline: plan.venue.venueName,
      subline: `${plan.venue.capacity} capacity · ${plan.venue.teamTables} tables · ${plan.venue.estimatedCost.toLocaleString()} ${plan.budget.currency}`,
    },
    {
      area: 'schedule',
      title: 'Schedule',
      icon: CalendarClock,
      headline: `${plan.schedule.startTime} – ${plan.schedule.endTime}`,
      subline: `${plan.schedule.totalDurationMinutes} mins total · ${plan.schedule.blocks.length} coordinated blocks`,
    },
    {
      area: 'food',
      title: 'Food & Catering',
      icon: Utensils,
      headline: `${plan.food.servingsPlanned} Servings Planned`,
      subline: `${plan.food.items.length} menu lines · ${plan.food.totalFoodCost.toLocaleString()} ${plan.budget.currency}`,
    },
    {
      area: 'judging',
      title: 'Judging',
      icon: Gavel,
      headline: `${plan.judging.parallelTracks} Tracks · ${plan.judging.judgeCount} Judges`,
      subline: `${plan.judging.totalTeams} teams × ${plan.judging.minutesPerTeam}m in ${plan.judging.judgingWindowMinutes}m window`,
    },
    {
      area: 'budget',
      title: 'Budget',
      icon: Wallet,
      headline: `${plan.budget.totalEstimatedCost.toLocaleString()} ${plan.budget.currency}`,
      subline:
        plan.budget.budgetCap != null
          ? `Cap: ${plan.budget.budgetCap.toLocaleString()} · Buffer: ${(plan.budget.remainingBuffer ?? 0).toLocaleString()}`
          : `${plan.budget.lineItems.length} verified line items`,
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-6"
    >
      {/* Top Event Overview Header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span className="font-semibold text-slate-900">Plan Version {plan.version}</span>
            <span aria-hidden="true">·</span>
            <span>{plan.parameters.location}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              {tokenSummary.totalCalls} Model Calls · {tokenSummary.totalTokens.toLocaleString()} Tokens
            </span>
            {state.lastRunDurationMs != null && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">
                  {(state.lastRunDurationMs / 1000).toFixed(1)}s Runtime
                </span>
              </>
            )}
          </div>
          <h1 className="mt-1 font-display text-2xl md:text-3xl font-bold tracking-tight text-slate-950">
            Hackathon Operations Plan
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <div
            className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold ${
              validation?.isValid
                ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                : 'border-amber-200 bg-amber-50 text-amber-800'
            }`}
          >
            {validation?.isValid ? (
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-amber-600" />
            )}
            <span>{validation?.isValid ? 'All Constraints Validated' : 'Validation Warnings'}</span>
          </div>

          <button
            type="button"
            disabled={isBusy}
            onClick={onOpenUpdate}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 cursor-pointer"
          >
            <span>Submit Incremental Update</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Participants & Teams</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {plan.parameters.participants} / {plan.parameters.teams}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            {plan.parameters.teamSize} students per team
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Event Window</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {plan.parameters.durationMinutes} min
          </div>
          <div className="mt-1 text-xs text-slate-500">
            {plan.schedule.startTime} – {plan.schedule.endTime}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Estimated Total Cost</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {plan.budget.totalEstimatedCost.toLocaleString()} {plan.budget.currency}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            {plan.budget.budgetCap != null
              ? `Cap ${plan.budget.budgetCap.toLocaleString()} ${plan.budget.currency}`
              : 'No hard ceiling specified'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Message Arbitration</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {state.dispositions.filter((d) => d.status === 'accepted' || d.status === 'partially_accepted').length} / {state.messages.length}
          </div>
          <div className="mt-1 text-xs text-slate-500 tabular-nums">
            {state.dispositions.filter((d) => d.status !== 'accepted' && d.status !== 'partially_accepted').length} rejected, outdated, or irrelevant
          </div>
        </div>
      </div>

      {/* Latest Incremental Update Diff Highlight (if any) */}
      {latestUpdate && (
        <motion.section
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-blue-200 bg-blue-50/40 p-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-bold text-slate-900">
                Latest Incremental Update ({latestUpdate.newMessageIds.join(', ')})
              </h2>
              <p className="mt-0.5 text-xs text-slate-600">{latestUpdate.reasoning}</p>
            </div>
            <div className="font-mono text-xs text-slate-700 tabular-nums">
              {latestUpdate.modelCallsUsed} / 5 model calls · {(latestUpdate.durationMs / 1000).toFixed(1)}s
            </div>
          </div>

          {latestUpdate.diff.changes.length > 0 ? (
            <div className="mt-4 divide-y divide-blue-100 rounded-lg border border-blue-100 bg-white">
              {latestUpdate.diff.changes.map((chg, idx) => (
                <div key={idx} className="grid grid-cols-1 gap-2 px-4 py-3 text-xs md:grid-cols-12 md:items-center">
                  <div className="font-semibold text-slate-900 md:col-span-3">
                    {chg.area.toUpperCase()} · {chg.field}
                  </div>
                  <div className="text-slate-500 line-through md:col-span-4 truncate" title={chg.before}>
                    {chg.before}
                  </div>
                  <div className="font-medium text-emerald-800 md:col-span-5" title={chg.after}>
                    {chg.after}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="mt-3 text-xs font-medium text-slate-700">
              {latestUpdate.diff.summary}
            </p>
          )}
        </motion.section>
      )}

      {/* 5 Planning Areas Interactive Grid */}
      <section aria-label="Five Planning Areas">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-slate-900">
            Five Planning Areas
          </h2>
          <button
            type="button"
            onClick={() => onNavigatePlanning('venue')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            Open Detailed Planner →
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {areaCards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.area}
                type="button"
                onClick={() => onNavigatePlanning(card.area)}
                className="group flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 text-left transition-all hover:border-slate-300 hover:shadow-sm cursor-pointer"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-2 text-xs font-semibold text-slate-500">
                      <Icon className="h-4 w-4 text-slate-700" />
                      <span>{card.title}</span>
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 text-slate-400 transition-transform group-hover:translate-x-0.5 group-hover:text-slate-800" />
                  </div>
                  <div className="mt-3 font-display text-lg font-bold text-slate-950">
                    {card.headline}
                  </div>
                  <div className="mt-1 text-xs text-slate-600 tabular-nums">{card.subline}</div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Deterministic Validation Audit Checklist */}
      {validation && (
        <section className="rounded-xl border border-slate-200 bg-white">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-5 py-4">
            <div>
              <h2 className="font-display text-base font-bold text-slate-900">
                Final Deterministic Validation Audit
              </h2>
              <p className="text-xs text-slate-500">{validation.summary}</p>
            </div>
            <span className="font-mono text-xs text-slate-500 tabular-nums">
              {validation.checks.filter((c) => c.passed).length} / {validation.checks.length} Passed
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {validation.checks.map((chk) => (
              <div key={chk.id} className="flex items-start justify-between gap-4 px-5 py-3.5">
                <div className="flex items-start gap-3">
                  {chk.passed ? (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                  ) : (
                    <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                  )}
                  <div>
                    <div className="text-xs font-semibold text-slate-900">{chk.label}</div>
                    <div className="mt-0.5 text-xs text-slate-600">{chk.details}</div>
                  </div>
                </div>
                <span
                  className={`text-xs font-semibold shrink-0 ${
                    chk.passed ? 'text-emerald-700' : 'text-red-700'
                  }`}
                >
                  {chk.passed ? 'Verified' : 'Failed'}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}
    </motion.div>
  );
}
