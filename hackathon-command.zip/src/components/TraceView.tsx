import { useMemo, useState } from 'react';
import { ChevronDown, ChevronRight, Download } from 'lucide-react';
import type { TraceAreaTag, WorkspaceState } from '../core/types';
import { summarizeTokens } from '../core/validation';

interface TraceViewProps {
  state: WorkspaceState;
}

type AreaFilter = 'all' | TraceAreaTag;

export function TraceView({ state }: TraceViewProps) {
  const [areaFilter, setAreaFilter] = useState<AreaFilter>('all');
  const [expandedCalls, setExpandedCalls] = useState<Record<number, { input: boolean; output: boolean }>>({});

  const summary = useMemo(() => summarizeTokens(state.executionTrace), [state.executionTrace]);

  const filteredTrace = useMemo(() => {
    if (areaFilter === 'all') return state.executionTrace;
    return state.executionTrace.filter((t) => t.areaTag === areaFilter);
  }, [state.executionTrace, areaFilter]);

  const togglePayload = (callNumber: number, field: 'input' | 'output') => {
    setExpandedCalls((prev) => {
      const current = prev[callNumber] ?? { input: false, output: false };
      return {
        ...prev,
        [callNumber]: { ...current, [field]: !current[field] },
      };
    });
  };

  if (state.executionTrace.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-10 text-center">
        <h2 className="font-display text-lg font-bold text-slate-900">
          No Model Calls Recorded Yet
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Run the multi-agent planner to capture sequential model calls, exact inputs, complete outputs, and real token usage.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Mandatory Total Token Usage Summary */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Total Model Calls</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {summary.totalCalls}
          </div>
          <div className="mt-1 text-xs text-slate-500">Sequential recorded invocations</div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Total Input Tokens</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {summary.inputTokens.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-slate-500">Reported by Gemini API</div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Total Output Tokens</div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-950 tabular-nums">
            {summary.outputTokens.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-slate-500">Reported by Gemini API</div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="text-xs font-medium text-slate-500">Grand Total Tokens</div>
          <div className="mt-2 font-mono text-2xl font-bold text-blue-700 tabular-nums">
            {summary.totalTokens.toLocaleString()}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            {summary.unavailableCount > 0
              ? `${summary.unavailableCount} call(s) lacked usage metadata`
              : 'Includes thinking tokens when reported'}
          </div>
        </div>
      </div>

      {/* Filter & Export Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="inline-flex flex-wrap items-center gap-1 rounded-xl border border-slate-200 bg-slate-100 p-1">
          {(['all', 'reading', 'venue', 'schedule', 'food', 'judging', 'budget'] as AreaFilter[]).map(
            (area) => (
              <button
                key={area}
                type="button"
                onClick={() => setAreaFilter(area)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold capitalize transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  areaFilter === area
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                {area}
              </button>
            )
          )}
        </div>

        <a
          href="/api/trace/export"
          download="hackathon-execution-trace.txt"
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0"
        >
          <Download className="h-3.5 w-3.5" />
          <span>Export Complete Trace (.txt)</span>
        </a>
      </div>

      {/* Sequential Model Call List */}
      <div className="space-y-3">
        {filteredTrace.map((entry) => {
          const exp = expandedCalls[entry.callNumber] ?? { input: false, output: false };
          return (
            <article
              key={`${entry.runId}-${entry.callNumber}`}
              className="rounded-xl border border-slate-200 bg-white p-5"
            >
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span className="font-mono font-bold text-slate-950">
                      Call #{entry.callNumber}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono font-semibold text-blue-700 uppercase">
                      {entry.areaTag}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{entry.model}</span>
                    <span aria-hidden="true">·</span>
                    <span>{entry.runType === 'initial' ? 'Initial Run' : 'Incremental Update'}</span>
                    {entry.isRetry && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-amber-700">Retry</span>
                      </>
                    )}
                  </div>
                  <h3 className="mt-1 text-sm font-semibold text-slate-900">{entry.purpose}</h3>
                </div>

                <div className="flex flex-wrap items-center gap-4 font-mono text-xs text-slate-700 tabular-nums">
                  <span>Duration: {entry.durationMs}ms</span>
                  {entry.tokenAvailability === 'reported' ? (
                    <span>
                      In: <strong>{entry.inputTokens}</strong> · Out:{' '}
                      <strong>{entry.outputTokens}</strong> · Total:{' '}
                      <strong className="text-slate-950">{entry.totalTokens}</strong>
                    </span>
                  ) : (
                    <span className="text-amber-700">Token usage unavailable</span>
                  )}
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  aria-expanded={exp.input}
                  onClick={() => togglePayload(entry.callNumber, 'input')}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  {exp.input ? (
                    <ChevronDown className="h-3.5 w-3.5" />
                  ) : (
                    <ChevronRight className="h-3.5 w-3.5" />
                  )}
                  <span>Exact Input ({entry.input.length.toLocaleString()} chars)</span>
                </button>

                <button
                  type="button"
                  aria-expanded={exp.output}
                  onClick={() => togglePayload(entry.callNumber, 'output')}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  {exp.output ? (
                    <ChevronDown className="h-3.5 w-3.5" />
                  ) : (
                    <ChevronRight className="h-3.5 w-3.5" />
                  )}
                  <span>Complete Output ({entry.output.length.toLocaleString()} chars)</span>
                </button>
              </div>

              {exp.input && (
                <pre className="mt-3 max-h-80 overflow-auto rounded-lg border border-slate-200 bg-slate-950 p-4 font-mono text-[11px] leading-relaxed text-slate-100 whitespace-pre-wrap">
                  {entry.input}
                </pre>
              )}

              {exp.output && (
                <pre className="mt-3 max-h-80 overflow-auto rounded-lg border border-slate-200 bg-slate-900 p-4 font-mono text-[11px] leading-relaxed text-emerald-100 whitespace-pre-wrap">
                  {entry.output}
                </pre>
              )}
            </article>
          );
        })}
      </div>
    </div>
  );
}
