import { motion } from 'motion/react';
import { ArrowRight, Play, PlusCircle, RefreshCw } from 'lucide-react';
import type { WorkspaceState } from '../core/types';

export type NavTab = 'overview' | 'planning' | 'messages' | 'trace';

interface TopBarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  state: WorkspaceState;
  isBusy: boolean;
  onPrimaryAction: () => void;
}

const NAV_ITEMS: Array<{ id: NavTab; label: string }> = [
  { id: 'overview', label: 'Overview' },
  { id: 'planning', label: 'Planning' },
  { id: 'messages', label: 'Messages' },
  { id: 'trace', label: 'Trace' },
];

export function TopBar({
  activeTab,
  onSelectTab,
  state,
  isBusy,
  onPrimaryAction,
}: TopBarProps) {
  let ctaLabel = 'Load Sample Pack';
  let CtaIcon = PlusCircle;

  if (isBusy) {
    ctaLabel = 'Running Agents...';
    CtaIcon = RefreshCw;
  } else if (state.plan) {
    ctaLabel = 'Incremental Update';
    CtaIcon = ArrowRight;
  } else if (state.messages.length > 0) {
    ctaLabel = 'Run Planner';
    CtaIcon = Play;
  }

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-[1380px] items-center justify-between gap-3 md:gap-8 px-4 sm:px-6 py-3.5">
        {/* Zone 1: Single-line Wordmark */}
        <button
          type="button"
          onClick={() => onSelectTab('overview')}
          className="font-display text-base sm:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 rounded"
        >
          Hackathon Command
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav aria-label="Primary Navigation" className="hidden md:flex items-center gap-7">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative py-1.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 rounded ${
                  isActive ? 'text-slate-950' : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {item.label}
                {isActive && (
                  <motion.span
                    layoutId="topbar-nav-underline"
                    transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                    className="absolute inset-x-0 -bottom-[15px] h-0.5 bg-blue-600"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            disabled={isBusy}
            onClick={onPrimaryAction}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 sm:px-4 py-2 text-xs font-semibold text-white transition-all hover:bg-slate-800 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <CtaIcon className={`h-3.5 w-3.5 ${isBusy ? 'animate-spin' : ''}`} />
            <span>{ctaLabel}</span>
          </button>
        </div>
      </div>

      {/* Mobile Nav Strip */}
      <nav
        aria-label="Mobile Navigation"
        className="flex md:hidden items-center justify-around border-t border-slate-100 bg-white px-3 py-1.5"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
                isActive ? 'bg-slate-100 text-slate-950 font-semibold' : 'text-slate-600'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
