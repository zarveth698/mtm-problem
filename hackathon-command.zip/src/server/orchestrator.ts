import { parseMessagePackText } from '../core/parser';
import type {
  BudgetPlan,
  ExecutionTraceEntry,
  ExtractedConstraint,
  FoodPlan,
  HackathonPlan,
  JudgingPlan,
  PipelineProgressEvent,
  PlanningArea,
  SchedulePlan,
  UpdateHistoryEntry,
  VenuePlan,
  WorkspaceState,
} from '../core/types';
import { computePlanDiff, summarizeTokens, validatePlanDeterministically } from '../core/validation';
import {
  type AgentContext,
  type CoordinationBrief,
  runBudgetAgent,
  runConsolidatedAreaUpdateAgent,
  runFoodAgent,
  runIncrementalImpactAgent,
  runJudgingAgent,
  runReadingAndCoordinationAgent,
  runScheduleAgent,
  runVenueAgent,
} from './agents';
import { saveState } from './store';

export type ProgressCallback = (event: PipelineProgressEvent) => void;

export function printExecutionTraceToConsole(
  runEntries: ExecutionTraceEntry[],
  allTrace: ExecutionTraceEntry[]
): void {
  const runSummary = summarizeTokens(runEntries);
  const grandSummary = summarizeTokens(allTrace);

  console.log('\n====================================================================');
  console.log('HACKATHON MULTI-AGENT EXECUTION TRACE');
  console.log('====================================================================');
  for (const entry of runEntries) {
    console.log(
      `\n--- Model Call #${entry.callNumber} [${entry.areaTag.toUpperCase()}] (${entry.model}) ---`
    );
    console.log(`Purpose: ${entry.purpose}`);
    console.log(`Run Type: ${entry.runType} | Duration: ${entry.durationMs}ms | Retry: ${entry.isRetry}`);
    console.log(
      `Tokens: ${
        entry.tokenAvailability === 'reported'
          ? `Input=${entry.inputTokens}, Output=${entry.outputTokens}, Total=${entry.totalTokens}`
          : 'Unavailable from provider'
      }`
    );
    console.log(`[EXACT INPUT]:\n${entry.input}`);
    console.log(`[COMPLETE OUTPUT]:\n${entry.output}`);
  }
  console.log('\n--------------------------------------------------------------------');
  console.log(
    `RUN TOKEN TOTAL (${runSummary.totalCalls} calls): Input=${runSummary.inputTokens}, Output=${runSummary.outputTokens}, Total=${runSummary.totalTokens}` +
      (runSummary.unavailableCount > 0 ? ` (${runSummary.unavailableCount} call(s) had unavailable token metadata)` : '')
  );
  console.log(
    `CUMULATIVE SESSION TOKEN TOTAL (${grandSummary.totalCalls} calls): Input=${grandSummary.inputTokens}, Output=${grandSummary.outputTokens}, Total=${grandSummary.totalTokens}`
  );
  console.log('====================================================================\n');
}

export async function runFullPlanningPipeline(
  currentState: WorkspaceState,
  emit: ProgressCallback
): Promise<WorkspaceState> {
  if (currentState.messages.length === 0) {
    throw new Error('No messages loaded. Please upload a .txt message pack or load the sample pack first.');
  }

  const runStart = Date.now();
  const runId = `run_${runStart}`;
  let callCounter = 0;
  const runEntries: ExecutionTraceEntry[] = [];

  const nextState: WorkspaceState = {
    ...currentState,
    dispositions: [],
    constraints: [],
    impossibleConflicts: [],
    plan: null,
    validation: null,
    executionTrace: [],
    updateHistory: [],
    status: 'running',
    errorMessage: null,
  };

  const ctx: AgentContext = {
    runId,
    runType: 'initial',
    getNextCallNumber: () => {
      callCounter += 1;
      return callCounter;
    },
    onTraceEntry: (entry) => {
      runEntries.push(entry);
      runEntries.sort((a, b) => a.callNumber - b.callNumber);
      nextState.executionTrace = [...nextState.executionTrace, entry].sort(
        (a, b) => a.callNumber - b.callNumber
      );
      emit({ type: 'trace', traceEntry: entry });
    },
  };

  try {
    // STEP 1 & 2: Unified Reading, Conflict Resolution & Coordination Brief
    emit({
      type: 'step',
      stepId: 'reading',
      label: 'Reading & Constraint Extraction',
      areaTag: 'reading',
      status: 'running',
      detail: `Reading ${nextState.messages.length} raw messages (English & Roman Urdu) & arbitrating conflicts...`,
    });
    emit({
      type: 'step',
      stepId: 'conflict',
      label: 'Conflict Resolution & Coordination',
      areaTag: 'reading',
      status: 'running',
      detail: 'Evaluating authority, specificity, overrides, and hard rules...',
    });

    const combined = await runReadingAndCoordinationAgent(ctx, nextState.messages);
    const resolvedConstraints = combined.constraints;
    const brief: CoordinationBrief = combined;

    nextState.dispositions = combined.dispositions;
    nextState.constraints = resolvedConstraints;
    nextState.impossibleConflicts = combined.impossibleConflicts;

    emit({
      type: 'step',
      stepId: 'reading',
      label: 'Reading & Constraint Extraction',
      areaTag: 'reading',
      status: 'completed',
      detail: `Extracted ${resolvedConstraints.length} constraints across ${combined.dispositions.length} messages.`,
    });
    emit({
      type: 'step',
      stepId: 'conflict',
      label: 'Conflict Resolution & Coordination',
      areaTag: 'reading',
      status: 'completed',
      detail: `${resolvedConstraints.filter((c) => c.status === 'active').length} active constraints · ${resolvedConstraints.filter((c) => c.status !== 'active').length} rejected/superseded/irrelevant.`,
    });

    const hasImpossible = brief.impossibleConflicts.some(
      (ic) => ic.resolutionStatus === 'unresolved_impossible'
    );
    if (hasImpossible) {
      nextState.status = 'impossible';
      nextState.lastRunDurationMs = Date.now() - runStart;
      nextState.errorMessage =
        'Unresolvable hard constraint conflict detected. Review impossibleConflicts rather than fabricating an invalid plan.';
      saveState(nextState);
      printExecutionTraceToConsole(runEntries, nextState.executionTrace);
      emit({ type: 'complete', state: nextState });
      return nextState;
    }

    // STEP 3: Sequential Specialized Planning Agents with 150ms breather to avoid Free Tier concurrent 503 bursts
    const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

    emit({ type: 'step', stepId: 'venue', label: 'Venue Agent', areaTag: 'venue', status: 'running', detail: 'Selecting capacity-compliant Islamabad venue...' });
    const venue = await runVenueAgent(ctx, brief, resolvedConstraints);
    emit({ type: 'step', stepId: 'venue', label: 'Venue Agent', areaTag: 'venue', status: 'completed', detail: `${venue.venueName} (${venue.capacity} cap)` });

    await delay(150);
    emit({ type: 'step', stepId: 'schedule', label: 'Schedule Agent', areaTag: 'schedule', status: 'running', detail: 'Building 240-minute conflict-free timeline...' });
    const schedule = await runScheduleAgent(ctx, brief, resolvedConstraints);
    emit({ type: 'step', stepId: 'schedule', label: 'Schedule Agent', areaTag: 'schedule', status: 'completed', detail: `${schedule.blocks.length} blocks · ${schedule.totalDurationMinutes}m` });

    await delay(150);
    emit({ type: 'step', stepId: 'food', label: 'Food Agent', areaTag: 'food', status: 'running', detail: 'Calculating quantities & dietary compliance...' });
    const food = await runFoodAgent(ctx, brief, resolvedConstraints);
    emit({ type: 'step', stepId: 'food', label: 'Food Agent', areaTag: 'food', status: 'completed', detail: `${food.servingsPlanned} servings · ${food.totalFoodCost.toLocaleString()} ${brief.parameters.currency}` });

    await delay(150);
    emit({ type: 'step', stepId: 'judging', label: 'Judging Agent', areaTag: 'judging', status: 'running', detail: 'Optimizing multi-track judging throughput...' });
    const judging = await runJudgingAgent(ctx, brief, resolvedConstraints);
    emit({ type: 'step', stepId: 'judging', label: 'Judging Agent', areaTag: 'judging', status: 'completed', detail: `${judging.parallelTracks} tracks · ${judging.minutesPerTeam}m/team` });

    // STEP 4: Budget Reconciliation Agent
    emit({
      type: 'step',
      stepId: 'budget',
      label: 'Budget & Cross-Area Reconciliation',
      areaTag: 'budget',
      status: 'running',
      detail: 'Consolidating area expenses, checking double-counting & funding caps...',
    });
    let budget = await runBudgetAgent(ctx, brief, resolvedConstraints, {
      venue,
      schedule,
      food,
      judging,
    });
    emit({
      type: 'step',
      stepId: 'budget',
      label: 'Budget & Cross-Area Reconciliation',
      areaTag: 'budget',
      status: 'completed',
      detail: `Total ${budget.totalEstimatedCost.toLocaleString()} ${budget.currency}`,
    });

    // STEP 5: Deterministic Final Validation (+ 1 targeted repair if needed)
    emit({
      type: 'step',
      stepId: 'validation',
      label: 'Final Plan Validation',
      areaTag: 'budget',
      status: 'running',
      detail: 'Verifying math, capacity, duration, judging feasibility, and source isolation...',
    });

    let plan: HackathonPlan = {
      version: 1,
      generatedAt: new Date().toISOString(),
      parameters: brief.parameters,
      venue,
      schedule,
      food,
      judging,
      budget,
      coordinationNotes: brief.coordinationNotes,
    };

    let validation = validatePlanDeterministically(plan, resolvedConstraints, brief.dispositions);

    // Targeted auto-repair if budget or schedule/judging had a deterministic mismatch and we are well under 120s
    if (!validation.isValid && Date.now() - runStart < 85_000) {
      const failedChecks = validation.checks.filter((c) => !c.passed);
      const repairInstructions = failedChecks.map((c) => `${c.label}: ${c.details}`).join(' | ');

      if (failedChecks.some((c) => c.area === 'schedule')) {
        plan.schedule = await runScheduleAgent(
          ctx,
          brief,
          resolvedConstraints,
          `REPAIR REQUIRED: Fix these validation failures: ${repairInstructions}`
        );
      }
      if (failedChecks.some((c) => c.area === 'judging')) {
        plan.judging = await runJudgingAgent(
          ctx,
          brief,
          resolvedConstraints,
          `REPAIR REQUIRED: Fix these validation failures: ${repairInstructions}`
        );
      }
      if (failedChecks.some((c) => c.area === 'food')) {
        plan.food = await runFoodAgent(
          ctx,
          brief,
          resolvedConstraints,
          `REPAIR REQUIRED: Fix these validation failures: ${repairInstructions}`
        );
      }
      if (failedChecks.some((c) => c.area === 'budget' || c.area === 'food' || c.area === 'judging')) {
        budget = await runBudgetAgent(
          ctx,
          brief,
          resolvedConstraints,
          { venue: plan.venue, schedule: plan.schedule, food: plan.food, judging: plan.judging },
          `REPAIR REQUIRED: Ensure exact arithmetic sum and stay within cap. Prior failure: ${repairInstructions}`
        );
        plan.budget = budget;
      }
      validation = validatePlanDeterministically(plan, resolvedConstraints, brief.dispositions);
    }

    emit({
      type: 'step',
      stepId: 'validation',
      label: 'Final Plan Validation',
      areaTag: 'budget',
      status: validation.isValid ? 'completed' : 'failed',
      detail: validation.summary,
    });

    nextState.plan = plan;
    nextState.validation = validation;
    nextState.lastRunDurationMs = Date.now() - runStart;
    nextState.status = validation.isValid ? 'completed' : 'completed_with_warnings';

    saveState(nextState);
    printExecutionTraceToConsole(runEntries, nextState.executionTrace);
    emit({ type: 'complete', state: nextState });
    return nextState;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    nextState.status = 'error';
    nextState.errorMessage = msg;
    nextState.lastRunDurationMs = Date.now() - runStart;
    saveState(nextState);
    printExecutionTraceToConsole(runEntries, nextState.executionTrace);
    emit({ type: 'error', error: msg, state: nextState });
    return nextState;
  }
}

export async function runIncrementalUpdatePipeline(
  currentState: WorkspaceState,
  rawUpdateText: string,
  emit: ProgressCallback
): Promise<{ state: WorkspaceState; updateEntry: UpdateHistoryEntry | null }> {
  if (!currentState.plan) {
    throw new Error('Cannot run incremental update before an initial plan exists. Run the full planner first.');
  }

  const newMessages = parseMessagePackText(rawUpdateText, {
    startingIndex: currentState.messages.length + 1,
    batchId: `update_${Date.now()}`,
  });

  if (newMessages.length === 0) {
    throw new Error('Update message cannot be empty.');
  }

  const runStart = Date.now();
  const runId = `upd_${runStart}`;
  let callCounter = currentState.executionTrace.length;
  let callsUsedInUpdate = 0;
  const MAX_UPDATE_CALLS = 5;
  const runEntries: ExecutionTraceEntry[] = [];

  const oldPlan = currentState.plan;
  const nextState: WorkspaceState = {
    ...currentState,
    messages: [...currentState.messages, ...newMessages],
    status: 'running',
    errorMessage: null,
  };

  const ctx: AgentContext = {
    runId,
    runType: 'incremental_update',
    canSpendCall: () => callsUsedInUpdate < MAX_UPDATE_CALLS,
    getNextCallNumber: () => {
      callCounter += 1;
      callsUsedInUpdate += 1;
      return callCounter;
    },
    onTraceEntry: (entry) => {
      runEntries.push(entry);
      runEntries.sort((a, b) => a.callNumber - b.callNumber);
      nextState.executionTrace = [...nextState.executionTrace, entry].sort(
        (a, b) => a.callNumber - b.callNumber
      );
      emit({ type: 'trace', traceEntry: entry });
    },
  };

  try {
    emit({
      type: 'step',
      stepId: 'reading',
      label: 'Incremental Message Analysis',
      areaTag: 'reading',
      status: 'running',
      detail: `Analyzing ${newMessages.length} new message(s) against existing plan (max 5 model calls)...`,
    });

    const impact = await runIncrementalImpactAgent(
      ctx,
      newMessages,
      currentState.constraints,
      oldPlan,
      currentState.constraints.length + 1
    );

    // Merge dispositions & constraints
    nextState.dispositions = [...currentState.dispositions, ...impact.newMessageDispositions];

    const resolutionMap = new Map(
      impact.updatedConstraintResolutions.map((r) => [r.constraintId, r])
    );
    const updatedExistingConstraints = currentState.constraints.map((c) => {
      const upd = resolutionMap.get(c.id);
      return upd
        ? {
            ...c,
            status: upd.status,
            resolutionReason: upd.resolutionReason,
            supersededById: upd.supersededById,
          }
        : c;
    });
    const allConstraints = [...updatedExistingConstraints, ...impact.newConstraints];
    nextState.constraints = allConstraints;
    nextState.impossibleConflicts = [
      ...currentState.impossibleConflicts,
      ...impact.impossibleConflicts,
    ];

    emit({
      type: 'step',
      stepId: 'reading',
      label: 'Incremental Message Analysis',
      areaTag: 'reading',
      status: 'completed',
      detail:
        impact.affectedAreas.length === 0
          ? 'No active plan areas affected (irrelevant, redundant, or rejected).'
          : `Affected areas: ${impact.affectedAreas.join(', ')}`,
    });

    const hasImpossible = impact.impossibleConflicts.some(
      (ic) => ic.resolutionStatus === 'unresolved_impossible'
    );
    if (hasImpossible) {
      nextState.status = 'impossible';
      nextState.errorMessage =
        'Incremental update introduced an unresolvable hard conflict.';
      nextState.lastRunDurationMs = Date.now() - runStart;
      saveState(nextState);
      printExecutionTraceToConsole(runEntries, nextState.executionTrace);
      emit({ type: 'complete', state: nextState });
      return { state: nextState, updateEntry: null };
    }

    // Build synthetic CoordinationBrief anchored to existing plan so unaffected areas stay untouched
    const syntheticBrief: CoordinationBrief = {
      parameters: impact.updatedParameters,
      dispositions: nextState.dispositions,
      impossibleConflicts: nextState.impossibleConflicts,
      sharedScheduleWindows: deriveWindowsFromSchedule(oldPlan.schedule, impact.updatedParameters.durationMinutes),
      sharedBudgetTargets: {
        currency: impact.updatedParameters.currency,
        totalCap: impact.updatedParameters.budgetCap,
        venueTarget: oldPlan.budget.areaTotals.venue,
        foodTarget: impact.updatedParameters.foodBudgetCap ?? oldPlan.budget.areaTotals.food,
        judgingTarget: oldPlan.budget.areaTotals.judging,
        operationsTarget: oldPlan.budget.areaTotals.operations,
        contingencyTarget: oldPlan.budget.areaTotals.contingency,
      },
      crossAreaDirectives: oldPlan.coordinationNotes,
      coordinationNotes: oldPlan.coordinationNotes,
    };

    let nextVenue: VenuePlan = oldPlan.venue;
    let nextSchedule: SchedulePlan = oldPlan.schedule;
    let nextFood: FoodPlan = oldPlan.food;
    let nextJudging: JudgingPlan = oldPlan.judging;
    let nextBudget: BudgetPlan = oldPlan.budget;

    const affectedSet = new Set<PlanningArea>(impact.affectedAreas);
    const nonBudgetAffected = (['venue', 'schedule', 'food', 'judging'] as PlanningArea[]).filter(
      (a) => affectedSet.has(a)
    );
    const needsBudget =
      affectedSet.has('budget') ||
      affectedSet.has('venue') ||
      affectedSet.has('food') ||
      affectedSet.has('judging');

    // Enforce strict <= 5 model calls (Call #1 already used => at most 4 calls left!)
    if (nonBudgetAffected.length === 4) {
      // Consolidate 4 operational areas into 1 call + 1 budget call = 3 total calls!
      emit({
        type: 'step',
        stepId: 'replan',
        label: 'Consolidated Multi-Area Update',
        areaTag: nonBudgetAffected[0],
        status: 'running',
        detail: 'Updating all impacted operational areas within 5-call limit...',
      });
      const consolidated = await runConsolidatedAreaUpdateAgent(
        ctx,
        nonBudgetAffected[0],
        syntheticBrief,
        allConstraints,
        oldPlan,
        impact.impactReasoning
      );
      nextVenue = consolidated.venue;
      nextSchedule = consolidated.schedule;
      nextFood = consolidated.food;
      nextJudging = consolidated.judging;
      emit({
        type: 'step',
        stepId: 'replan',
        label: 'Consolidated Multi-Area Update',
        areaTag: nonBudgetAffected[0],
        status: 'completed',
        detail: 'Operational plans updated.',
      });
    } else if (nonBudgetAffected.length > 0) {
      // Run targeted affected areas sequentially with a short breather (1..3 calls)
      const breather = (ms: number) => new Promise((r) => setTimeout(r, ms));
      if (affectedSet.has('venue')) {
        emit({ type: 'step', stepId: 'venue', label: 'Venue Update', areaTag: 'venue', status: 'running', detail: 'Updating venue plan...' });
        nextVenue = await runVenueAgent(ctx, syntheticBrief, allConstraints, impact.areaInstructions.venue ?? impact.impactReasoning);
        emit({ type: 'step', stepId: 'venue', label: 'Venue Update', areaTag: 'venue', status: 'completed', detail: nextVenue.venueName });
        await breather(150);
      }
      if (affectedSet.has('schedule')) {
        emit({ type: 'step', stepId: 'schedule', label: 'Schedule Update', areaTag: 'schedule', status: 'running', detail: 'Updating schedule timeline...' });
        nextSchedule = await runScheduleAgent(ctx, syntheticBrief, allConstraints, impact.areaInstructions.schedule ?? impact.impactReasoning);
        emit({ type: 'step', stepId: 'schedule', label: 'Schedule Update', areaTag: 'schedule', status: 'completed', detail: `${nextSchedule.blocks.length} blocks` });
        await breather(150);
      }
      if (affectedSet.has('food')) {
        emit({ type: 'step', stepId: 'food', label: 'Food Update', areaTag: 'food', status: 'running', detail: 'Updating catering & quantities...' });
        nextFood = await runFoodAgent(ctx, syntheticBrief, allConstraints, impact.areaInstructions.food ?? impact.impactReasoning);
        emit({ type: 'step', stepId: 'food', label: 'Food Update', areaTag: 'food', status: 'completed', detail: `${nextFood.servingsPlanned} servings` });
        await breather(150);
      }
      if (affectedSet.has('judging')) {
        emit({ type: 'step', stepId: 'judging', label: 'Judging Update', areaTag: 'judging', status: 'running', detail: 'Updating judging tracks & rubric...' });
        nextJudging = await runJudgingAgent(ctx, syntheticBrief, allConstraints, impact.areaInstructions.judging ?? impact.impactReasoning);
        emit({ type: 'step', stepId: 'judging', label: 'Judging Update', areaTag: 'judging', status: 'completed', detail: `${nextJudging.parallelTracks} tracks` });
      }
    }

    if (needsBudget && callsUsedInUpdate < MAX_UPDATE_CALLS) {
      emit({
        type: 'step',
        stepId: 'budget',
        label: 'Budget Reconciliation',
        areaTag: 'budget',
        status: 'running',
        detail: 'Recalculating affected budget lines & verifying cap...',
      });
      nextBudget = await runBudgetAgent(
        ctx,
        syntheticBrief,
        allConstraints,
        { venue: nextVenue, schedule: nextSchedule, food: nextFood, judging: nextJudging },
        impact.areaInstructions.budget ?? impact.impactReasoning
      );
      emit({
        type: 'step',
        stepId: 'budget',
        label: 'Budget Reconciliation',
        areaTag: 'budget',
        status: 'completed',
        detail: `${nextBudget.totalEstimatedCost.toLocaleString()} ${nextBudget.currency}`,
      });
    }

    // Reconcile superseded citations on preserved unaffected areas when an incremental update supersedes an earlier multi-area constraint
    const supersededConstraintMap = new Map(
      impact.updatedConstraintResolutions
        .filter((r) => r.status === 'superseded')
        .map((r) => [r.constraintId, r.supersededById])
    );
    const activeConstraintIds = new Set(
      allConstraints.filter((c) => c.status === 'active').map((c) => c.id)
    );
    const activeMessageIds = new Set(
      nextState.dispositions
        .filter((d) => d.status === 'accepted' || d.status === 'partially_accepted')
        .map((d) => d.messageId)
    );

    const reconcilePreservedCitations = <
      T extends { appliedConstraintIds: string[]; sourceMessageIds: string[] }
    >(
      areaPlan: T
    ): T => {
      if (supersededConstraintMap.size === 0) return areaPlan;
      const nextApplied = Array.from(
        new Set(
          areaPlan.appliedConstraintIds
            .map((cid) => supersededConstraintMap.get(cid) ?? cid)
            .filter((cid) => activeConstraintIds.has(cid))
        )
      );
      const nextSources = Array.from(
        new Set(areaPlan.sourceMessageIds.filter((mid) => activeMessageIds.has(mid)))
      );
      return {
        ...areaPlan,
        appliedConstraintIds: nextApplied,
        sourceMessageIds: nextSources,
      };
    };

    if (!affectedSet.has('venue')) nextVenue = reconcilePreservedCitations(nextVenue);
    if (!affectedSet.has('schedule')) nextSchedule = reconcilePreservedCitations(nextSchedule);
    if (!affectedSet.has('food')) nextFood = reconcilePreservedCitations(nextFood);
    if (!affectedSet.has('judging')) nextJudging = reconcilePreservedCitations(nextJudging);
    if (!needsBudget) nextBudget = reconcilePreservedCitations(nextBudget);

    const updatedPlan: HackathonPlan = {
      version: oldPlan.version + 1,
      generatedAt: new Date().toISOString(),
      parameters: impact.updatedParameters,
      venue: nextVenue,
      schedule: nextSchedule,
      food: nextFood,
      judging: nextJudging,
      budget: nextBudget,
      coordinationNotes: [
        ...oldPlan.coordinationNotes,
        `Update v${oldPlan.version + 1}: ${impact.impactReasoning}`,
      ],
    };

    const validation = validatePlanDeterministically(
      updatedPlan,
      allConstraints,
      nextState.dispositions
    );

    const reasoningMap: Partial<Record<PlanningArea | 'general', string>> = {
      general: impact.impactReasoning,
      venue: impact.areaInstructions.venue ?? impact.impactReasoning,
      schedule: impact.areaInstructions.schedule ?? impact.impactReasoning,
      food: impact.areaInstructions.food ?? impact.impactReasoning,
      judging: impact.areaInstructions.judging ?? impact.impactReasoning,
      budget: impact.areaInstructions.budget ?? impact.impactReasoning,
    };

    const diff = computePlanDiff(oldPlan, updatedPlan, reasoningMap);
    const durationMs = Date.now() - runStart;

    const updateEntry: UpdateHistoryEntry = {
      id: runId,
      timestamp: new Date().toISOString(),
      newMessageIds: newMessages.map((m) => m.id),
      rawInputPreview: rawUpdateText.slice(0, 180),
      affectedAreas: impact.affectedAreas,
      modelCallsUsed: callsUsedInUpdate,
      durationMs,
      reasoning: impact.impactReasoning,
      diff,
    };

    nextState.plan = updatedPlan;
    nextState.validation = validation;
    nextState.updateHistory = [updateEntry, ...currentState.updateHistory];
    nextState.lastRunDurationMs = durationMs;
    nextState.status = validation.isValid ? 'completed' : 'completed_with_warnings';

    saveState(nextState);
    printExecutionTraceToConsole(runEntries, nextState.executionTrace);
    emit({ type: 'complete', state: nextState });

    return { state: nextState, updateEntry };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    nextState.status = 'error';
    nextState.errorMessage = msg;
    nextState.lastRunDurationMs = Date.now() - runStart;
    saveState(nextState);
    printExecutionTraceToConsole(runEntries, nextState.executionTrace);
    emit({ type: 'error', error: msg, state: nextState });
    return { state: nextState, updateEntry: null };
  }
}

function deriveWindowsFromSchedule(schedule: SchedulePlan, durationMinutes: number) {
  const sumPhase = (phase: SchedulePlan['blocks'][number]['phase']) =>
    schedule.blocks
      .filter((b) => b.phase === phase)
      .reduce((acc, b) => acc + (b.endMinute - b.startMinute), 0);

  return {
    startTime: schedule.startTime,
    endTime: schedule.endTime,
    registrationMinutes: sumPhase('registration'),
    openingMinutes: sumPhase('opening'),
    hackingMinutes: sumPhase('hacking') || Math.max(0, durationMinutes - 90),
    foodBreakMinutes: sumPhase('food'),
    judgingWindowMinutes: sumPhase('judging') || 45,
    closingMinutes: sumPhase('closing'),
  };
}
