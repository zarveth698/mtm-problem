import { GoogleGenAI, ThinkingLevel, type Schema } from '@google/genai';
import type { ExecutionTraceEntry, TraceAreaTag } from '../core/types';

export const DEFAULT_MODEL = 'gemini-3.1-flash-lite';
export const FALLBACK_MODEL = 'gemini-3.1-flash-lite';

let cachedClient: GoogleGenAI | null = null;
const modelDailyExhaustedUntil = new Map<string, number>();

export function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is not configured in environment secrets. Please set it in Settings > Secrets.'
    );
  }
  if (!cachedClient) {
    cachedClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedClient;
}

export interface TracedCallParams<T> {
  runId: string;
  runType: 'initial' | 'incremental_update';
  areaTag: TraceAreaTag;
  purpose: string;
  systemInstruction: string;
  contents: string;
  responseSchema?: Schema;
  thinkingLevel?: ThinkingLevel;
  model?: string;
  maxRetries?: number;
  getNextCallNumber: () => number;
  onTraceEntry: (entry: ExecutionTraceEntry) => void;
  canSpendCall?: () => boolean;
}

function serializeInput(systemInstruction: string, contents: string): string {
  return `[SYSTEM INSTRUCTION]\n${systemInstruction}\n\n[USER / AGENT PAYLOAD]\n${contents}`;
}

function isDailyQuotaExhausted(errMsg: string): boolean {
  return (
    errMsg.includes('GenerateRequestsPerDay') ||
    errMsg.includes('PerDay') ||
    /retry in \d+h/i.test(errMsg)
  );
}

function isTransientOverload(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err ?? '');
  return (
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('429') ||
    msg.includes('RESOURCE_EXHAUSTED')
  );
}

function extractRetryBackoffMs(errMsg: string, attempt: number): number {
  const retryMatch = errMsg.match(/"retryDelay"\s*:\s*"(\d+)s"/);
  if (retryMatch) {
    const secs = Number(retryMatch[1]);
    if (Number.isFinite(secs) && secs > 0 && secs <= 15) {
      return secs * 1000 + 300;
    }
  }
  return 2000 * (attempt + 1) + Math.floor(Math.random() * 400);
}

function formatReadableError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err ?? 'Unknown Gemini API error');
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return 'Gemini API rate/quota limit reached (429 RESOURCE_EXHAUSTED). Please wait a moment and retry, or select a billing-enabled API key in Settings > Secrets.';
  }
  if (raw.includes('503') || raw.includes('UNAVAILABLE')) {
    return 'Gemini API is temporarily overloaded (503 UNAVAILABLE). Please retry in a few seconds.';
  }
  if (raw.includes('API_KEY_INVALID') || raw.includes('PERMISSION_DENIED')) {
    return 'Gemini API key error (400/403). Please verify your GEMINI_API_KEY in Settings > Secrets.';
  }
  return raw;
}

export async function tracedGenerateJson<T>(params: TracedCallParams<T>): Promise<T> {
  const ai = getGeminiClient();
  const requestedModel = params.model ?? DEFAULT_MODEL;
  const now = Date.now();
  const exhaustedUntil = modelDailyExhaustedUntil.get(requestedModel) ?? 0;
  const primaryModel =
    now < exhaustedUntil && requestedModel !== FALLBACK_MODEL
      ? FALLBACK_MODEL
      : requestedModel;
  const maxRetries = params.maxRetries ?? 2;
  const serializedInput = serializeInput(params.systemInstruction, params.contents);

  let lastError: unknown;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    if (params.canSpendCall && !params.canSpendCall()) {
      throw new Error('Model call budget exceeded for this run.');
    }

    const callNumber = params.getNextCallNumber();
    const start = Date.now();
    const isRetry = attempt > 0;
    const useFallbackModel =
      attempt >= 1 && primaryModel !== FALLBACK_MODEL && isTransientOverload(lastError);
    const model = useFallbackModel ? FALLBACK_MODEL : primaryModel;

    try {
      const effectiveThinkingLevel =
        model === 'gemini-3.1-flash-lite'
          ? params.thinkingLevel === ThinkingLevel.LOW
            ? ThinkingLevel.LOW
            : undefined
          : params.thinkingLevel ?? ThinkingLevel.LOW;

      const response = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: {
          systemInstruction: params.systemInstruction,
          responseMimeType: 'application/json',
          ...(params.responseSchema ? { responseSchema: params.responseSchema } : {}),
          ...(effectiveThinkingLevel
            ? {
                thinkingConfig: {
                  thinkingLevel: effectiveThinkingLevel,
                },
              }
            : {}),
        },
      });

      const durationMs = Date.now() - start;
      const rawOutput = (response.text ?? '').trim();
      const usage = response.usageMetadata;
      const hasUsage =
        usage != null &&
        typeof usage.promptTokenCount === 'number' &&
        typeof usage.candidatesTokenCount === 'number' &&
        typeof usage.totalTokenCount === 'number';

      const entry: ExecutionTraceEntry = {
        callNumber,
        runId: params.runId,
        runType: params.runType,
        model,
        areaTag: params.areaTag,
        purpose: isRetry ? `${params.purpose} (Retry #${attempt})` : params.purpose,
        isRetry,
        input: serializedInput,
        output: rawOutput,
        inputTokens: hasUsage ? usage!.promptTokenCount! : null,
        outputTokens: hasUsage ? usage!.candidatesTokenCount! : null,
        totalTokens: hasUsage ? usage!.totalTokenCount! : null,
        tokenAvailability: hasUsage ? 'reported' : 'unavailable',
        durationMs,
        timestamp: new Date().toISOString(),
      };

      params.onTraceEntry(entry);

      if (!rawOutput) {
        throw new Error(`Model returned empty output on call #${callNumber}`);
      }

      const parsed = JSON.parse(rawOutput) as T;
      return parsed;
    } catch (err) {
      lastError = err;
      const durationMs = Date.now() - start;
      const errMsg = err instanceof Error ? err.message : String(err);
      if (isDailyQuotaExhausted(errMsg)) {
        modelDailyExhaustedUntil.set(model, Date.now() + 60 * 60 * 1000);
      }

      const isApiError =
        !(err instanceof SyntaxError) &&
        !errMsg.startsWith('Model returned empty');
      if (isApiError) {
        const statusMatch = errMsg.match(/"code"\s*:\s*(\d+)/);
        const statusCode = statusMatch ? statusMatch[1] : 'API';
        const willRetry = attempt < maxRetries;
        const entry: ExecutionTraceEntry = {
          callNumber,
          runId: params.runId,
          runType: params.runType,
          model,
          areaTag: params.areaTag,
          purpose: willRetry
            ? `${params.purpose} (Attempt #${attempt + 1} transient ${statusCode} — retrying)`
            : `${params.purpose} (Failed after ${attempt + 1} attempts)`,
          isRetry,
          input: serializedInput,
          output: willRetry
            ? `[TRANSIENT ${statusCode}] Provider requested backoff; proceeding to retry.`
            : `[FAILED] ${formatReadableError(err)}`,
          inputTokens: null,
          outputTokens: null,
          totalTokens: null,
          tokenAvailability: 'unavailable',
          durationMs,
          timestamp: new Date().toISOString(),
        };
        params.onTraceEntry(entry);
      }

      if (attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, extractRetryBackoffMs(errMsg, attempt)));
      }
    }
  }

  throw new Error(formatReadableError(lastError));
}
