import { ThinkingLevel, Type, type Schema } from '@google/genai';
import type {
  BudgetPlan,
  EventParameters,
  ExecutionTraceEntry,
  ExtractedConstraint,
  FoodPlan,
  HackathonPlan,
  ImpossibleConflict,
  JudgingPlan,
  MessageDisposition,
  PlanningArea,
  RawMessage,
  SchedulePlan,
  VenuePlan,
} from '../core/types';
import { tracedGenerateJson } from './geminiClient';

export interface AgentContext {
  runId: string;
  runType: 'initial' | 'incremental_update';
  getNextCallNumber: () => number;
  onTraceEntry: (entry: ExecutionTraceEntry) => void;
  canSpendCall?: () => boolean;
}

export interface CombinedReadingResult {
  parameters: EventParameters;
  dispositions: MessageDisposition[];
  constraints: ExtractedConstraint[];
  impossibleConflicts: ImpossibleConflict[];
  sharedScheduleWindows: {
    startTime: string;
    endTime: string;
    registrationMinutes: number;
    openingMinutes: number;
    hackingMinutes: number;
    foodBreakMinutes: number;
    judgingWindowMinutes: number;
    closingMinutes: number;
  };
  sharedBudgetTargets: {
    currency: string;
    totalCap: number | null;
    venueTarget: number;
    foodTarget: number;
    judgingTarget: number;
    operationsTarget: number;
    contingencyTarget: number;
  };
  crossAreaDirectives: string[];
  coordinationNotes: string[];
}

export type CoordinationBrief = Omit<CombinedReadingResult, 'constraints'>;

export interface IncrementalImpactResult {
  newMessageDispositions: MessageDisposition[];
  newConstraints: ExtractedConstraint[];
  updatedConstraintResolutions: Array<{
    constraintId: string;
    status: ExtractedConstraint['status'];
    resolutionReason: string;
    supersededById?: string;
  }>;
  impossibleConflicts: ImpossibleConflict[];
  updatedParameters: EventParameters;
  affectedAreas: PlanningArea[];
  impactReasoning: string;
  areaInstructions: Partial<Record<PlanningArea, string>>;
}

const DEFAULT_BASELINE_TEXT = `Default Baseline Event Requirements (apply unless explicitly overridden by an authoritative active message):
- Event: Physical Hackathon
- Location: Islamabad, Pakistan
- Duration: 4 hours (240 minutes)
- Participants: 150 students
- Teams: 50 teams
- Team size: 3 students per team
- Currency: PKR (unless another currency is explicitly specified in the messages)
- Planning Areas: Venue, Schedule, Food, Judging, Budget`;

const COMBINED_READING_COORDINATION_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    parameters: {
      type: Type.OBJECT,
      properties: {
        eventType: { type: Type.STRING },
        location: { type: Type.STRING },
        durationMinutes: { type: Type.INTEGER },
        participants: { type: Type.INTEGER },
        teams: { type: Type.INTEGER },
        teamSize: { type: Type.INTEGER },
        currency: { type: Type.STRING },
        budgetCap: { type: Type.NUMBER, nullable: true },
        foodBudgetCap: { type: Type.NUMBER, nullable: true },
        venueNameOverride: { type: Type.STRING, nullable: true },
        dateHint: { type: Type.STRING, nullable: true },
        startTimeHint: { type: Type.STRING, nullable: true },
      },
      required: ['eventType', 'location', 'durationMinutes', 'participants', 'teams', 'teamSize', 'currency'],
    },
    dispositions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          messageId: { type: Type.STRING },
          status: {
            type: Type.STRING,
            enum: ['accepted', 'partially_accepted', 'rejected', 'outdated', 'superseded', 'irrelevant'],
          },
          relevance: { type: Type.STRING, enum: ['relevant', 'irrelevant'] },
          language: { type: Type.STRING, enum: ['en', 'roman_urdu', 'mixed'] },
          senderOrSource: { type: Type.STRING },
          summary: { type: Type.STRING },
          reason: { type: Type.STRING },
          extractedFactCount: { type: Type.INTEGER },
          supersededByMessageId: { type: Type.STRING },
        },
        required: ['messageId', 'status', 'relevance', 'language', 'senderOrSource', 'summary', 'reason', 'extractedFactCount'],
      },
    },
    constraints: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          sourceMessageId: { type: Type.STRING },
          area: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'budget', 'general'] },
          affectedAreas: {
            type: Type.ARRAY,
            items: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'budget'] },
          },
          category: {
            type: Type.STRING,
            enum: ['hard', 'soft', 'numerical', 'temporal', 'conditional', 'dependency', 'prohibition', 'resource', 'cross_area'],
          },
          isHard: { type: Type.BOOLEAN },
          summary: { type: Type.STRING },
          exactQuote: { type: Type.STRING },
          language: { type: Type.STRING, enum: ['en', 'roman_urdu', 'mixed'] },
          authorityHint: {
            type: Type.STRING,
            enum: ['official_notice', 'lead_organizer', 'sponsor_or_venue', 'volunteer_or_student', 'casual_chat', 'unknown'],
          },
          status: { type: Type.STRING, enum: ['active', 'superseded', 'rejected', 'irrelevant', 'impossible'] },
          resolutionReason: { type: Type.STRING },
          supersededById: { type: Type.STRING },
        },
        required: [
          'id',
          'sourceMessageId',
          'area',
          'affectedAreas',
          'category',
          'isHard',
          'summary',
          'exactQuote',
          'language',
          'authorityHint',
          'status',
          'resolutionReason',
        ],
      },
    },
    impossibleConflicts: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          areas: { type: Type.ARRAY, items: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'budget'] } },
          description: { type: Type.STRING },
          conflictingMessageIds: { type: Type.ARRAY, items: { type: Type.STRING } },
          resolutionStatus: { type: Type.STRING, enum: ['unresolved_impossible', 'resolved_with_tradeoff'] },
        },
        required: ['id', 'areas', 'description', 'conflictingMessageIds', 'resolutionStatus'],
      },
    },
    sharedScheduleWindows: {
      type: Type.OBJECT,
      properties: {
        startTime: { type: Type.STRING },
        endTime: { type: Type.STRING },
        registrationMinutes: { type: Type.INTEGER },
        openingMinutes: { type: Type.INTEGER },
        hackingMinutes: { type: Type.INTEGER },
        foodBreakMinutes: { type: Type.INTEGER },
        judgingWindowMinutes: { type: Type.INTEGER },
        closingMinutes: { type: Type.INTEGER },
      },
      required: [
        'startTime',
        'endTime',
        'registrationMinutes',
        'openingMinutes',
        'hackingMinutes',
        'foodBreakMinutes',
        'judgingWindowMinutes',
        'closingMinutes',
      ],
    },
    sharedBudgetTargets: {
      type: Type.OBJECT,
      properties: {
        currency: { type: Type.STRING },
        totalCap: { type: Type.NUMBER, nullable: true },
        venueTarget: { type: Type.NUMBER },
        foodTarget: { type: Type.NUMBER },
        judgingTarget: { type: Type.NUMBER },
        operationsTarget: { type: Type.NUMBER },
        contingencyTarget: { type: Type.NUMBER },
      },
      required: ['currency', 'venueTarget', 'foodTarget', 'judgingTarget', 'operationsTarget', 'contingencyTarget'],
    },
    crossAreaDirectives: { type: Type.ARRAY, items: { type: Type.STRING } },
    coordinationNotes: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'parameters',
    'dispositions',
    'constraints',
    'impossibleConflicts',
    'sharedScheduleWindows',
    'sharedBudgetTargets',
    'crossAreaDirectives',
    'coordinationNotes',
  ],
};

export async function runReadingAndCoordinationAgent(
  ctx: AgentContext,
  messages: RawMessage[]
): Promise<CombinedReadingResult> {
  const formattedMessages = messages
    .map((m) => `=== ${m.id} ===\n${m.rawText}`)
    .join('\n\n');

  const systemInstruction = `You are the Reading, Conflict Resolution & Cross-Area Coordination Agent for an autonomous hackathon planning system.
Read EVERY raw message (English, Roman Urdu, or mixed), extract constraints (C1, C2, ...), arbitrate all conflicts, classify every message, and produce ONE unified Coordination Brief for the 5 specialized planning agents.

CONCISENESS REQUIREMENT (CRITICAL FOR SPEED):
- Keep every summary, reason, and resolutionReason crisp (1 short sentence, <= 22 words).
- Keep exactQuote to a short 5–15 word verbatim snippet from the source message.

ARBITRATION POLICY (STRICT):
1. Hard constraints & explicit prohibitions ALWAYS override soft preferences or casual requests.
2. Official notices & lead organizers/finance carry higher authority than volunteers or casual student chat.
3. Explicit overrides ("supersedes", "final", "not X anymore") override earlier drafts.
4. Specific constraints override general assumptions.
5. NEVER assume newest automatically wins—evaluate authority, hard-rule compatibility, and specificity first.
6. Reject venues that fail hard capacity (capacity < participants) or violate hard rules, and document why.
7. If two authoritative hard constraints are mathematically impossible to satisfy simultaneously, flag them in impossibleConflicts with resolutionStatus: "unresolved_impossible".
8. sharedScheduleWindows minutes MUST sum EXACTLY to parameters.durationMinutes (default 240).
9. sharedBudgetTargets (venueTarget + foodTarget + judgingTarget + operationsTarget + contingencyTarget) MUST be <= totalCap (if totalCap exists).
10. Provide a disposition entry for EVERY message ID (${messages.map((m) => m.id).join(', ')}).`;

  const contents = `${DEFAULT_BASELINE_TEXT}\n\nRAW MESSAGE PACK (${messages.length} messages):\n\n${formattedMessages}`;

  return tracedGenerateJson<CombinedReadingResult>({
    ...ctx,
    areaTag: 'reading',
    purpose: `Reading & Conflict Resolution Agent: Extract constraints & arbitrate ${messages.length} messages`,
    systemInstruction,
    contents,
    responseSchema: COMBINED_READING_COORDINATION_SCHEMA,
    thinkingLevel: ThinkingLevel.LOW,
  });
}

function formatActiveContext(
  area: PlanningArea,
  brief: CoordinationBrief,
  constraints: ExtractedConstraint[]
): string {
  const active = constraints.filter(
    (c) => c.status === 'active' && (c.affectedAreas.includes(area) || c.area === area || c.area === 'general')
  );
  const blockedIds = constraints
    .filter((c) => c.status !== 'active')
    .map((c) => `${c.id} (from ${c.sourceMessageId}: ${c.status})`);

  return JSON.stringify(
    {
      eventParameters: brief.parameters,
      sharedScheduleWindows: brief.sharedScheduleWindows,
      sharedBudgetTargets: brief.sharedBudgetTargets,
      crossAreaDirectives: brief.crossAreaDirectives,
      activeConstraintsForThisArea: active.map((c) => ({
        id: c.id,
        sourceMessageId: c.sourceMessageId,
        category: c.category,
        isHard: c.isHard,
        summary: c.summary,
        exactQuote: c.exactQuote,
      })),
      doNotUseBlockedConstraints: blockedIds,
      rule: 'ONLY cite IDs from activeConstraintsForThisArea in appliedConstraintIds and sourceMessageIds. Never use rejected/superseded/irrelevant items.',
    },
    null,
    2
  );
}

const VENUE_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    venueName: { type: Type.STRING },
    addressOrSector: { type: Type.STRING },
    capacity: { type: Type.INTEGER },
    teamTables: { type: Type.INTEGER },
    seatsPerTable: { type: Type.INTEGER },
    facilities: { type: Type.ARRAY, items: { type: Type.STRING } },
    accessibilityNotes: { type: Type.STRING },
    restrictionsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    seatingArrangement: { type: Type.STRING },
    estimatedCost: { type: Type.NUMBER },
    rationale: { type: Type.STRING },
    sourceMessageIds: { type: Type.ARRAY, items: { type: Type.STRING } },
    appliedConstraintIds: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'venueName',
    'addressOrSector',
    'capacity',
    'teamTables',
    'seatsPerTable',
    'facilities',
    'accessibilityNotes',
    'restrictionsRespected',
    'seatingArrangement',
    'estimatedCost',
    'rationale',
    'sourceMessageIds',
    'appliedConstraintIds',
  ],
};

export async function runVenueAgent(
  ctx: AgentContext,
  brief: CoordinationBrief,
  constraints: ExtractedConstraint[],
  extraDirective?: string
): Promise<VenuePlan> {
  return tracedGenerateJson<VenuePlan>({
    ...ctx,
    model: 'gemini-3.1-flash-lite',
    areaTag: 'venue',
    purpose: 'Venue Agent: Select venue, seating layout, facilities, and restrictions',
    systemInstruction: `You are the Venue Planning Agent. Select the valid physical venue in ${brief.parameters.location} satisfying capacity >= ${brief.parameters.participants} participants and teamTables >= ${brief.parameters.teams} teams (${brief.parameters.teamSize}/table). Respect all venue prohibitions, accessibility needs, and venueTarget budget (${brief.sharedBudgetTargets.venueTarget} ${brief.parameters.currency}). Cite ONLY active constraint/message IDs.${extraDirective ? `\n\nUPDATE DIRECTIVE: ${extraDirective}` : ''}`,
    contents: formatActiveContext('venue', brief, constraints),
    responseSchema: VENUE_SCHEMA,
    thinkingLevel: ThinkingLevel.MINIMAL,
  });
}

const SCHEDULE_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    totalDurationMinutes: { type: Type.INTEGER },
    startTime: { type: Type.STRING },
    endTime: { type: Type.STRING },
    blocks: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          title: { type: Type.STRING },
          phase: { type: Type.STRING, enum: ['registration', 'opening', 'hacking', 'food', 'judging', 'closing', 'buffer'] },
          startMinute: { type: Type.INTEGER },
          endMinute: { type: Type.INTEGER },
          clockTimeRange: { type: Type.STRING },
          description: { type: Type.STRING },
          allowParallel: { type: Type.BOOLEAN },
          dependencies: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['id', 'title', 'phase', 'startMinute', 'endMinute', 'clockTimeRange', 'description', 'allowParallel', 'dependencies'],
      },
    },
    constraintsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    rationale: { type: Type.STRING },
    sourceMessageIds: { type: Type.ARRAY, items: { type: Type.STRING } },
    appliedConstraintIds: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'totalDurationMinutes',
    'startTime',
    'endTime',
    'blocks',
    'constraintsRespected',
    'rationale',
    'sourceMessageIds',
    'appliedConstraintIds',
  ],
};

export async function runScheduleAgent(
  ctx: AgentContext,
  brief: CoordinationBrief,
  constraints: ExtractedConstraint[],
  extraDirective?: string
): Promise<SchedulePlan> {
  return tracedGenerateJson<SchedulePlan>({
    ...ctx,
    model: 'gemini-3.1-flash-lite',
    areaTag: 'schedule',
    purpose: 'Schedule Agent: Construct non-overlapping 4-hour timeline',
    systemInstruction: `You are the Schedule Planning Agent. Construct a complete, contiguous schedule from minute 0 to minute ${brief.parameters.durationMinutes} (totalDurationMinutes = ${brief.parameters.durationMinutes}). Follow sharedScheduleWindows closely so Food and Judging windows match. No blocks may exceed ${brief.parameters.durationMinutes}, and non-parallel blocks must never overlap. Respect all temporal constraints (entry times, building lockup, minimum hacking time). Cite ONLY active constraint/message IDs.${extraDirective ? `\n\nUPDATE DIRECTIVE: ${extraDirective}` : ''}`,
    contents: formatActiveContext('schedule', brief, constraints),
    responseSchema: SCHEDULE_SCHEMA,
    thinkingLevel: ThinkingLevel.MINIMAL,
  });
}

const FOOD_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    servingsPlanned: { type: Type.INTEGER },
    dietaryAccommodations: { type: Type.ARRAY, items: { type: Type.STRING } },
    prohibitionsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    distributionStrategy: { type: Type.STRING },
    distributionWindow: { type: Type.STRING },
    items: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          category: { type: Type.STRING, enum: ['meal', 'snack', 'beverage', 'dietary_special'] },
          quantity: { type: Type.INTEGER },
          unit: { type: Type.STRING },
          unitCost: { type: Type.NUMBER },
          totalCost: { type: Type.NUMBER },
          notes: { type: Type.STRING },
        },
        required: ['name', 'category', 'quantity', 'unit', 'unitCost', 'totalCost', 'notes'],
      },
    },
    totalFoodCost: { type: Type.NUMBER },
    rationale: { type: Type.STRING },
    sourceMessageIds: { type: Type.ARRAY, items: { type: Type.STRING } },
    appliedConstraintIds: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'servingsPlanned',
    'dietaryAccommodations',
    'prohibitionsRespected',
    'distributionStrategy',
    'distributionWindow',
    'items',
    'totalFoodCost',
    'rationale',
    'sourceMessageIds',
    'appliedConstraintIds',
  ],
};

export async function runFoodAgent(
  ctx: AgentContext,
  brief: CoordinationBrief,
  constraints: ExtractedConstraint[],
  extraDirective?: string
): Promise<FoodPlan> {
  return tracedGenerateJson<FoodPlan>({
    ...ctx,
    model: 'gemini-3.1-flash-lite',
    areaTag: 'food',
    purpose: 'Food Agent: Plan meals, quantities, dietary rules, and distribution',
    systemInstruction: `You are the Food Planning Agent. Plan food & refreshments for at least ${brief.parameters.participants} participants. Ensure servingsPlanned >= ${brief.parameters.participants}, item totalCost = quantity * unitCost, totalFoodCost equals the exact sum of items[].totalCost, and totalFoodCost stays within any foodBudgetCap (${brief.parameters.foodBudgetCap ?? brief.sharedBudgetTargets.foodTarget} ${brief.parameters.currency}). Respect all dietary restrictions and venue food prohibitions. Cite ONLY active constraint/message IDs.${extraDirective ? `\n\nUPDATE DIRECTIVE: ${extraDirective}` : ''}`,
    contents: formatActiveContext('food', brief, constraints),
    responseSchema: FOOD_SCHEMA,
    thinkingLevel: ThinkingLevel.MINIMAL,
  });
}

const JUDGING_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    totalTeams: { type: Type.INTEGER },
    judgeCount: { type: Type.INTEGER },
    parallelTracks: { type: Type.INTEGER },
    judgingWindowMinutes: { type: Type.INTEGER },
    minutesPerTeam: { type: Type.NUMBER },
    formatDescription: { type: Type.STRING },
    scoringProcedure: { type: Type.STRING },
    tieBreakerRule: { type: Type.STRING },
    criteria: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          weightPercent: { type: Type.NUMBER },
          description: { type: Type.STRING },
        },
        required: ['name', 'weightPercent', 'description'],
      },
    },
    restrictionsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    estimatedJudgingCost: { type: Type.NUMBER },
    rationale: { type: Type.STRING },
    sourceMessageIds: { type: Type.ARRAY, items: { type: Type.STRING } },
    appliedConstraintIds: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'totalTeams',
    'judgeCount',
    'parallelTracks',
    'judgingWindowMinutes',
    'minutesPerTeam',
    'formatDescription',
    'scoringProcedure',
    'tieBreakerRule',
    'criteria',
    'restrictionsRespected',
    'estimatedJudgingCost',
    'rationale',
    'sourceMessageIds',
    'appliedConstraintIds',
  ],
};

export async function runJudgingAgent(
  ctx: AgentContext,
  brief: CoordinationBrief,
  constraints: ExtractedConstraint[],
  extraDirective?: string
): Promise<JudgingPlan> {
  return tracedGenerateJson<JudgingPlan>({
    ...ctx,
    model: 'gemini-3.1-flash-lite',
    areaTag: 'judging',
    purpose: 'Judging Agent: Design feasible evaluation throughput & rubric for all teams',
    systemInstruction: `You are the Judging Planning Agent. Design a mathematically feasible judging workflow for totalTeams = ${brief.parameters.teams} within judgingWindowMinutes = ${brief.sharedScheduleWindows.judgingWindowMinutes}. CRITICAL MATH RULE: (parallelTracks * judgingWindowMinutes) MUST be >= (totalTeams * minutesPerTeam), judgeCount >= parallelTracks, and criteria weights MUST sum to exactly 100. Respect all judging/noise restrictions and budget target (${brief.sharedBudgetTargets.judgingTarget}). Cite ONLY active constraint/message IDs.${extraDirective ? `\n\nUPDATE DIRECTIVE: ${extraDirective}` : ''}`,
    contents: formatActiveContext('judging', brief, constraints),
    responseSchema: JUDGING_SCHEMA,
    thinkingLevel: ThinkingLevel.MINIMAL,
  });
}

const BUDGET_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    currency: { type: Type.STRING },
    budgetCap: { type: Type.NUMBER, nullable: true },
    totalEstimatedCost: { type: Type.NUMBER },
    remainingBuffer: { type: Type.NUMBER, nullable: true },
    areaTotals: {
      type: Type.OBJECT,
      properties: {
        venue: { type: Type.NUMBER },
        schedule: { type: Type.NUMBER },
        food: { type: Type.NUMBER },
        judging: { type: Type.NUMBER },
        operations: { type: Type.NUMBER },
        contingency: { type: Type.NUMBER },
      },
      required: ['venue', 'schedule', 'food', 'judging', 'operations', 'contingency'],
    },
    lineItems: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          area: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'operations', 'contingency'] },
          item: { type: Type.STRING },
          quantity: { type: Type.NUMBER },
          unitCost: { type: Type.NUMBER },
          totalCost: { type: Type.NUMBER },
          notes: { type: Type.STRING },
        },
        required: ['id', 'area', 'item', 'quantity', 'unitCost', 'totalCost', 'notes'],
      },
    },
    doubleCountingAudit: { type: Type.STRING },
    financialConstraintsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    rationale: { type: Type.STRING },
    sourceMessageIds: { type: Type.ARRAY, items: { type: Type.STRING } },
    appliedConstraintIds: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: [
    'currency',
    'totalEstimatedCost',
    'areaTotals',
    'lineItems',
    'doubleCountingAudit',
    'financialConstraintsRespected',
    'rationale',
    'sourceMessageIds',
    'appliedConstraintIds',
  ],
};

export async function runBudgetAgent(
  ctx: AgentContext,
  brief: CoordinationBrief,
  constraints: ExtractedConstraint[],
  areaOutputs: {
    venue: VenuePlan;
    schedule: SchedulePlan;
    food: FoodPlan;
    judging: JudgingPlan;
  },
  extraDirective?: string
): Promise<BudgetPlan> {
  const activeBudgetConstraints = constraints.filter(
    (c) => c.status === 'active' && (c.affectedAreas.includes('budget') || c.area === 'budget' || c.area === 'general')
  );

  const contents = JSON.stringify(
    {
      parameters: brief.parameters,
      sharedBudgetTargets: brief.sharedBudgetTargets,
      proposedAreaCosts: {
        venueCost: areaOutputs.venue.estimatedCost,
        venueName: areaOutputs.venue.venueName,
        foodCost: areaOutputs.food.totalFoodCost,
        foodItems: areaOutputs.food.items,
        judgingCost: areaOutputs.judging.estimatedJudgingCost,
      },
      activeBudgetConstraints: activeBudgetConstraints.map((c) => ({
        id: c.id,
        sourceMessageId: c.sourceMessageId,
        isHard: c.isHard,
        summary: c.summary,
        exactQuote: c.exactQuote,
      })),
    },
    null,
    2
  );

  return tracedGenerateJson<BudgetPlan>({
    ...ctx,
    model: 'gemini-3.1-flash-lite',
    areaTag: 'budget',
    purpose: 'Budget Agent: Consolidate all area costs, add ops/contingency, verify arithmetic & cap',
    systemInstruction: `You are the Budget & Financial Reconciliation Agent. Produce a mathematically exact, zero-double-counting budget in ${brief.parameters.currency}.
CRITICAL RULES:
1. Venue line items must sum to areaTotals.venue (= ${areaOutputs.venue.estimatedCost}).
2. Food line items must sum to areaTotals.food (= ${areaOutputs.food.totalFoodCost}).
3. Judging line items must sum to areaTotals.judging (= ${areaOutputs.judging.estimatedJudgingCost}).
4. Include required operational items (badges, lanyards, cables, first-aid, prizes if requested) in 'operations' and a contingency reserve in 'contingency'.
5. Every lineItem.totalCost = quantity * unitCost.
6. totalEstimatedCost MUST equal the exact sum of all lineItems[].totalCost AND the exact sum of areaTotals.
7. If budgetCap (${brief.parameters.budgetCap ?? 'none'}) is set, totalEstimatedCost MUST be <= budgetCap, and remainingBuffer = budgetCap - totalEstimatedCost.
8. Cite ONLY active constraint/message IDs.${extraDirective ? `\n\nUPDATE DIRECTIVE: ${extraDirective}` : ''}`,
    contents,
    responseSchema: BUDGET_SCHEMA,
    thinkingLevel: ThinkingLevel.MINIMAL,
  });
}

const INCREMENTAL_IMPACT_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    newMessageDispositions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          messageId: { type: Type.STRING },
          status: {
            type: Type.STRING,
            enum: ['accepted', 'partially_accepted', 'rejected', 'outdated', 'superseded', 'irrelevant'],
          },
          relevance: { type: Type.STRING, enum: ['relevant', 'irrelevant'] },
          language: { type: Type.STRING, enum: ['en', 'roman_urdu', 'mixed'] },
          senderOrSource: { type: Type.STRING },
          summary: { type: Type.STRING },
          reason: { type: Type.STRING },
          extractedFactCount: { type: Type.INTEGER },
          supersededByMessageId: { type: Type.STRING },
        },
        required: ['messageId', 'status', 'relevance', 'language', 'senderOrSource', 'summary', 'reason', 'extractedFactCount'],
      },
    },
    newConstraints: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          sourceMessageId: { type: Type.STRING },
          area: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'budget', 'general'] },
          affectedAreas: {
            type: Type.ARRAY,
            items: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'budget'] },
          },
          category: {
            type: Type.STRING,
            enum: ['hard', 'soft', 'numerical', 'temporal', 'conditional', 'dependency', 'prohibition', 'resource', 'cross_area'],
          },
          isHard: { type: Type.BOOLEAN },
          summary: { type: Type.STRING },
          exactQuote: { type: Type.STRING },
          language: { type: Type.STRING, enum: ['en', 'roman_urdu', 'mixed'] },
          authorityHint: {
            type: Type.STRING,
            enum: ['official_notice', 'lead_organizer', 'sponsor_or_venue', 'volunteer_or_student', 'casual_chat', 'unknown'],
          },
          status: { type: Type.STRING, enum: ['active', 'superseded', 'rejected', 'irrelevant', 'impossible'] },
          resolutionReason: { type: Type.STRING },
          supersededById: { type: Type.STRING },
        },
        required: [
          'id',
          'sourceMessageId',
          'area',
          'affectedAreas',
          'category',
          'isHard',
          'summary',
          'exactQuote',
          'language',
          'authorityHint',
          'status',
        ],
      },
    },
    updatedConstraintResolutions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          constraintId: { type: Type.STRING },
          status: { type: Type.STRING, enum: ['active', 'superseded', 'rejected', 'irrelevant', 'impossible'] },
          resolutionReason: { type: Type.STRING },
          supersededById: { type: Type.STRING },
        },
        required: ['constraintId', 'status', 'resolutionReason'],
      },
    },
    impossibleConflicts: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          areas: { type: Type.ARRAY, items: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'budget'] } },
          description: { type: Type.STRING },
          conflictingMessageIds: { type: Type.ARRAY, items: { type: Type.STRING } },
          resolutionStatus: { type: Type.STRING, enum: ['unresolved_impossible', 'resolved_with_tradeoff'] },
        },
        required: ['id', 'areas', 'description', 'conflictingMessageIds', 'resolutionStatus'],
      },
    },
    updatedParameters: {
      type: Type.OBJECT,
      properties: {
        eventType: { type: Type.STRING },
        location: { type: Type.STRING },
        durationMinutes: { type: Type.INTEGER },
        participants: { type: Type.INTEGER },
        teams: { type: Type.INTEGER },
        teamSize: { type: Type.INTEGER },
        currency: { type: Type.STRING },
        budgetCap: { type: Type.NUMBER, nullable: true },
        foodBudgetCap: { type: Type.NUMBER, nullable: true },
        venueNameOverride: { type: Type.STRING, nullable: true },
        dateHint: { type: Type.STRING, nullable: true },
        startTimeHint: { type: Type.STRING, nullable: true },
      },
      required: ['eventType', 'location', 'durationMinutes', 'participants', 'teams', 'teamSize', 'currency'],
    },
    affectedAreas: {
      type: Type.ARRAY,
      items: { type: Type.STRING, enum: ['venue', 'schedule', 'food', 'judging', 'budget'] },
    },
    impactReasoning: { type: Type.STRING },
    areaInstructions: {
      type: Type.OBJECT,
      properties: {
        venue: { type: Type.STRING },
        schedule: { type: Type.STRING },
        food: { type: Type.STRING },
        judging: { type: Type.STRING },
        budget: { type: Type.STRING },
      },
    },
  },
  required: [
    'newMessageDispositions',
    'newConstraints',
    'updatedConstraintResolutions',
    'impossibleConflicts',
    'updatedParameters',
    'affectedAreas',
    'impactReasoning',
    'areaInstructions',
  ],
};

export async function runIncrementalImpactAgent(
  ctx: AgentContext,
  newMessages: RawMessage[],
  existingConstraints: ExtractedConstraint[],
  existingPlan: HackathonPlan,
  nextConstraintIndex: number
): Promise<IncrementalImpactResult> {
  const systemInstruction = `You are the Incremental Update & Conflict Analysis Agent.
Read the NEW message(s) (English or Roman Urdu), extract new constraints starting at ID C${nextConstraintIndex}, compare them against existing active constraints and the current plan, and determine:
1. Whether the new message is accepted, rejected, outdated, superseded, or irrelevant (never blindly let the newest message win if it has lower authority or violates a hard rule!).
2. Which existing constraints (if any) are superseded by the new message.
3. Exactly which planning areas MUST be updated (preserve unaffected areas!).
4. If the new message is irrelevant or rejected, return affectedAreas: [] so zero unnecessary replanning occurs.
5. If a cost-bearing area (venue, food, judging) changes, include 'budget' in affectedAreas as well.`;

  const contents = JSON.stringify(
    {
      newMessages: newMessages.map((m) => ({ id: m.id, rawText: m.rawText })),
      existingActiveConstraints: existingConstraints.filter((c) => c.status === 'active'),
      currentPlanSummary: {
        parameters: existingPlan.parameters,
        venue: { name: existingPlan.venue.venueName, capacity: existingPlan.venue.capacity, cost: existingPlan.venue.estimatedCost },
        schedule: { totalMin: existingPlan.schedule.totalDurationMinutes, blocks: existingPlan.schedule.blocks.map((b) => `${b.title} (${b.startMinute}-${b.endMinute}m)`) },
        food: { servings: existingPlan.food.servingsPlanned, cost: existingPlan.food.totalFoodCost },
        judging: { teams: existingPlan.judging.totalTeams, judges: existingPlan.judging.judgeCount, tracks: existingPlan.judging.parallelTracks, minPerTeam: existingPlan.judging.minutesPerTeam, windowMin: existingPlan.judging.judgingWindowMinutes, cost: existingPlan.judging.estimatedJudgingCost },
        budget: { total: existingPlan.budget.totalEstimatedCost, cap: existingPlan.budget.budgetCap },
      },
    },
    null,
    2
  );

  return tracedGenerateJson<IncrementalImpactResult>({
    ...ctx,
    areaTag: 'reading',
    purpose: `Incremental Impact Agent: Analyze ${newMessages.length} new message(s) against existing plan`,
    systemInstruction,
    contents,
    responseSchema: INCREMENTAL_IMPACT_SCHEMA,
    thinkingLevel: ThinkingLevel.LOW,
  });
}

const CONSOLIDATED_MULTI_AREA_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    venue: VENUE_SCHEMA,
    schedule: SCHEDULE_SCHEMA,
    food: FOOD_SCHEMA,
    judging: JUDGING_SCHEMA,
  },
  required: ['venue', 'schedule', 'food', 'judging'],
};

export async function runConsolidatedAreaUpdateAgent(
  ctx: AgentContext,
  primaryArea: PlanningArea,
  brief: CoordinationBrief,
  constraints: ExtractedConstraint[],
  currentPlan: HackathonPlan,
  impactReasoning: string
): Promise<{ venue: VenuePlan; schedule: SchedulePlan; food: FoodPlan; judging: JudgingPlan }> {
  const active = constraints.filter((c) => c.status === 'active');
  return tracedGenerateJson<{ venue: VenuePlan; schedule: SchedulePlan; food: FoodPlan; judging: JudgingPlan }>({
    ...ctx,
    model: 'gemini-3.1-flash-lite',
    areaTag: primaryArea,
    purpose: `Consolidated Multi-Area Update: Re-plan impacted operational areas within 5-call limit`,
    systemInstruction: `You are executing a consolidated multi-area incremental update (to stay strictly within the 5-model-call budget). Preserve all unaffected decisions from currentPlan, and update only the areas impacted by the new constraint(s). Respect every hard constraint and mathematical rule across Venue, Schedule, Food, and Judging. Cite ONLY active constraint/message IDs.`,
    contents: JSON.stringify(
      {
        impactReasoning,
        updatedParameters: brief.parameters,
        activeConstraints: active,
        currentPlan: {
          venue: currentPlan.venue,
          schedule: currentPlan.schedule,
          food: currentPlan.food,
          judging: currentPlan.judging,
        },
      },
      null,
      2
    ),
    responseSchema: CONSOLIDATED_MULTI_AREA_SCHEMA,
    thinkingLevel: ThinkingLevel.MINIMAL,
  });
}
