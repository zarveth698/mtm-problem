import fs from 'fs';
import path from 'path';
import type { WorkspaceState } from '../core/types';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');
const SAMPLE_PACK_PATH = path.join(DATA_DIR, 'sample_pack.txt');

export function createEmptyState(): WorkspaceState {
  return {
    messages: [],
    dispositions: [],
    constraints: [],
    impossibleConflicts: [],
    plan: null,
    validation: null,
    executionTrace: [],
    updateHistory: [],
    lastRunDurationMs: null,
    status: 'idle',
    errorMessage: null,
  };
}

export function loadState(): WorkspaceState {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(STORE_PATH)) {
      const empty = createEmptyState();
      fs.writeFileSync(STORE_PATH, JSON.stringify(empty, null, 2), 'utf8');
      return empty;
    }
    const raw = fs.readFileSync(STORE_PATH, 'utf8');
    const parsed = JSON.parse(raw) as WorkspaceState;
    return {
      ...createEmptyState(),
      ...parsed,
    };
  } catch {
    return createEmptyState();
  }
}

export function saveState(state: WorkspaceState): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpPath = `${STORE_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(state, null, 2), 'utf8');
  fs.renameSync(tmpPath, STORE_PATH);
}

export function resetState(): WorkspaceState {
  const empty = createEmptyState();
  saveState(empty);
  return empty;
}

export function readSamplePackFile(): string {
  if (!fs.existsSync(SAMPLE_PACK_PATH)) {
    throw new Error('Sample message pack file not found at data/sample_pack.txt');
  }
  return fs.readFileSync(SAMPLE_PACK_PATH, 'utf8');
}
