export type PlanningArea = 'venue' | 'schedule' | 'food' | 'judging' | 'budget';
export type TraceAreaTag = 'reading' | PlanningArea;

export type ConstraintCategory =
  | 'hard'
  | 'soft'
  | 'numerical'
  | 'temporal'
  | 'conditional'
  | 'dependency'
  | 'prohibition'
  | 'resource'
  | 'cross_area';

export type MessageDispositionStatus =
  | 'accepted'
  | 'partially_accepted'
  | 'rejected'
  | 'outdated'
  | 'superseded'
  | 'irrelevant';

export interface RawMessage {
  id: string;
  order: number;
  rawText: string;
  sourceLabel?: string;
  batchId: string;
  ingestedAt: string;
}

export interface ExtractedConstraint {
  id: string;
  sourceMessageId: string;
  area: PlanningArea | 'general';
  affectedAreas: PlanningArea[];
  category: ConstraintCategory;
  isHard: boolean;
  summary: string;
  exactQuote: string;
  language: 'en' | 'roman_urdu' | 'mixed';
  authorityHint: 'official_notice' | 'lead_organizer' | 'sponsor_or_venue' | 'volunteer_or_student' | 'casual_chat' | 'unknown';
  timestampHint?: string;
  status: 'active' | 'superseded' | 'rejected' | 'irrelevant' | 'impossible';
  resolutionReason?: string;
  supersededById?: string;
}

export interface MessageDisposition {
  messageId: string;
  status: MessageDispositionStatus;
  relevance: 'relevant' | 'irrelevant';
  language: 'en' | 'roman_urdu' | 'mixed';
  senderOrSource: string;
  summary: string;
  reason: string;
  extractedFactCount: number;
  supersededByMessageId?: string;
}

export interface EventParameters {
  eventType: string;
  location: string;
  durationMinutes: number;
  participants: number;
  teams: number;
  teamSize: number;
  currency: string;
  budgetCap: number | null;
  foodBudgetCap: number | null;
  venueNameOverride: string | null;
  dateHint: string | null;
  startTimeHint: string | null;
}

export interface ImpossibleConflict {
  id: string;
  areas: PlanningArea[];
  description: string;
  conflictingMessageIds: string[];
  resolutionStatus: 'unresolved_impossible' | 'resolved_with_tradeoff';
}

export interface VenuePlan {
  venueName: string;
  addressOrSector: string;
  capacity: number;
  teamTables: number;
  seatsPerTable: number;
  facilities: string[];
  accessibilityNotes: string;
  restrictionsRespected: string[];
  seatingArrangement: string;
  estimatedCost: number;
  rationale: string;
  sourceMessageIds: string[];
  appliedConstraintIds: string[];
}

export interface ScheduleBlock {
  id: string;
  title: string;
  phase: 'registration' | 'opening' | 'hacking' | 'food' | 'judging' | 'closing' | 'buffer';
  startMinute: number;
  endMinute: number;
  clockTimeRange: string;
  description: string;
  allowParallel: boolean;
  dependencies: string[];
}

export interface SchedulePlan {
  totalDurationMinutes: number;
  startTime: string;
  endTime: string;
  blocks: ScheduleBlock[];
  constraintsRespected: string[];
  rationale: string;
  sourceMessageIds: string[];
  appliedConstraintIds: string[];
}

export interface FoodItem {
  name: string;
  category: 'meal' | 'snack' | 'beverage' | 'dietary_special';
  quantity: number;
  unit: string;
  unitCost: number;
  totalCost: number;
  notes: string;
}

export interface FoodPlan {
  servingsPlanned: number;
  dietaryAccommodations: string[];
  prohibitionsRespected: string[];
  distributionStrategy: string;
  distributionWindow: string;
  items: FoodItem[];
  totalFoodCost: number;
  rationale: string;
  sourceMessageIds: string[];
  appliedConstraintIds: string[];
}

export interface JudgingCriterion {
  name: string;
  weightPercent: number;
  description: string;
}

export interface JudgingPlan {
  totalTeams: number;
  judgeCount: number;
  parallelTracks: number;
  judgingWindowMinutes: number;
  minutesPerTeam: number;
  formatDescription: string;
  scoringProcedure: string;
  tieBreakerRule: string;
  criteria: JudgingCriterion[];
  restrictionsRespected: string[];
  estimatedJudgingCost: number;
  rationale: string;
  sourceMessageIds: string[];
  appliedConstraintIds: string[];
}

export interface BudgetLineItem {
  id: string;
  area: PlanningArea | 'operations' | 'contingency';
  item: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  notes: string;
}

export interface BudgetPlan {
  currency: string;
  budgetCap: number | null;
  totalEstimatedCost: number;
  remainingBuffer: number | null;
  areaTotals: {
    venue: number;
    schedule: number;
    food: number;
    judging: number;
    operations: number;
    contingency: number;
  };
  lineItems: BudgetLineItem[];
  doubleCountingAudit: string;
  financialConstraintsRespected: string[];
  rationale: string;
  sourceMessageIds: string[];
  appliedConstraintIds: string[];
}

export interface HackathonPlan {
  version: number;
  generatedAt: string;
  parameters: EventParameters;
  venue: VenuePlan;
  schedule: SchedulePlan;
  food: FoodPlan;
  judging: JudgingPlan;
  budget: BudgetPlan;
  coordinationNotes: string[];
}

export interface ValidationCheckItem {
  id: string;
  label: string;
  area: PlanningArea | 'general';
  passed: boolean;
  severity: 'hard' | 'warning';
  details: string;
}

export interface ValidationReport {
  isValid: boolean;
  checkedAt: string;
  summary: string;
  checks: ValidationCheckItem[];
}

export interface ExecutionTraceEntry {
  callNumber: number;
  runId: string;
  runType: 'initial' | 'incremental_update';
  model: string;
  areaTag: TraceAreaTag;
  purpose: string;
  isRetry: boolean;
  input: string;
  output: string;
  inputTokens: number | null;
  outputTokens: number | null;
  totalTokens: number | null;
  tokenAvailability: 'reported' | 'unavailable';
  durationMs: number;
  timestamp: string;
}

export interface PlanFieldChange {
  area: PlanningArea | 'general';
  field: string;
  before: string;
  after: string;
  reason: string;
}

export interface PlanDiff {
  affectedAreas: PlanningArea[];
  changes: PlanFieldChange[];
  summary: string;
}

export interface UpdateHistoryEntry {
  id: string;
  timestamp: string;
  newMessageIds: string[];
  rawInputPreview: string;
  affectedAreas: PlanningArea[];
  modelCallsUsed: number;
  durationMs: number;
  reasoning: string;
  diff: PlanDiff;
}

export interface WorkspaceState {
  messages: RawMessage[];
  dispositions: MessageDisposition[];
  constraints: ExtractedConstraint[];
  impossibleConflicts: ImpossibleConflict[];
  plan: HackathonPlan | null;
  validation: ValidationReport | null;
  executionTrace: ExecutionTraceEntry[];
  updateHistory: UpdateHistoryEntry[];
  lastRunDurationMs: number | null;
  status: 'idle' | 'running' | 'completed' | 'completed_with_warnings' | 'impossible' | 'error';
  errorMessage: string | null;
}

export interface PipelineProgressEvent {
  type: 'step' | 'trace' | 'complete' | 'error';
  stepId?: string;
  label?: string;
  areaTag?: TraceAreaTag;
  status?: 'pending' | 'running' | 'completed' | 'failed';
  detail?: string;
  traceEntry?: ExecutionTraceEntry;
  state?: WorkspaceState;
  error?: string;
}
