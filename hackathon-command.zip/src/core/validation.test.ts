import test from 'node:test';
import assert from 'node:assert/strict';
import { computePlanDiff, summarizeTokens, validatePlanDeterministically } from './validation';
import type { ExtractedConstraint, HackathonPlan, MessageDisposition } from './types';

function makeValidPlan(): HackathonPlan {
  return {
    version: 1,
    generatedAt: '2026-11-18T00:00:00.000Z',
    parameters: {
      eventType: 'Physical Hackathon',
      location: 'Islamabad, Pakistan',
      durationMinutes: 240,
      participants: 150,
      teams: 50,
      teamSize: 3,
      currency: 'PKR',
      budgetCap: 220000,
      foodBudgetCap: 75000,
      venueNameOverride: null,
      dateHint: null,
      startTimeHint: '10:00 AM',
    },
    venue: {
      venueName: 'Multipurpose Innovation Hall',
      addressOrSector: 'Sector H-11/4, Islamabad',
      capacity: 200,
      teamTables: 55,
      seatsPerTable: 3,
      facilities: ['Wi-Fi', 'Power Strips', 'Projectors', 'Backup Generator'],
      accessibilityNotes: 'Wheelchair ramp at East Gate',
      restrictionsRespected: ['No food at coding tables'],
      seatingArrangement: '50 team tables of 3 + 5 buffer tables',
      estimatedCost: 60000,
      rationale: 'Meets 150 participant capacity.',
      sourceMessageIds: ['M4'],
      appliedConstraintIds: ['C4'],
    },
    schedule: {
      totalDurationMinutes: 240,
      startTime: '10:00 AM',
      endTime: '2:00 PM',
      blocks: [
        {
          id: 'S1',
          title: 'Registration & Opening',
          phase: 'registration',
          startMinute: 0,
          endMinute: 15,
          clockTimeRange: '10:00 - 10:15 AM',
          description: 'Check-in & kickoff',
          allowParallel: false,
          dependencies: [],
        },
        {
          id: 'S2',
          title: 'Core Hacking Sprint',
          phase: 'hacking',
          startMinute: 15,
          endMinute: 170,
          clockTimeRange: '10:15 AM - 12:50 PM',
          description: '155 minutes uninterrupted build',
          allowParallel: false,
          dependencies: ['S1'],
        },
        {
          id: 'S3',
          title: 'Courtyard Lunch Break',
          phase: 'food',
          startMinute: 170,
          endMinute: 190,
          clockTimeRange: '12:50 - 1:10 PM',
          description: 'Boxed lunch in Atrium',
          allowParallel: false,
          dependencies: ['S2'],
        },
        {
          id: 'S4',
          title: 'Parallel Judging',
          phase: 'judging',
          startMinute: 190,
          endMinute: 230,
          clockTimeRange: '1:10 - 1:50 PM',
          description: '5 tracks evaluating 10 teams each',
          allowParallel: false,
          dependencies: ['S2'],
        },
        {
          id: 'S5',
          title: 'Awards & Closing',
          phase: 'closing',
          startMinute: 230,
          endMinute: 240,
          clockTimeRange: '1:50 - 2:00 PM',
          description: 'Winner announcement',
          allowParallel: false,
          dependencies: ['S4'],
        },
      ],
      constraintsRespected: ['4 hour duration 10:00 AM - 2:00 PM'],
      rationale: 'Fits 240 minutes cleanly.',
      sourceMessageIds: ['M8', 'M10'],
      appliedConstraintIds: ['C8', 'C10'],
    },
    food: {
      servingsPlanned: 150,
      dietaryAccommodations: ['100% Halal', '20 Vegetarian boxes'],
      prohibitionsRespected: ['Served only in Courtyard Atrium'],
      distributionStrategy: 'Pre-packed boxes distributed in Atrium',
      distributionWindow: '12:50 - 1:10 PM',
      items: [
        { name: 'Halal Chicken Box', category: 'meal', quantity: 130, unit: 'box', unitCost: 420, totalCost: 54600, notes: '' },
        { name: 'Vegetarian Box', category: 'dietary_special', quantity: 20, unit: 'box', unitCost: 400, totalCost: 8000, notes: '' },
        { name: 'Bottled Water', category: 'beverage', quantity: 150, unit: 'bottle', unitCost: 40, totalCost: 6000, notes: '' },
        { name: 'Serving Setup', category: 'snack', quantity: 1, unit: 'flat', unitCost: 3500, totalCost: 3500, notes: '' },
      ],
      totalFoodCost: 72100,
      rationale: 'Stays under 75,000 PKR food cap.',
      sourceMessageIds: ['M6', 'M9'],
      appliedConstraintIds: ['C6', 'C9'],
    },
    judging: {
      totalTeams: 50,
      judgeCount: 6,
      parallelTracks: 5,
      judgingWindowMinutes: 40,
      minutesPerTeam: 4,
      formatDescription: '5 parallel tracks, 10 teams each, 4 min/team',
      scoringProcedure: 'Digital rubric weighted 100%',
      tieBreakerRule: '6th floating judge resolves ties',
      criteria: [
        { name: 'Technical Execution', weightPercent: 35, description: '' },
        { name: 'Innovation', weightPercent: 30, description: '' },
        { name: 'Completeness', weightPercent: 20, description: '' },
        { name: 'Pitch Clarity', weightPercent: 15, description: '' },
      ],
      restrictionsRespected: ['No loud speakers in Corridor B'],
      estimatedJudgingCost: 18000,
      rationale: '5 * 40 = 200 team-minutes == 50 * 4.',
      sourceMessageIds: ['M7'],
      appliedConstraintIds: ['C7'],
    },
    budget: {
      currency: 'PKR',
      budgetCap: 220000,
      totalEstimatedCost: 212100,
      remainingBuffer: 7900,
      areaTotals: {
        venue: 60000,
        schedule: 0,
        food: 72100,
        judging: 18000,
        operations: 52000,
        contingency: 10000,
      },
      lineItems: [
        { id: 'B1', area: 'venue', item: 'Hall Rental', quantity: 1, unitCost: 60000, totalCost: 60000, notes: '' },
        { id: 'B2', area: 'food', item: 'Catering & Water', quantity: 1, unitCost: 72100, totalCost: 72100, notes: '' },
        { id: 'B3', area: 'judging', item: 'Judges & Certificates', quantity: 1, unitCost: 18000, totalCost: 18000, notes: '' },
        { id: 'B4', area: 'operations', item: 'Badges, Cables & Prizes', quantity: 1, unitCost: 52000, totalCost: 52000, notes: '' },
        { id: 'B5', area: 'contingency', item: 'Contingency Reserve', quantity: 1, unitCost: 10000, totalCost: 10000, notes: '' },
      ],
      doubleCountingAudit: 'All items mapped uniquely to one area.',
      financialConstraintsRespected: ['Total <= 220,000 PKR'],
      rationale: 'Mathematically consistent.',
      sourceMessageIds: ['M6', 'M10'],
      appliedConstraintIds: ['C6', 'C10'],
    },
    coordinationNotes: ['Schedule and judging windows aligned.'],
  };
}

test('validates a fully compliant hackathon plan', () => {
  const plan = makeValidPlan();
  const constraints: ExtractedConstraint[] = [
    {
      id: 'C1',
      sourceMessageId: 'M1',
      area: 'venue',
      affectedAreas: ['venue'],
      category: 'numerical',
      isHard: true,
      summary: 'Old 120-cap auditorium',
      exactQuote: '120 people',
      language: 'en',
      authorityHint: 'official_notice',
      status: 'rejected',
    },
  ];
  const dispositions: MessageDisposition[] = [
    {
      messageId: 'M1',
      status: 'rejected',
      relevance: 'relevant',
      language: 'en',
      senderOrSource: 'Admin',
      summary: 'Auditorium too small',
      reason: '120 < 150',
      extractedFactCount: 1,
    },
  ];

  const report = validatePlanDeterministically(plan, constraints, dispositions);
  assert.equal(report.isValid, true);
  assert.equal(report.checks.every((c) => c.passed), true);
});

test('catches budget over-cap, schedule overflow, and leaked rejected message', () => {
  const plan = makeValidPlan();
  plan.budget.totalEstimatedCost = 260000;
  plan.schedule.blocks[4].endMinute = 255;
  plan.venue.sourceMessageIds.push('M1');

  const dispositions: MessageDisposition[] = [
    {
      messageId: 'M1',
      status: 'rejected',
      relevance: 'relevant',
      language: 'en',
      senderOrSource: 'Admin',
      summary: 'Auditorium rejected',
      reason: 'Capacity too small',
      extractedFactCount: 1,
    },
  ];

  const report = validatePlanDeterministically(plan, [], dispositions);
  assert.equal(report.isValid, false);
  const failedIds = report.checks.filter((c) => !c.passed).map((c) => c.id);
  assert.ok(failedIds.includes('budget_math_and_cap'));
  assert.ok(failedIds.includes('schedule_duration_and_overlaps'));
  assert.ok(failedIds.includes('no_rejected_influence'));
});

test('computes diff accurately between old and updated plan', () => {
  const oldPlan = makeValidPlan();
  const newPlan = makeValidPlan();
  newPlan.budget.totalEstimatedCost = 205000;
  newPlan.food.totalFoodCost = 65000;

  const diff = computePlanDiff(oldPlan, newPlan);
  assert.ok(diff.affectedAreas.includes('food'));
  assert.ok(diff.affectedAreas.includes('budget'));
  assert.ok(!diff.affectedAreas.includes('venue'));
  assert.equal(diff.changes.length, 2);
});

test('summarizes token usage and tracks unavailable metadata honestly', () => {
  const summary = summarizeTokens([
    {
      callNumber: 1,
      runId: 'r1',
      runType: 'initial',
      model: 'gemini-4-hydrogen',
      areaTag: 'reading',
      purpose: 'Read',
      isRetry: false,
      input: 'in',
      output: 'out',
      inputTokens: 100,
      outputTokens: 50,
      totalTokens: 150,
      tokenAvailability: 'reported',
      durationMs: 500,
      timestamp: '2026-11-18T00:00:00.000Z',
    },
    {
      callNumber: 2,
      runId: 'r1',
      runType: 'initial',
      model: 'gemini-4-hydrogen',
      areaTag: 'venue',
      purpose: 'Venue',
      isRetry: false,
      input: 'in',
      output: 'out',
      inputTokens: null,
      outputTokens: null,
      totalTokens: null,
      tokenAvailability: 'unavailable',
      durationMs: 400,
      timestamp: '2026-11-18T00:00:01.000Z',
    },
  ]);
  assert.equal(summary.totalCalls, 2);
  assert.equal(summary.inputTokens, 100);
  assert.equal(summary.outputTokens, 50);
  assert.equal(summary.totalTokens, 150);
  assert.equal(summary.unavailableCount, 1);
});
