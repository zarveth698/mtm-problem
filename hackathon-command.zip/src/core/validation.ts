import type {
  ExecutionTraceEntry,
  ExtractedConstraint,
  HackathonPlan,
  MessageDisposition,
  PlanDiff,
  PlanFieldChange,
  PlanningArea,
  ValidationCheckItem,
  ValidationReport,
} from './types';

export function validatePlanDeterministically(
  plan: HackathonPlan,
  constraints: ExtractedConstraint[],
  dispositions: MessageDisposition[]
): ValidationReport {
  const checks: ValidationCheckItem[] = [];

  const targetParticipants = plan.parameters.participants;
  const targetTeams = plan.parameters.teams;
  const targetDuration = plan.parameters.durationMinutes;

  // 1. Participant & Team baseline checks
  checks.push({
    id: 'participants_accounted',
    label: 'Participant Count Accounted',
    area: 'general',
    passed: targetParticipants > 0 && plan.food.servingsPlanned >= targetParticipants && plan.venue.capacity >= targetParticipants,
    severity: 'hard',
    details: `Target: ${targetParticipants} students. Venue capacity: ${plan.venue.capacity}, Food servings: ${plan.food.servingsPlanned}.`,
  });

  checks.push({
    id: 'teams_accounted',
    label: 'Team Count & Seating Accounted',
    area: 'general',
    passed:
      targetTeams > 0 &&
      plan.venue.teamTables >= targetTeams &&
      plan.judging.totalTeams === targetTeams,
    severity: 'hard',
    details: `Target: ${targetTeams} teams (${plan.parameters.teamSize}/team). Venue team tables: ${plan.venue.teamTables}, Judging teams: ${plan.judging.totalTeams}.`,
  });

  // 2. Duration & Schedule timing check
  const blocks = [...plan.schedule.blocks].sort((a, b) => a.startMinute - b.startMinute);
  let scheduleOverlapError: string | null = null;
  let scheduleBoundsError: string | null = null;

  for (let i = 0; i < blocks.length; i++) {
    const b = blocks[i];
    if (b.startMinute < 0 || b.endMinute <= b.startMinute || b.endMinute > targetDuration) {
      scheduleBoundsError = `Block "${b.title}" (${b.startMinute}-${b.endMinute}m) exceeds 0-${targetDuration}m window.`;
      break;
    }
    for (let j = i + 1; j < blocks.length; j++) {
      const next = blocks[j];
      if (next.startMinute < b.endMinute && !(b.allowParallel && next.allowParallel)) {
        scheduleOverlapError = `Blocks "${b.title}" (${b.startMinute}-${b.endMinute}m) and "${next.title}" (${next.startMinute}-${next.endMinute}m) overlap without parallel flag.`;
        break;
      }
    }
    if (scheduleOverlapError) break;
  }

  const maxEnd = blocks.reduce((acc, b) => Math.max(acc, b.endMinute), 0);
  const scheduleFits =
    plan.schedule.totalDurationMinutes === targetDuration &&
    maxEnd <= targetDuration &&
    maxEnd > 0 &&
    !scheduleBoundsError &&
    !scheduleOverlapError;

  checks.push({
    id: 'schedule_duration_and_overlaps',
    label: '4-Hour Schedule Integrity',
    area: 'schedule',
    passed: scheduleFits,
    severity: 'hard',
    details: scheduleBoundsError || scheduleOverlapError || `Schedule covers 0–${maxEnd}m out of ${targetDuration}m target across ${blocks.length} blocks.`,
  });

  // 3. Venue capacity check
  checks.push({
    id: 'venue_capacity',
    label: 'Venue Capacity & Location',
    area: 'venue',
    passed:
      Boolean(plan.venue.venueName.trim()) &&
      plan.venue.capacity >= targetParticipants &&
      plan.venue.teamTables >= targetTeams,
    severity: 'hard',
    details: `${plan.venue.venueName} (${plan.venue.addressOrSector}) · Capacity ${plan.venue.capacity} >= ${targetParticipants}, Tables ${plan.venue.teamTables} >= ${targetTeams}.`,
  });

  // 4. Food quantities & math check
  const foodItemsSum = plan.food.items.reduce((acc, item) => acc + item.totalCost, 0);
  const foodCapOk =
    plan.parameters.foodBudgetCap == null || plan.food.totalFoodCost <= plan.parameters.foodBudgetCap;

  checks.push({
    id: 'food_adequacy',
    label: 'Food Quantity & Dietary Coverage',
    area: 'food',
    passed:
      plan.food.servingsPlanned >= targetParticipants &&
      plan.food.items.length > 0 &&
      Math.abs(foodItemsSum - plan.food.totalFoodCost) <= 5 &&
      foodCapOk,
    severity: 'hard',
    details: `Servings: ${plan.food.servingsPlanned}/${targetParticipants}. Items sum: ${foodItemsSum} vs reported ${plan.food.totalFoodCost}${plan.parameters.foodBudgetCap != null ? ` (cap ${plan.parameters.foodBudgetCap})` : ''}.`,
  });

  // 5. Judging feasibility math check
  const rubricSum = plan.judging.criteria.reduce((acc, c) => acc + c.weightPercent, 0);
  const requiredTeamMinutes = plan.judging.totalTeams * plan.judging.minutesPerTeam;
  const availableJudgeTrackMinutes = plan.judging.judgingWindowMinutes * plan.judging.parallelTracks;
  const judgingFeasible =
    plan.judging.totalTeams === targetTeams &&
    plan.judging.judgeCount >= plan.judging.parallelTracks &&
    plan.judging.minutesPerTeam > 0 &&
    availableJudgeTrackMinutes >= requiredTeamMinutes &&
    Math.abs(rubricSum - 100) <= 0.5;

  checks.push({
    id: 'judging_feasibility',
    label: 'Judging Throughput & Rubric Math',
    area: 'judging',
    passed: judgingFeasible,
    severity: 'hard',
    details: `Capacity: ${plan.judging.parallelTracks} tracks × ${plan.judging.judgingWindowMinutes}m = ${availableJudgeTrackMinutes} team-min >= ${requiredTeamMinutes} needed (${plan.judging.totalTeams} teams × ${plan.judging.minutesPerTeam}m). Rubric sum: ${rubricSum}%.`,
  });

  // 6. Budget math & funding cap check
  const lineItemSum = plan.budget.lineItems.reduce((acc, li) => acc + li.totalCost, 0);
  const areaSum =
    plan.budget.areaTotals.venue +
    plan.budget.areaTotals.schedule +
    plan.budget.areaTotals.food +
    plan.budget.areaTotals.judging +
    plan.budget.areaTotals.operations +
    plan.budget.areaTotals.contingency;
  const budgetCapOk =
    plan.budget.budgetCap == null || plan.budget.totalEstimatedCost <= plan.budget.budgetCap;
  const mathConsistent =
    Math.abs(lineItemSum - plan.budget.totalEstimatedCost) <= 5 &&
    Math.abs(areaSum - plan.budget.totalEstimatedCost) <= 5;

  checks.push({
    id: 'budget_math_and_cap',
    label: 'Budget Arithmetic & Funding Cap',
    area: 'budget',
    passed: mathConsistent && budgetCapOk && plan.budget.lineItems.length > 0,
    severity: 'hard',
    details: `Line items: ${lineItemSum.toLocaleString()}, Area sum: ${areaSum.toLocaleString()}, Total: ${plan.budget.totalEstimatedCost.toLocaleString()} ${plan.budget.currency}${plan.budget.budgetCap != null ? ` / Cap ${plan.budget.budgetCap.toLocaleString()}` : ''}.`,
  });

  // 7. Rejected / outdated / irrelevant leakage check
  const blockedMessageIds = new Set(
    dispositions
      .filter((d) => d.status === 'rejected' || d.status === 'outdated' || d.status === 'superseded' || d.status === 'irrelevant')
      .map((d) => d.messageId)
  );
  const blockedConstraintIds = new Set(
    constraints
      .filter((c) => c.status === 'rejected' || c.status === 'superseded' || c.status === 'irrelevant')
      .map((c) => c.id)
  );

  const areaPlans = [plan.venue, plan.schedule, plan.food, plan.judging, plan.budget];
  const leakedConstraints = areaPlans.flatMap((ap) =>
    ap.appliedConstraintIds.filter((cid) => blockedConstraintIds.has(cid))
  );
  const leakedMessages = areaPlans.flatMap((ap) =>
    ap.sourceMessageIds.filter((mid) => blockedMessageIds.has(mid))
  );

  checks.push({
    id: 'no_rejected_influence',
    label: 'Outdated & Rejected Info Isolation',
    area: 'general',
    passed: leakedConstraints.length === 0 && leakedMessages.length === 0,
    severity: 'hard',
    details:
      leakedConstraints.length === 0 && leakedMessages.length === 0
        ? `Zero rejected, outdated, or irrelevant sources referenced in final plan.`
        : `Detected leaked references: constraints [${leakedConstraints.join(', ')}], messages [${leakedMessages.join(', ')}].`,
  });

  const isValid = checks.every((c) => c.passed || c.severity !== 'hard');

  return {
    isValid,
    checkedAt: new Date().toISOString(),
    summary: isValid
      ? `All ${checks.length} deterministic checks passed across all 5 planning areas.`
      : `${checks.filter((c) => !c.passed).length} validation check(s) require attention.`,
    checks,
  };
}

export function computePlanDiff(
  oldPlan: HackathonPlan | null,
  newPlan: HackathonPlan,
  reasoningMap?: Partial<Record<PlanningArea | 'general', string>>
): PlanDiff {
  if (!oldPlan) {
    return {
      affectedAreas: ['venue', 'schedule', 'food', 'judging', 'budget'],
      changes: [
        {
          area: 'general',
          field: 'Initial Plan',
          before: 'None',
          after: `${newPlan.venue.venueName} · ${newPlan.budget.totalEstimatedCost.toLocaleString()} ${newPlan.budget.currency}`,
          reason: 'Initial plan generated.',
        },
      ],
      summary: 'Generated initial full hackathon plan.',
    };
  }

  const changes: PlanFieldChange[] = [];
  const affectedSet = new Set<PlanningArea>();

  const addChange = (area: PlanningArea | 'general', field: string, before: string, after: string) => {
    if (before !== after) {
      if (area !== 'general') affectedSet.add(area);
      changes.push({
        area,
        field,
        before,
        after,
        reason: reasoningMap?.[area] ?? 'Updated based on incremental message constraints.',
      });
    }
  };

  addChange('general', 'Participants', String(oldPlan.parameters.participants), String(newPlan.parameters.participants));
  addChange('general', 'Teams', String(oldPlan.parameters.teams), String(newPlan.parameters.teams));
  addChange('general', 'Duration (min)', String(oldPlan.parameters.durationMinutes), String(newPlan.parameters.durationMinutes));

  addChange('venue', 'Selected Venue', oldPlan.venue.venueName, newPlan.venue.venueName);
  addChange('venue', 'Capacity', String(oldPlan.venue.capacity), String(newPlan.venue.capacity));
  addChange('venue', 'Venue Cost', String(oldPlan.venue.estimatedCost), String(newPlan.venue.estimatedCost));
  addChange('venue', 'Seating Arrangement', oldPlan.venue.seatingArrangement, newPlan.venue.seatingArrangement);

  const oldScheduleSig = oldPlan.schedule.blocks.map((b) => `${b.title} (${b.startMinute}-${b.endMinute}m)`).join(' → ');
  const newScheduleSig = newPlan.schedule.blocks.map((b) => `${b.title} (${b.startMinute}-${b.endMinute}m)`).join(' → ');
  addChange('schedule', 'Timeline Blocks', oldScheduleSig, newScheduleSig);

  addChange('food', 'Servings Planned', String(oldPlan.food.servingsPlanned), String(newPlan.food.servingsPlanned));
  addChange('food', 'Food Menu', oldPlan.food.items.map((i) => `${i.quantity}× ${i.name}`).join(', '), newPlan.food.items.map((i) => `${i.quantity}× ${i.name}`).join(', '));
  addChange('food', 'Food Total Cost', String(oldPlan.food.totalFoodCost), String(newPlan.food.totalFoodCost));

  addChange('judging', 'Judges & Tracks', `${oldPlan.judging.judgeCount} judges / ${oldPlan.judging.parallelTracks} tracks`, `${newPlan.judging.judgeCount} judges / ${newPlan.judging.parallelTracks} tracks`);
  addChange('judging', 'Time Per Team', `${oldPlan.judging.minutesPerTeam}m (${oldPlan.judging.judgingWindowMinutes}m window)`, `${newPlan.judging.minutesPerTeam}m (${newPlan.judging.judgingWindowMinutes}m window)`);
  addChange('judging', 'Judging Cost', String(oldPlan.judging.estimatedJudgingCost), String(newPlan.judging.estimatedJudgingCost));

  addChange('budget', 'Total Estimated Cost', `${oldPlan.budget.totalEstimatedCost.toLocaleString()} ${oldPlan.budget.currency}`, `${newPlan.budget.totalEstimatedCost.toLocaleString()} ${newPlan.budget.currency}`);
  addChange('budget', 'Budget Cap', String(oldPlan.budget.budgetCap ?? 'None'), String(newPlan.budget.budgetCap ?? 'None'));

  return {
    affectedAreas: Array.from(affectedSet),
    changes,
    summary:
      changes.length === 0
        ? 'No plan changes were needed; new message was informational, redundant, or rejected.'
        : `Updated ${changes.length} field(s) across ${affectedSet.size || 1} area(s).`,
  };
}

export function summarizeTokens(trace: ExecutionTraceEntry[]) {
  let inputTokens = 0;
  let outputTokens = 0;
  let totalTokens = 0;
  let unavailableCount = 0;

  for (const entry of trace) {
    if (entry.inputTokens == null || entry.outputTokens == null || entry.totalTokens == null) {
      unavailableCount++;
    } else {
      inputTokens += entry.inputTokens;
      outputTokens += entry.outputTokens;
      totalTokens += entry.totalTokens;
    }
  }

  return {
    totalCalls: trace.length,
    inputTokens,
    outputTokens,
    totalTokens,
    unavailableCount,
  };
}
