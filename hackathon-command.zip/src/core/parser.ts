import type { RawMessage } from './types';

/**
 * Parses an arbitrary raw .txt message pack into individual RawMessage objects
 * without hardcoding content rules or pre-classifying messages.
 *
 * Supported formats in unseen message packs:
 * 1. Explicit separator lines (e.g. `---`, `===`, `***`)
 * 2. Numbered/tagged markers (e.g. `[MSG 1]`, `Message 1:`, `MSG 01:`, `#1`)
 * 3. WhatsApp-style timestamped lines (e.g. `[12/11/2026, 10:15] Ali:` or `12/11/2026, 10:15 AM - Sara:`)
 * 4. Email headers (`From:` / `Subject:`)
 * 5. Fallback: double-newline-separated message blocks
 */
export function parseMessagePackText(
  rawText: string,
  options?: { startingIndex?: number; batchId?: string; ingestedAt?: string }
): RawMessage[] {
  const normalized = rawText.replace(/\r\n/g, '\n').trim();
  if (!normalized) {
    return [];
  }

  const startingIndex = options?.startingIndex ?? 1;
  const batchId = options?.batchId ?? `batch_${Date.now()}`;
  const ingestedAt = options?.ingestedAt ?? new Date().toISOString();

  let chunks: string[] = [];

  // Strategy 1: Explicit horizontal divider lines (---, ===, ***)
  const dividerRegex = /\n\s*(?:[-=*]{3,})\s*\n/;
  if (dividerRegex.test(normalized)) {
    chunks = normalized
      .split(/\n\s*(?:[-=*]{3,})\s*\n/)
      .map((s) => s.trim())
      .filter(Boolean);
  } else {
    // Strategy 2: Line-based boundary detection (MSG tags, Message N:, WhatsApp headers, Email From:)
    const lines = normalized.split('\n');
    const boundaryPattern =
      /^(?:\[(?:MSG|MESSAGE)\s*#?\d+\]|(?:MSG|MESSAGE)\s*#?\d+\s*[:\-]|(?:\[\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4},?\s+\d{1,2}:\d{2}(?::\d{2})?(?:\s*[APap][Mm])?\]|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4},?\s+\d{1,2}:\d{2}(?:\s*[APap][Mm])?\s*[-–])\s*[^:\n]+:|From:\s*.+)/i;

    const grouped: string[] = [];
    let current: string[] = [];

    for (const line of lines) {
      if (boundaryPattern.test(line.trim()) && current.length > 0) {
        grouped.push(current.join('\n').trim());
        current = [line];
      } else {
        current.push(line);
      }
    }
    if (current.length > 0) {
      grouped.push(current.join('\n').trim());
    }

    if (grouped.length > 1) {
      chunks = grouped.filter(Boolean);
    } else {
      // Strategy 3: Blank-line separated blocks when multiple paragraphs exist
      const blankSplit = normalized
        .split(/\n{2,}/)
        .map((s) => s.trim())
        .filter(Boolean);
      chunks = blankSplit.length > 1 ? blankSplit : [normalized];
    }
  }

  return chunks.map((chunk, idx) => {
    const order = startingIndex + idx;
    const firstLine = chunk.split('\n')[0]?.trim() ?? '';
    const sourceLabel = extractSourceHint(firstLine);

    return {
      id: `M${order}`,
      order,
      rawText: chunk,
      sourceLabel,
      batchId,
      ingestedAt,
    };
  });
}

function extractSourceHint(firstLine: string): string | undefined {
  const bracketMsg = firstLine.match(/^\[(?:MSG|MESSAGE)\s*#?\d+(?:\s*\|\s*([^\]]+))?\]/i);
  if (bracketMsg?.[1]) {
    return bracketMsg[1].trim();
  }

  const whatsApp = firstLine.match(
    /^(?:\[[^\]]+\]|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4},?\s+\d{1,2}:\d{2}(?:\s*[APap][Mm])?\s*[-–])\s*([^:]+):/
  );
  if (whatsApp?.[1]) {
    return whatsApp[1].trim();
  }

  const emailFrom = firstLine.match(/^From:\s*(.+)$/i);
  if (emailFrom?.[1]) {
    return emailFrom[1].trim();
  }

  const msgPrefix = firstLine.match(/^(?:MSG|MESSAGE)\s*#?\d+\s*[:\-]\s*(?:\(([^)]+)\))?/i);
  if (msgPrefix?.[1]) {
    return msgPrefix[1].trim();
  }

  return undefined;
}
