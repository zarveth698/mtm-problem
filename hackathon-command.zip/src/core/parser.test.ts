import test from 'node:test';
import assert from 'node:assert/strict';
import { parseMessagePackText } from './parser';

test('splits messages separated by --- dividers while preserving exact text', () => {
  const input = `[MSG 1 | Email]
Subject: Venue
Hall capacity is 200.

---

[MSG 2 | WhatsApp]
10:00 AM - Ali: Bhai khana 150 logon ka hona chahiye.`;

  const result = parseMessagePackText(input, { batchId: 'b1', ingestedAt: '2026-11-18T00:00:00.000Z' });
  assert.equal(result.length, 2);
  assert.equal(result[0].id, 'M1');
  assert.equal(result[0].sourceLabel, 'Email');
  assert.match(result[0].rawText, /Hall capacity is 200/);
  assert.equal(result[1].id, 'M2');
  assert.equal(result[1].sourceLabel, 'WhatsApp');
  assert.match(result[1].rawText, /khana 150 logon ka/);
});

test('splits WhatsApp timestamped messages without explicit --- dividers', () => {
  const input = `[11/18/2026, 09:00] Sara: Venue confirmed at H-11.
[11/18/2026, 09:15] Bilal: Match ka kya scene hai?
[11/18/2026, 09:30] Dr Tariq: Judging 5 tracks mein hogi.`;

  const result = parseMessagePackText(input, { startingIndex: 5, batchId: 'b2' });
  assert.equal(result.length, 3);
  assert.equal(result[0].id, 'M5');
  assert.equal(result[0].sourceLabel, 'Sara');
  assert.equal(result[1].id, 'M6');
  assert.equal(result[2].id, 'M7');
  assert.equal(result[2].sourceLabel, 'Dr Tariq');
});

test('handles single incremental message as one RawMessage', () => {
  const input = 'Update: Total budget ab PKR 200,000 hai, pizza cancel kar dein.';
  const result = parseMessagePackText(input, { startingIndex: 11, batchId: 'upd1' });
  assert.equal(result.length, 1);
  assert.equal(result[0].id, 'M11');
  assert.equal(result[0].rawText, input);
});
