import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AlertCircle, X } from 'lucide-react';
import type {
  ExecutionTraceEntry,
  PipelineProgressEvent,
  PlanningArea,
  WorkspaceState,
} from './core/types';
import { TopBar, type NavTab } from './components/TopBar';
import { WorkspaceToolbar } from './components/WorkspaceToolbar';
import { PipelineRunner, type PipelineStepState } from './components/PipelineRunner';
import { OverviewView } from './components/OverviewView';
import { PlanningView } from './components/PlanningView';
import { MessagesView } from './components/MessagesView';
import { TraceView } from './components/TraceView';
import { PastePackModal, UpdateModal } from './components/MessageModals';

const EMPTY_STATE: WorkspaceState = {
  messages: [],
  dispositions: [],
  constraints: [],
  impossibleConflicts: [],
  plan: null,
  validation: null,
  executionTrace: [],
  updateHistory: [],
  lastRunDurationMs: null,
  status: 'idle',
  errorMessage: null,
};

function createInitialSteps(): PipelineStepState[] {
  return [
    { stepId: 'reading', label: 'Reading Agent', areaTag: 'reading', status: 'pending', detail: 'Waiting...' },
    { stepId: 'conflict', label: 'Conflict Resolution', areaTag: 'reading', status: 'pending', detail: 'Waiting...' },
    { stepId: 'venue', label: 'Venue Agent', areaTag: 'venue', status: 'pending', detail: 'Waiting...' },
    { stepId: 'schedule', label: 'Schedule Agent', areaTag: 'schedule', status: 'pending', detail: 'Waiting...' },
    { stepId: 'food', label: 'Food Agent', areaTag: 'food', status: 'pending', detail: 'Waiting...' },
    { stepId: 'judging', label: 'Judging Agent', areaTag: 'judging', status: 'pending', detail: 'Waiting...' },
    { stepId: 'budget', label: 'Budget Agent', areaTag: 'budget', status: 'pending', detail: 'Waiting...' },
    { stepId: 'validation', label: 'Final Validation', areaTag: 'budget', status: 'pending', detail: 'Waiting...' },
  ];
}

export default function App() {
  const [state, setState] = useState<WorkspaceState>(EMPTY_STATE);
  const [loadingInitial, setLoadingInitial] = useState(true);
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [planningArea, setPlanningArea] = useState<PlanningArea>('venue');

  const [isBusy, setIsBusy] = useState(false);
  const [pipelineMode, setPipelineMode] = useState<'initial' | 'incremental_update'>('initial');
  const [pipelineSteps, setPipelineSteps] = useState<PipelineStepState[]>([]);
  const [liveTraces, setLiveTraces] = useState<ExecutionTraceEntry[]>([]);
  const [runStartedAt, setRunStartedAt] = useState<number>(Date.now());

  const [pasteModalOpen, setPasteModalOpen] = useState(false);
  const [updateModalOpen, setUpdateModalOpen] = useState(false);
  const [errorBanner, setErrorBanner] = useState<string | null>(null);

  const fetchState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (!res.ok) throw new Error('Failed to load workspace state');
      const data = (await res.json()) as WorkspaceState;
      setState(data);
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Unable to reach backend server');
    } finally {
      setLoadingInitial(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  const consumeSseStream = async (url: string, body?: unknown) => {
    const res = await fetch(url, {
      method: 'POST',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok || !res.body) {
      const text = await res.text();
      throw new Error(text || `HTTP ${res.status}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const parts = buffer.split('\n\n');
      buffer = parts.pop() ?? '';

      for (const chunk of parts) {
        const line = chunk
          .split('\n')
          .find((l) => l.startsWith('data: '));
        if (!line) continue;

        const payload = JSON.parse(line.slice(6)) as PipelineProgressEvent;

        if (payload.type === 'step' && payload.stepId) {
          setPipelineSteps((prev) => {
            const exists = prev.some((s) => s.stepId === payload.stepId);
            const updated: PipelineStepState = {
              stepId: payload.stepId!,
              label: payload.label ?? payload.stepId!,
              areaTag: payload.areaTag ?? 'reading',
              status: payload.status ?? 'running',
              detail: payload.detail ?? '',
            };
            return exists
              ? prev.map((s) => (s.stepId === payload.stepId ? updated : s))
              : [...prev, updated];
          });
        } else if (payload.type === 'trace' && payload.traceEntry) {
          setLiveTraces((prev) => [...prev, payload.traceEntry!]);
        } else if (payload.type === 'complete' && payload.state) {
          setState(payload.state);
        } else if (payload.type === 'error') {
          setErrorBanner(payload.error ?? 'Pipeline failed');
          if (payload.state) setState(payload.state);
        }
      }
    }
  };

  const handleLoadSample = async () => {
    setErrorBanner(null);
    try {
      const res = await fetch('/api/sample/load', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Failed to load sample pack');
      setState(data);
      setActiveTab('overview');
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Failed to load sample pack');
    }
  };

  const handleIngestText = async (rawText: string, replaceExisting = true) => {
    setErrorBanner(null);
    try {
      const res = await fetch('/api/messages/ingest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText, replaceExisting }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Failed to ingest messages');
      setState(data);
      setActiveTab('overview');
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Failed to ingest messages');
    }
  };

  const handleReset = async () => {
    setErrorBanner(null);
    try {
      const res = await fetch('/api/reset', { method: 'POST' });
      const data = await res.json();
      setState(data);
      setPipelineSteps([]);
      setLiveTraces([]);
      setActiveTab('overview');
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Failed to reset workspace');
    }
  };

  const handleRunPlanner = async () => {
    setErrorBanner(null);
    setIsBusy(true);
    setPipelineMode('initial');
    setPipelineSteps(createInitialSteps());
    setLiveTraces([]);
    setRunStartedAt(Date.now());
    setActiveTab('overview');

    try {
      await consumeSseStream('/api/plan/run');
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Planner execution failed');
    } finally {
      setIsBusy(false);
    }
  };

  const handleRunUpdate = async (rawText: string) => {
    setErrorBanner(null);
    setIsBusy(true);
    setPipelineMode('incremental_update');
    setPipelineSteps([
      {
        stepId: 'reading',
        label: 'Incremental Analysis',
        areaTag: 'reading',
        status: 'running',
        detail: 'Analyzing new message against active constraints...',
      },
    ]);
    setLiveTraces([]);
    setRunStartedAt(Date.now());
    setActiveTab('overview');

    try {
      await consumeSseStream('/api/plan/update', { rawText });
    } catch (err) {
      setErrorBanner(err instanceof Error ? err.message : 'Incremental update failed');
    } finally {
      setIsBusy(false);
    }
  };

  const handleTopBarPrimaryAction = () => {
    if (state.plan) {
      setUpdateModalOpen(true);
    } else if (state.messages.length > 0) {
      handleRunPlanner();
    } else {
      handleLoadSample();
    }
  };

  const navigateToPlanningArea = (area: PlanningArea) => {
    setPlanningArea(area);
    setActiveTab('planning');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        state={state}
        isBusy={isBusy}
        onPrimaryAction={handleTopBarPrimaryAction}
      />

      <WorkspaceToolbar
        state={state}
        isBusy={isBusy}
        onUploadFile={(rawText) => handleIngestText(rawText, true)}
        onOpenPasteModal={() => setPasteModalOpen(true)}
        onLoadSample={handleLoadSample}
        onRunPlanner={handleRunPlanner}
        onOpenUpdateModal={() => setUpdateModalOpen(true)}
        onReset={handleReset}
        onSelectTab={setActiveTab}
      />

      <main className="mx-auto max-w-[1380px] px-6 py-6">
        {/* Error Banner */}
        {errorBanner && (
          <div
            role="alert"
            className="mb-6 flex items-start justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-900"
          >
            <div className="flex items-start gap-2.5">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
              <div>
                <span className="font-semibold">Execution Error: </span>
                <span>{errorBanner}</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setErrorBanner(null)}
              aria-label="Dismiss error"
              className="rounded p-1 text-red-500 hover:bg-red-100 cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {/* Live Animated Multi-Agent Pipeline Monitor */}
        <AnimatePresence>
          {isBusy && (
            <PipelineRunner
              mode={pipelineMode}
              steps={pipelineSteps}
              liveTraces={liveTraces}
              startedAt={runStartedAt}
            />
          )}
        </AnimatePresence>

        {/* Loading Skeleton */}
        {loadingInitial ? (
          <div className="space-y-4">
            <div className="h-28 animate-pulse rounded-xl border border-slate-200 bg-white" />
            <div className="grid grid-cols-4 gap-4">
              <div className="h-24 animate-pulse rounded-xl border border-slate-200 bg-white" />
              <div className="h-24 animate-pulse rounded-xl border border-slate-200 bg-white" />
              <div className="h-24 animate-pulse rounded-xl border border-slate-200 bg-white" />
              <div className="h-24 animate-pulse rounded-xl border border-slate-200 bg-white" />
            </div>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            >
              {activeTab === 'overview' && (
                <OverviewView
                  state={state}
                  isBusy={isBusy}
                  onLoadSample={handleLoadSample}
                  onOpenPaste={() => setPasteModalOpen(true)}
                  onRunPlanner={handleRunPlanner}
                  onOpenUpdate={() => setUpdateModalOpen(true)}
                  onNavigatePlanning={navigateToPlanningArea}
                  onNavigateTab={setActiveTab}
                />
              )}

              {activeTab === 'planning' && (
                <PlanningView
                  plan={state.plan}
                  activeArea={planningArea}
                  onSelectArea={setPlanningArea}
                  onRunSamplePrompt={() => setActiveTab('overview')}
                />
              )}

              {activeTab === 'messages' && <MessagesView state={state} />}

              {activeTab === 'trace' && <TraceView state={state} />}
            </motion.div>
          </AnimatePresence>
        )}
      </main>

      <PastePackModal
        isOpen={pasteModalOpen}
        onClose={() => setPasteModalOpen(false)}
        onSubmit={handleIngestText}
      />

      <UpdateModal
        isOpen={updateModalOpen}
        onClose={() => setUpdateModalOpen(false)}
        onSubmit={handleRunUpdate}
      />
    </div>
  );
}
