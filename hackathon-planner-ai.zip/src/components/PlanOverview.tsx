import React from 'react';
import { CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';
import type { AgentSessionState } from '../agent/types';
import type { ActiveView } from './TopBar';

interface PlanOverviewProps {
  session: AgentSessionState;
  onNavigate: (view: ActiveView) => void;
}

export const PlanOverview: React.FC<PlanOverviewProps> = ({ session, onNavigate }) => {
  const { plan, validation, assessments, traceSummary } = session;
  if (!plan) return null;

  const rejectedCount = assessments.filter((a) => a.status === 'rejected_conflict').length;
  const outdatedCount = assessments.filter((a) => a.status === 'outdated').length;
  const irrelevantCount = assessments.filter((a) => a.status === 'irrelevant').length;
  const excludedCount = rejectedCount + outdatedCount + irrelevantCount;

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-8">
      {/* Header & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            {plan.parameters.city} · {plan.parameters.format} · Updates applied: {session.updateCount}
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 mt-1 text-balance">
            {plan.parameters.eventName}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('trace')}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            Inspect Trace
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={() => onNavigate('update')}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            Add New Message
          </button>
        </div>
      </div>

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 bg-white border border-slate-200 rounded-xl divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Event Scale</p>
          <p className="mt-1.5 text-xl font-semibold text-slate-900 font-mono tabular-nums">
            {plan.parameters.targetStudents} Students · {plan.parameters.targetTeams} Teams
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {plan.parameters.targetHours}h core · {plan.parameters.totalStaffAndJudges} judges &amp; staff
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Budget Utilization</p>
          <p className="mt-1.5 text-xl font-semibold text-slate-900 font-mono tabular-nums">
            {plan.budget.currency} {plan.budget.totalPlannedSpend.toLocaleString()}
          </p>
          <p className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
            Cap {plan.budget.hardBudgetCap.toLocaleString()} · Buffer {plan.budget.remainingBuffer.toLocaleString()}
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Message Pack Audit</p>
          <p className="mt-1.5 text-xl font-semibold text-slate-900 font-mono tabular-nums">
            {assessments.length} Read · {excludedCount} Excluded
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {rejectedCount} conflict · {outdatedCount} outdated · {irrelevantCount} irrelevant
          </p>
        </div>

        <div className="p-5">
          <p className="text-xs font-medium text-slate-500">Model Trace Tokens</p>
          <p className="mt-1.5 text-xl font-semibold text-slate-900 font-mono tabular-nums">
            {traceSummary.grandTotalTokens.toLocaleString()}
          </p>
          <p className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
            {traceSummary.totalCalls} model calls · {(session.lastRunDurationMs / 1000).toFixed(1)}s last run
          </p>
        </div>
      </div>

      {/* Invariant Verification Strip */}
      {validation && (
        <div
          className={`p-4 rounded-xl border ${
            validation.valid
              ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
              : 'bg-amber-50 border-amber-200 text-amber-950'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-3">
            <div className="flex items-center gap-2 font-semibold text-sm">
              {validation.valid ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" aria-hidden="true" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" aria-hidden="true" />
              )}
              <span>
                {validation.valid
                  ? 'All Plan Invariants Verified Valid'
                  : 'Plan Invariant Warnings Detected'}
              </span>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('messages')}
              className="text-xs font-medium underline underline-offset-2 text-left sm:text-right whitespace-nowrap shrink-0"
            >
              Review {excludedCount} rejected / outdated / irrelevant messages
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2 text-xs">
            {validation.checks.map((chk) => (
              <div key={chk.id} className="flex items-start gap-2">
                <span
                  className={`font-semibold shrink-0 ${
                    chk.passed ? 'text-emerald-800' : 'text-red-700'
                  }`}
                >
                  {chk.passed ? 'PASS' : 'FAIL'}
                </span>
                <span className="text-slate-700">
                  <strong className="font-medium text-slate-900">{chk.label}:</strong> {chk.detail}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Novel Constraints Extracted */}
      {plan.parameters.novelConstraints.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-900 mb-2">
            Cross-Cutting &amp; Novel Constraints Respected
          </h2>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-1.5 text-sm text-slate-700 list-disc pl-5">
            {plan.parameters.novelConstraints.map((c, idx) => (
              <li key={idx}>{c}</li>
            ))}
          </ul>
        </div>
      )}

      {/* 01. VENUE */}
      <section aria-labelledby="area-venue" className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2 pb-4 border-b border-slate-200">
          <h2 id="area-venue" className="text-lg font-semibold text-slate-900">
            01. Venue Plan
          </h2>
          <span className="text-sm font-mono tabular-nums font-medium text-slate-700">
            Cost: {plan.budget.currency} {plan.venue.venueCostPkr.toLocaleString()}
          </span>
        </div>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
          <div>
            <p className="text-xs font-medium text-slate-500">Confirmed Location</p>
            <p className="mt-1 font-semibold text-slate-900">{plan.venue.venueName}</p>
            <p className="text-slate-600">{plan.venue.addressOrSector}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">Capacity &amp; Access Window</p>
            <p className="mt-1 font-mono tabular-nums text-slate-900">
              {plan.venue.capacitySeats} seats (need {plan.venue.requiredCapacity})
            </p>
            <p className="text-slate-600 font-mono tabular-nums">
              {plan.venue.accessWindowStart} – {plan.venue.accessWindowEnd} (curfew {plan.venue.lockdownCurfew})
            </p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">Power &amp; Connectivity</p>
            <p className="mt-1 text-slate-800">{plan.venue.powerAndNetwork}</p>
          </div>
        </div>

        <div className="mt-5 pt-5 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1.5">Allocated Zones</p>
            <ul className="list-disc pl-5 space-y-1 text-slate-700">
              {plan.venue.zones.map((z, i) => (
                <li key={i}>{z}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1.5">Safety, Accessibility &amp; Rules</p>
            <ul className="list-disc pl-5 space-y-1 text-slate-700">
              {plan.venue.accessibilityAndSafety.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
              {plan.venue.constraintsRespected.map((c, i) => (
                <li key={`c-${i}`}>{c}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* 02. SCHEDULE */}
      <section aria-labelledby="area-schedule" className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-6 pb-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2">
          <h2 id="area-schedule" className="text-lg font-semibold text-slate-900">
            02. Schedule Timeline
          </h2>
          <p className="text-xs font-mono tabular-nums text-slate-600">
            Doors {plan.schedule.doorsOpen} · Hard exit {plan.schedule.hardExitBy} · Core {plan.schedule.coreEventDurationMinutes} mins
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-medium text-slate-500">
                <th className="py-3 px-6 whitespace-nowrap">Time Window</th>
                <th className="py-3 px-4 whitespace-nowrap text-right">Duration</th>
                <th className="py-3 px-4">Activity</th>
                <th className="py-3 px-4 whitespace-nowrap">Zone</th>
                <th className="py-3 px-4 whitespace-nowrap">Owner</th>
                <th className="py-3 px-6">Constraint Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {plan.schedule.slots.map((slot) => (
                <tr key={slot.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-6 font-mono tabular-nums text-slate-900 whitespace-nowrap">
                    {slot.startTime} – {slot.endTime}
                  </td>
                  <td className="py-3 px-4 font-mono tabular-nums text-slate-600 text-right whitespace-nowrap">
                    {slot.durationMinutes}m
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-900">{slot.activity}</td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">{slot.zone}</td>
                  <td className="py-3 px-4 text-slate-600 whitespace-nowrap">{slot.owner}</td>
                  <td className="py-3 px-6 text-slate-600 text-xs">{slot.constraintsNote || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* 03. FOOD & LOGISTICS */}
      <section aria-labelledby="area-food" className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-6 pb-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2">
          <div>
            <h2 id="area-food" className="text-lg font-semibold text-slate-900">
              03. Food &amp; Catering
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {plan.food.vendor} · {plan.food.servingWindow} · {plan.food.servingZone}
            </p>
          </div>
          <span className="text-sm font-mono tabular-nums font-medium text-slate-700">
            Total: {plan.budget.currency} {plan.food.totalFoodCostPkr.toLocaleString()}
          </span>
        </div>

        <div className="p-6 pb-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm border-b border-slate-100">
          <div>
            <p className="text-xs font-medium text-slate-500">Headcount Covered</p>
            <p className="mt-1 font-mono tabular-nums font-semibold text-slate-900">
              {plan.food.totalHeadcountCovered} people ({plan.food.studentsCount} students + {plan.food.judgesAndVolunteersCount} judges/staff)
            </p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">Dietary Split</p>
            <p className="mt-1 font-mono tabular-nums text-slate-900">
              {plan.food.vegetarianBoxes} Vegetarian · {plan.food.standardBoxes} Standard
            </p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">Halal &amp; Allergen Safety</p>
            <p className="mt-1 text-slate-900">
              {plan.food.halalCertified ? '100% Halal' : 'Check Halal'} · {plan.food.allergenFreeGuarantee}
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-medium text-slate-500">
                <th className="py-3 px-6">Item</th>
                <th className="py-3 px-4">Dietary Tag</th>
                <th className="py-3 px-4 text-right">Quantity</th>
                <th className="py-3 px-4 text-right">Unit Cost</th>
                <th className="py-3 px-6 text-right">Total Cost</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {plan.food.items.map((item, idx) => (
                <tr key={idx}>
                  <td className="py-3 px-6 font-medium text-slate-900">{item.item}</td>
                  <td className="py-3 px-4 text-slate-600">{item.dietaryTag}</td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-900">
                    {item.quantity}
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-600">
                    {item.unitCostPkr.toLocaleString()}
                  </td>
                  <td className="py-3 px-6 text-right font-mono tabular-nums font-medium text-slate-900">
                    {item.totalCostPkr.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* 04. JUDGING */}
      <section aria-labelledby="area-judging" className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2 pb-4 border-b border-slate-200">
          <h2 id="area-judging" className="text-lg font-semibold text-slate-900">
            04. Judging &amp; Awards
          </h2>
          <span className="text-sm font-mono tabular-nums font-medium text-slate-700">
            Prizes &amp; Honoraria: {plan.budget.currency} {plan.judging.prizesAndHonorariaPkr.toLocaleString()}
          </span>
        </div>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
          <div>
            <p className="text-xs font-medium text-slate-500">Parallel Throughput</p>
            <p className="mt-1 font-mono tabular-nums font-semibold text-slate-900">
              {plan.judging.parallelPanels} panels × {plan.judging.teamsPerPanel} teams ({plan.judging.minutesPerTeam}m/team)
            </p>
            <p className="mt-1 text-xs text-slate-600 font-mono tabular-nums">
              {plan.judging.mathVerificationNote}
            </p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">Judge Composition ({plan.judging.totalJudges} total)</p>
            <ul className="mt-1 list-disc pl-5 space-y-0.5 text-slate-700">
              {plan.judging.judgeBreakdown.map((jb, i) => (
                <li key={i}>{jb}</li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">Prizes &amp; Stipends</p>
            <ul className="mt-1 space-y-1 text-slate-700">
              {plan.judging.prizesBreakdown.map((pb, i) => (
                <li key={i} className="flex justify-between gap-4">
                  <span>{pb.label}</span>
                  <span className="font-mono tabular-nums font-medium text-slate-900">
                    {pb.amountPkr.toLocaleString()}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-5 pt-5 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div>
            <p className="text-xs font-medium text-slate-500 mb-2">Evaluation Rubric</p>
            <ul className="space-y-1.5 text-slate-700">
              {plan.judging.rubricCriteria.map((r, i) => (
                <li key={i}>
                  <span className="font-medium text-slate-900">{r.criterion}</span>{' '}
                  <span className="font-mono tabular-nums text-slate-500">({r.weightPercent}%)</span> —{' '}
                  {r.description}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500 mb-2">Panel Assignments</p>
            <ul className="list-disc pl-5 space-y-1 text-slate-700">
              {plan.judging.panelAssignments.map((pa, i) => (
                <li key={i}>{pa}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* 05. BUDGET */}
      <section aria-labelledby="area-budget" className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-6 pb-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-2">
          <div>
            <h2 id="area-budget" className="text-lg font-semibold text-slate-900">
              05. Budget Ledger
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Sources: {plan.budget.fundingSources.map((f) => `${f.source} (${f.amountPkr.toLocaleString()})`).join(' + ')}
            </p>
          </div>
          <span className="text-sm font-mono tabular-nums font-semibold text-slate-900">
            {plan.budget.totalPlannedSpend.toLocaleString()} / {plan.budget.hardBudgetCap.toLocaleString()} {plan.budget.currency}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-medium text-slate-500">
                <th className="py-3 px-6">Category</th>
                <th className="py-3 px-4">Line Item Description</th>
                <th className="py-3 px-4">Source Msg</th>
                <th className="py-3 px-6 text-right">Amount ({plan.budget.currency})</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {plan.budget.lineItems.map((item, idx) => (
                <tr key={idx}>
                  <td className="py-3 px-6 capitalize font-medium text-slate-700">{item.category}</td>
                  <td className="py-3 px-4 text-slate-900">{item.description}</td>
                  <td className="py-3 px-4 font-mono text-xs text-slate-500">{item.sourceMessageId}</td>
                  <td className="py-3 px-6 text-right font-mono tabular-nums font-medium text-slate-900">
                    {item.amountPkr.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 border-t border-slate-200 font-semibold">
                <td colSpan={3} className="py-3 px-6 text-slate-900">
                  Total Planned Spend (Buffer: {plan.budget.currency} {plan.budget.remainingBuffer.toLocaleString()})
                </td>
                <td className="py-3 px-6 text-right font-mono tabular-nums text-slate-900">
                  {plan.budget.totalPlannedSpend.toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </section>
    </div>
  );
};
