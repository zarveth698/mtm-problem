import React, { useRef, useState } from 'react';
import { FileText, Upload, Play, Loader2, AlertCircle } from 'lucide-react';

interface IngestPanelProps {
  rawText: string;
  fileName: string | null;
  isRunning: boolean;
  error: string | null;
  onChangeText: (text: string, fileName?: string | null) => void;
  onLoadSample: () => Promise<void>;
  onRunAgent: () => Promise<void>;
}

export const IngestPanel: React.FC<IngestPanelProps> = ({
  rawText,
  fileName,
  isRunning,
  error,
  onChangeText,
  onLoadSample,
  onRunAgent,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      onChangeText(content, file.name);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const messageCountEstimate = rawText.trim()
    ? rawText
        .trim()
        .split(/\n\s*(?:-{3,}|={3,}|\*{3,})\s*\n/)
        .filter((s) => s.trim().length > 0).length
    : 0;

  return (
    <section aria-labelledby="ingest-heading" className="max-w-5xl mx-auto py-8 px-4 sm:px-6">
      <div className="mb-8">
        <p className="text-sm font-medium text-teal-700 mb-2">
          Autonomous Event Operations · Verbatim Pack Ingestion
        </p>
        <h1
          id="ingest-heading"
          className="text-3xl sm:text-4xl font-semibold tracking-tight text-slate-900 text-balance max-w-3xl"
        >
          Plan a 4-hour physical hackathon from raw message packs
        </h1>
        <p className="mt-3 text-base text-slate-600 max-w-2xl leading-relaxed">
          Upload any plain-text pack of emails, WhatsApp threads, and notices in English or Roman
          Urdu. Every message is processed identically with zero hardcoded assumptions, full conflict
          rejection, and token-level trace auditing.
        </p>
      </div>

      {error && (
        <div
          role="alert"
          className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3 text-sm text-red-900"
        >
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="font-semibold">Execution Error</p>
            <p className="mt-0.5 text-red-800">{error}</p>
          </div>
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`p-6 border-b border-slate-200 transition-colors ${
            isDragging ? 'bg-teal-50/60' : 'bg-slate-50/70'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-start gap-3">
              <FileText className="w-5 h-5 text-slate-700 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Message Pack Source (.txt)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {fileName
                    ? `Loaded file: ${fileName} · ~${messageCountEstimate} message block(s)`
                    : 'Drop a .txt file here, upload from disk, or paste raw messages below'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <input
                ref={fileInputRef}
                type="file"
                accept=".txt,text/plain"
                className="hidden"
                aria-label="Upload message pack text file"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                }}
              />
              <button
                type="button"
                disabled={isRunning}
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
              >
                <Upload className="w-4 h-4" aria-hidden="true" />
                Upload .txt File
              </button>
              <button
                type="button"
                disabled={isRunning}
                onClick={onLoadSample}
                className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
              >
                Load Sample Pack
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <label
            htmlFor="message-pack-textarea"
            className="block text-xs font-medium text-slate-600 mb-2"
          >
            Verbatim Message Pack Content (read as-is without edits or hints)
          </label>
          <textarea
            id="message-pack-textarea"
            value={rawText}
            onChange={(e) => onChangeText(e.target.value, null)}
            disabled={isRunning}
            rows={13}
            placeholder="Paste your raw message pack here (e.g., messages separated by ---) or upload a .txt file above..."
            className="w-full p-4 font-mono text-xs leading-relaxed text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white resize-y"
          />

          <div className="mt-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
              <span>Areas planned: Venue · Schedule · Food · Judging · Budget</span>
              <span aria-hidden="true">/</span>
              <span>Cutoff: 2 minutes</span>
            </div>

            <button
              type="button"
              disabled={isRunning || rawText.trim().length === 0}
              onClick={onRunAgent}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-teal-700"
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                  Running 6-Stage Planning Agent...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" aria-hidden="true" />
                  Run Planning Agent
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
