import React, { useState } from 'react';
import { CheckCircle2, XCircle, Clock, MinusCircle } from 'lucide-react';
import type { MessageAssessment, MessageStatus } from '../agent/types';

interface MessageAuditProps {
  assessments: MessageAssessment[];
}

type FilterOption = 'all' | 'rejected_and_excluded' | MessageStatus;

export const MessageAudit: React.FC<MessageAuditProps> = ({ assessments }) => {
  const [filter, setFilter] = useState<FilterOption>('all');

  const filtered = assessments.filter((m) => {
    if (filter === 'all') return true;
    if (filter === 'rejected_and_excluded') return m.status !== 'accepted';
    return m.status === filter;
  });

  const counts = {
    all: assessments.length,
    rejected_and_excluded: assessments.filter((m) => m.status !== 'accepted').length,
    accepted: assessments.filter((m) => m.status === 'accepted').length,
    rejected_conflict: assessments.filter((m) => m.status === 'rejected_conflict').length,
    outdated: assessments.filter((m) => m.status === 'outdated').length,
    irrelevant: assessments.filter((m) => m.status === 'irrelevant').length,
  };

  const renderStatus = (status: MessageStatus) => {
    switch (status) {
      case 'accepted':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
            Accepted
          </span>
        );
      case 'rejected_conflict':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-red-700">
            <XCircle className="w-3.5 h-3.5 text-red-600" aria-hidden="true" />
            Rejected (Conflict)
          </span>
        );
      case 'outdated':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800">
            <Clock className="w-3.5 h-3.5 text-amber-700" aria-hidden="true" />
            Outdated (Superseded)
          </span>
        );
      case 'irrelevant':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600">
            <MinusCircle className="w-3.5 h-3.5 text-slate-500" aria-hidden="true" />
            Irrelevant
          </span>
        );
    }
  };

  const filterButtons: Array<{ id: FilterOption; label: string; count: number }> = [
    { id: 'all', label: 'All Messages', count: counts.all },
    { id: 'rejected_and_excluded', label: 'Rejected & Excluded', count: counts.rejected_and_excluded },
    { id: 'accepted', label: 'Accepted', count: counts.accepted },
    { id: 'rejected_conflict', label: 'Conflicts', count: counts.rejected_conflict },
    { id: 'outdated', label: 'Outdated', count: counts.outdated },
    { id: 'irrelevant', label: 'Irrelevant', count: counts.irrelevant },
  ];

  return (
    <section aria-labelledby="messages-heading" className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Verbatim Input Audit · English &amp; Roman Urdu Triage
          </p>
          <h1 id="messages-heading" className="text-2xl font-semibold tracking-tight text-slate-900 mt-1">
            Message Log &amp; Rejections
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
          {filterButtons.map((btn) => (
            <button
              key={btn.id}
              type="button"
              onClick={() => setFilter(btn.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                filter === btn.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {btn.label} ({btn.count})
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
          No messages match the selected filter.
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((msg) => (
            <article
              key={msg.messageId}
              className="bg-white border border-slate-200 rounded-xl p-5 space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 border-b border-slate-100">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                  <span className="font-mono font-semibold text-slate-900">{msg.messageId}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-medium text-slate-800">{msg.sender}</span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize">{msg.channel}</span>
                  <span aria-hidden="true">·</span>
                  <span>{msg.language}</span>
                  {msg.affectedAreas.length > 0 && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">Areas: {msg.affectedAreas.join(', ')}</span>
                    </>
                  )}
                </div>

                <div className="shrink-0">{renderStatus(msg.status)}</div>
              </div>

              <div className="text-sm text-slate-900">
                <span className="font-medium">Decision Reason: </span>
                <span className={msg.status === 'rejected_conflict' ? 'text-red-800 font-medium' : 'text-slate-700'}>
                  {msg.reason}
                </span>
                {msg.supersededById && (
                  <span className="text-slate-500 font-mono text-xs ml-2">
                    (Superseded by {msg.supersededById})
                  </span>
                )}
              </div>

              <div>
                <p className="text-xs font-medium text-slate-500 mb-1">Verbatim Message Text</p>
                <pre className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg font-mono text-xs text-slate-800 whitespace-pre-wrap break-words">
                  {msg.rawText}
                </pre>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
};
