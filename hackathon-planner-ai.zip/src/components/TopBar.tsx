import React from 'react';

export type ActiveView = 'plan' | 'trace' | 'messages' | 'update' | 'ingest';

interface TopBarProps {
  activeView: ActiveView;
  hasPlan: boolean;
  onSelectView: (view: ActiveView) => void;
  onNewPack: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeView,
  hasPlan,
  onSelectView,
  onNewPack,
}) => {
  const navItems: Array<{ id: ActiveView; label: string; requiresPlan: boolean }> = [
    { id: 'plan', label: 'Event Plan', requiresPlan: true },
    { id: 'trace', label: 'Model Trace', requiresPlan: true },
    { id: 'messages', label: 'Message Log', requiresPlan: true },
    { id: 'update', label: 'Update Plan', requiresPlan: true },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        <button
          type="button"
          onClick={() => onSelectView(hasPlan ? 'plan' : 'ingest')}
          className="text-lg font-semibold tracking-tight text-slate-900 whitespace-nowrap shrink-0 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-700 rounded"
        >
          HackPlan Islamabad
        </button>

        <nav aria-label="Primary sections" className="hidden md:flex items-center gap-6">
          {navItems.map((item) => {
            const disabled = item.requiresPlan && !hasPlan;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                disabled={disabled}
                onClick={() => onSelectView(item.id)}
                className={`py-2 text-sm font-medium whitespace-nowrap shrink-0 border-b-2 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-700 ${
                  disabled
                    ? 'border-transparent text-slate-300 cursor-not-allowed'
                    : isActive
                      ? 'border-teal-700 text-slate-900'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onNewPack}
            className="px-4 py-2 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-teal-700"
          >
            {hasPlan ? 'New Message Pack' : 'Import Sample Pack'}
          </button>
        </div>
      </div>

      {hasPlan && (
        <nav
          aria-label="Mobile sections"
          className="md:hidden border-t border-slate-200 px-4 flex items-center gap-4 overflow-x-auto"
        >
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectView(item.id)}
                className={`py-2.5 text-sm font-medium whitespace-nowrap shrink-0 border-b-2 ${
                  isActive
                    ? 'border-teal-700 text-slate-900'
                    : 'border-transparent text-slate-600'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>
      )}
    </header>
  );
};
