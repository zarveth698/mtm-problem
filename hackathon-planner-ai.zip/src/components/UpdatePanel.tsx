import React, { useRef, useState } from 'react';
import { Upload, Send, Loader2, AlertCircle, ShieldCheck } from 'lucide-react';

interface UpdatePanelProps {
  isUpdating: boolean;
  updateCount: number;
  error: string | null;
  lastUpdateNotes: string[];
  onSubmitUpdate: (messageText: string) => Promise<void>;
}

export const UpdatePanel: React.FC<UpdatePanelProps> = ({
  isUpdating,
  updateCount,
  error,
  lastUpdateNotes,
  onSubmitUpdate,
}) => {
  const [messageText, setMessageText] = useState('');
  const [uploadedName, setUploadedName] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      setMessageText(content);
      setUploadedName(file.name);
    };
    reader.readAsText(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || isUpdating) return;
    await onSubmitUpdate(messageText);
    setMessageText('');
    setUploadedName(null);
  };

  return (
    <section aria-labelledby="update-heading" className="max-w-4xl mx-auto py-8 px-4 sm:px-6">
      <div className="mb-6">
        <p className="text-sm font-medium text-teal-700 mb-1">
          Incremental Plan Update · Updates Applied: <span className="font-mono tabular-nums">{updateCount}</span>
        </p>
        <h2 id="update-heading" className="text-2xl font-semibold tracking-tight text-slate-900">
          Submit New Message After Initial Run
        </h2>
        <p className="mt-2 text-sm text-slate-600 max-w-2xl">
          Send a new email, WhatsApp message, or notice (English or Roman Urdu). The agent uses at
          most 5 model calls within a 1-minute cutoff, updates only impacted areas, and rejects
          conflicting instructions while keeping the existing plan valid.
        </p>
      </div>

      {error && (
        <div
          role="alert"
          className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3 text-sm text-red-900"
        >
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="font-semibold">Update Error</p>
            <p className="mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {lastUpdateNotes.length > 0 && (
        <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-950">
          <div className="flex items-center gap-2 font-semibold mb-1.5">
            <ShieldCheck className="w-4 h-4 text-amber-700" aria-hidden="true" />
            <span>Latest Conflict / Validation Audit Notes</span>
          </div>
          <ul className="list-disc pl-5 space-y-1 text-amber-900">
            {lastUpdateNotes.map((note, idx) => (
              <li key={idx}>{note}</li>
            ))}
          </ul>
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className="bg-white border border-slate-200 rounded-xl p-6 space-y-5"
      >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200">
          <div>
            <p className="text-sm font-medium text-slate-900">Incoming Message Text</p>
            <p className="text-xs text-slate-500 mt-0.5">
              {uploadedName
                ? `Loaded from ${uploadedName}`
                : 'Enter a single new message or upload a .txt update file'}
            </p>
          </div>
          <div>
            <input
              ref={fileRef}
              type="file"
              accept=".txt,text/plain"
              className="hidden"
              aria-label="Upload new message text file"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
              }}
            />
            <button
              type="button"
              disabled={isUpdating}
              onClick={() => fileRef.current?.click()}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <Upload className="w-4 h-4" aria-hidden="true" />
              Load Update .txt
            </button>
          </div>
        </div>

        <div>
          <label htmlFor="incremental-msg-input" className="sr-only">
            New message content
          </label>
          <textarea
            id="incremental-msg-input"
            rows={6}
            value={messageText}
            onChange={(e) => {
              setMessageText(e.target.value);
              setUploadedName(null);
            }}
            disabled={isUpdating}
            placeholder="Example: [WhatsApp - 15 Nov] Caterer: Chai break ab PKR 100 per person par finalize ho gaya hai for all 170 people."
            className="w-full p-4 font-mono text-xs leading-relaxed text-slate-900 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-700 focus:bg-white"
          />
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <p className="text-xs text-slate-500">
            Hard limits: max 5 model calls · 60s cutoff · plan invariants preserved
          </p>
          <button
            type="submit"
            disabled={isUpdating || messageText.trim().length === 0}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isUpdating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                Updating Plan...
              </>
            ) : (
              <>
                <Send className="w-4 h-4" aria-hidden="true" />
                Apply Incremental Update
              </>
            )}
          </button>
        </div>
      </form>
    </section>
  );
};
