import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Copy, Check, Download, AlertTriangle } from 'lucide-react';
import type { TraceEntry, TraceSummary } from '../agent/types';

interface TraceViewerProps {
  trace: TraceEntry[];
  summary: TraceSummary;
  formattedTrace: string;
}

export const TraceViewer: React.FC<TraceViewerProps> = ({
  trace,
  summary,
  formattedTrace,
}) => {
  const [expandedCalls, setExpandedCalls] = useState<Record<number, boolean>>({ 1: true });
  const [copied, setCopied] = useState(false);

  const toggleCall = (num: number) => {
    setExpandedCalls((prev) => ({ ...prev, [num]: !prev[num] }));
  };

  const setAll = (open: boolean) => {
    const next: Record<number, boolean> = {};
    for (const entry of trace) {
      next[entry.callNumber] = open;
    }
    setExpandedCalls(next);
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(formattedTrace);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section aria-labelledby="trace-heading" className="max-w-7xl mx-auto py-8 px-4 sm:px-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-500">
            Numbered Model Execution Log · Exact UsageMetadata Reporting
          </p>
          <h1 id="trace-heading" className="text-2xl font-semibold tracking-tight text-slate-900 mt-1">
            Execution Trace ({summary.totalCalls} Model Calls)
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setAll(true)}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
          >
            Expand All
          </button>
          <button
            type="button"
            onClick={() => setAll(false)}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
          >
            Collapse All
          </button>
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg whitespace-nowrap shrink-0"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" /> : <Copy className="w-3.5 h-3.5" aria-hidden="true" />}
            {copied ? 'Copied Trace' : 'Copy Trace'}
          </button>
          <a
            href="/api/trace/download"
            download="hackathon-agent-trace.txt"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-teal-700 hover:bg-teal-800 rounded-lg whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            Download .txt Trace
          </a>
        </div>
      </div>

      {/* Trace Entries */}
      <div className="space-y-4">
        {trace.map((entry) => {
          const isOpen = Boolean(expandedCalls[entry.callNumber]);
          return (
            <article
              key={entry.callNumber}
              className="bg-white border border-slate-200 rounded-xl overflow-hidden"
            >
              <button
                type="button"
                aria-expanded={isOpen}
                onClick={() => toggleCall(entry.callNumber)}
                className="w-full px-5 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-left hover:bg-slate-50/70 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  {isOpen ? (
                    <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" aria-hidden="true" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-500 shrink-0" aria-hidden="true" />
                  )}
                  <span className="font-mono tabular-nums text-sm font-semibold text-slate-900">
                    Call #{entry.callNumber}
                  </span>
                  <span className="text-slate-300" aria-hidden="true">/</span>
                  <span className="text-sm font-medium text-teal-800">
                    Area: {entry.area}
                  </span>
                  <span className="text-slate-300" aria-hidden="true">/</span>
                  <span className="font-mono text-xs text-slate-600 truncate">
                    {entry.modelName}
                  </span>
                  <span className="text-slate-300 hidden md:inline" aria-hidden="true">/</span>
                  <span className="text-xs text-slate-500 hidden md:inline">
                    {entry.phase === 'update' ? `Update #${entry.updateBatchIndex ?? 1}` : 'Initial Run'}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-4 text-xs font-mono tabular-nums text-slate-600 pl-7 sm:pl-0 shrink-0">
                  <span>Prompt: {entry.tokens.promptTokens.toLocaleString()}</span>
                  <span>Output: {entry.tokens.candidatesTokens.toLocaleString()}</span>
                  <span>Think: {entry.tokens.thoughtsTokens.toLocaleString()}</span>
                  <span className="font-semibold text-slate-900">
                    Total: {entry.tokens.totalTokens.toLocaleString()}
                  </span>
                  <span className="text-slate-400">{entry.durationMs}ms</span>
                </div>
              </button>

              {entry.conflictNotes.length > 0 && (
                <div className="px-5 py-3 bg-amber-50 border-t border-amber-200 text-xs text-amber-950 flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <span className="font-semibold">Conflict / Rejection Reasons Logged:</span>
                    <ul className="list-disc pl-4 mt-1 space-y-0.5">
                      {entry.conflictNotes.map((note, idx) => (
                        <li key={idx}>{note}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {isOpen && (
                <div className="border-t border-slate-200 divide-y divide-slate-200">
                  <div className="p-5">
                    <p className="text-xs font-semibold text-slate-600 mb-2">Model Input</p>
                    <pre className="p-4 bg-slate-50 border border-slate-200 rounded-lg font-mono text-xs text-slate-800 whitespace-pre-wrap break-words max-h-72 overflow-y-auto">
                      {entry.input}
                    </pre>
                  </div>
                  <div className="p-5">
                    <p className="text-xs font-semibold text-slate-600 mb-2">Model Output</p>
                    <pre className="p-4 bg-slate-50 border border-slate-200 rounded-lg font-mono text-xs text-slate-800 whitespace-pre-wrap break-words max-h-72 overflow-y-auto">
                      {entry.output}
                    </pre>
                  </div>
                </div>
              )}
            </article>
          );
        })}
      </div>

      {/* Trace Totals Footer */}
      <div className="bg-slate-900 text-slate-100 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-slate-400">Trace End Summary</p>
          <p className="text-lg font-semibold mt-0.5 font-mono tabular-nums">
            Total Tokens: {summary.grandTotalTokens.toLocaleString()}
          </p>
        </div>

        <div className="grid grid-cols-2 sm:flex sm:items-center gap-6 text-xs font-mono tabular-nums">
          <div>
            <span className="text-slate-400 block">Calls</span>
            <span className="text-sm font-semibold">{summary.totalCalls}</span>
          </div>
          <div>
            <span className="text-slate-400 block">Prompt Tokens</span>
            <span className="text-sm font-semibold">{summary.totalPromptTokens.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-slate-400 block">Output Tokens</span>
            <span className="text-sm font-semibold">{summary.totalCandidatesTokens.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-slate-400 block">Thinking Tokens</span>
            <span className="text-sm font-semibold">{summary.totalThoughtsTokens.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </section>
  );
};
