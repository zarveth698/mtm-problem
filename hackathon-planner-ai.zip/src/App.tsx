import { useEffect, useState } from 'react';
import { TopBar } from './components/TopBar';
import type { ActiveView } from './components/TopBar';
import { IngestPanel } from './components/IngestPanel';
import { PlanOverview } from './components/PlanOverview';
import { TraceViewer } from './components/TraceViewer';
import { MessageAudit } from './components/MessageAudit';
import { UpdatePanel } from './components/UpdatePanel';
import type { AgentSessionState } from './agent/types';

export default function App() {
  const [session, setSession] = useState<AgentSessionState | null>(null);
  const [formattedTrace, setFormattedTrace] = useState<string>('');
  const [activeView, setActiveView] = useState<ActiveView>('ingest');
  const [rawPackText, setRawPackText] = useState<string>('');
  const [fileName, setFileName] = useState<string | null>(null);
  const [isInitialLoading, setIsInitialLoading] = useState<boolean>(true);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdateNotes, setLastUpdateNotes] = useState<string[]>([]);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const res = await fetch('/api/session');
        if (!res.ok) return;
        const data = (await res.json()) as {
          session: AgentSessionState | null;
          formattedTrace: string;
        };
        if (!active) return;
        if (data.session && data.session.plan) {
          setSession(data.session);
          setFormattedTrace(data.formattedTrace);
          setActiveView('plan');
        }
      } catch {
        // Initial empty state
      } finally {
        if (active) setIsInitialLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const handleLoadSample = async () => {
    setError(null);
    try {
      const res = await fetch('/api/sample-pack');
      const data = (await res.json()) as { filename?: string; content?: string; error?: string };
      if (!res.ok || !data.content) {
        throw new Error(data.error || 'Could not load sample pack.');
      }
      setRawPackText(data.content);
      setFileName(data.filename ?? 'islamabad-sample-pack.txt');
      setActiveView('ingest');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load sample pack.');
    }
  };

  const handleRunAgent = async () => {
    if (!rawPackText.trim() || isRunning) return;
    setError(null);
    setIsRunning(true);
    setLastUpdateNotes([]);
    try {
      const res = await fetch('/api/plan/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText: rawPackText }),
      });
      const data = (await res.json()) as {
        session?: AgentSessionState;
        formattedTrace?: string;
        error?: string;
      };
      if (!res.ok || !data.session) {
        throw new Error(data.error || 'Planning agent failed.');
      }
      setSession(data.session);
      setFormattedTrace(data.formattedTrace ?? '');
      setActiveView('plan');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Planning agent failed.');
    } finally {
      setIsRunning(false);
    }
  };

  const handleSubmitUpdate = async (messageText: string) => {
    setError(null);
    setIsUpdating(true);
    try {
      const prevTraceLen = session?.trace.length ?? 0;
      const res = await fetch('/api/plan/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messageText }),
      });
      const data = (await res.json()) as {
        session?: AgentSessionState;
        formattedTrace?: string;
        error?: string;
      };
      if (!res.ok || !data.session) {
        throw new Error(data.error || 'Incremental update failed.');
      }
      const newEntries = data.session.trace.slice(prevTraceLen);
      const notes = newEntries.flatMap((entry) => entry.conflictNotes);
      setLastUpdateNotes(notes);
      setSession(data.session);
      setFormattedTrace(data.formattedTrace ?? '');
      setActiveView(notes.length > 0 ? 'update' : 'plan');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Incremental update failed.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleNewPack = async () => {
    if (!session?.plan) {
      await handleLoadSample();
      return;
    }
    setError(null);
    setLastUpdateNotes([]);
    await fetch('/api/plan/reset', { method: 'POST' });
    setSession(null);
    setFormattedTrace('');
    setActiveView('ingest');
  };

  const hasPlan = Boolean(session && session.plan);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <TopBar
        activeView={activeView}
        hasPlan={hasPlan}
        onSelectView={setActiveView}
        onNewPack={handleNewPack}
      />

      <main className="flex-1">
        {isInitialLoading ? (
          <div className="max-w-5xl mx-auto py-16 px-6 space-y-4">
            <div className="h-8 w-64 bg-slate-200 rounded animate-pulse" />
            <div className="h-48 w-full bg-slate-200 rounded-xl animate-pulse" />
          </div>
        ) : activeView === 'ingest' || !hasPlan ? (
          <IngestPanel
            rawText={rawPackText}
            fileName={fileName}
            isRunning={isRunning}
            error={error}
            onChangeText={(txt, name) => {
              setRawPackText(txt);
              if (name !== undefined) setFileName(name);
            }}
            onLoadSample={handleLoadSample}
            onRunAgent={handleRunAgent}
          />
        ) : activeView === 'plan' && session ? (
          <PlanOverview session={session} onNavigate={setActiveView} />
        ) : activeView === 'trace' && session ? (
          <TraceViewer
            trace={session.trace}
            summary={session.traceSummary}
            formattedTrace={formattedTrace}
          />
        ) : activeView === 'messages' && session ? (
          <MessageAudit assessments={session.assessments} />
        ) : activeView === 'update' && session ? (
          <UpdatePanel
            isUpdating={isUpdating}
            updateCount={session.updateCount}
            error={error}
            lastUpdateNotes={lastUpdateNotes}
            onSubmitUpdate={handleSubmitUpdate}
          />
        ) : null}
      </main>
    </div>
  );
}
