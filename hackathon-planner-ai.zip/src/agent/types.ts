export type AreaTag = 'reading' | 'venue' | 'schedule' | 'food' | 'judging' | 'budget';

export type PlanArea = 'venue' | 'schedule' | 'food' | 'judging' | 'budget';

export type MessageStatus =
  | 'accepted'
  | 'outdated'
  | 'irrelevant'
  | 'rejected_conflict';

export interface RawMessage {
  id: string;
  index: number;
  rawText: string;
  senderHint: string;
  channelHint: 'email' | 'whatsapp' | 'notice' | 'unknown';
}

export interface MessageAssessment {
  messageId: string;
  rawText: string;
  sender: string;
  channel: string;
  language: 'English' | 'Roman Urdu' | 'Mixed' | 'Other';
  status: MessageStatus;
  summary: string;
  affectedAreas: PlanArea[];
  reason: string;
  supersededById?: string;
}

export interface EventParameters {
  eventName: string;
  city: string;
  format: string;
  targetStudents: number;
  targetTeams: number;
  targetHours: number;
  totalStaffAndJudges: number;
  novelConstraints: string[];
}

export interface VenuePlan {
  venueName: string;
  addressOrSector: string;
  capacitySeats: number;
  requiredCapacity: number;
  accessWindowStart: string;
  accessWindowEnd: string;
  lockdownCurfew: string;
  zones: string[];
  powerAndNetwork: string;
  accessibilityAndSafety: string[];
  venueCostPkr: number;
  constraintsRespected: string[];
  notes: string;
}

export interface ScheduleSlot {
  id: string;
  startTime: string;
  endTime: string;
  startMinuteOfDay: number;
  endMinuteOfDay: number;
  durationMinutes: number;
  activity: string;
  zone: string;
  owner: string;
  constraintsNote: string;
}

export interface SchedulePlan {
  eventDateNote: string;
  doorsOpen: string;
  hardExitBy: string;
  coreEventDurationMinutes: number;
  slots: ScheduleSlot[];
  constraintsRespected: string[];
}

export interface FoodItem {
  item: string;
  quantity: number;
  unitCostPkr: number;
  totalCostPkr: number;
  dietaryTag: string;
}

export interface FoodPlan {
  vendor: string;
  totalHeadcountCovered: number;
  studentsCount: number;
  judgesAndVolunteersCount: number;
  halalCertified: boolean;
  allergenFreeGuarantee: string;
  vegetarianBoxes: number;
  standardBoxes: number;
  servingWindow: string;
  servingZone: string;
  items: FoodItem[];
  totalFoodCostPkr: number;
  constraintsRespected: string[];
}

export interface JudgingPlan {
  totalTeams: number;
  parallelPanels: number;
  teamsPerPanel: number;
  minutesPerTeam: number;
  judgingWindowMinutes: number;
  totalJudges: number;
  judgeBreakdown: string[];
  panelAssignments: string[];
  rubricCriteria: Array<{ criterion: string; weightPercent: number; description: string }>;
  prizesAndHonorariaPkr: number;
  prizesBreakdown: Array<{ label: string; amountPkr: number }>;
  constraintsRespected: string[];
  mathVerificationNote: string;
}

export interface BudgetLineItem {
  category: PlanArea | 'operations' | 'contingency';
  description: string;
  amountPkr: number;
  sourceMessageId: string;
}

export interface BudgetPlan {
  currency: string;
  hardBudgetCap: number;
  totalPlannedSpend: number;
  remainingBuffer: number;
  lineItems: BudgetLineItem[];
  fundingSources: Array<{ source: string; amountPkr: number }>;
  constraintsRespected: string[];
}

export interface HackathonPlan {
  parameters: EventParameters;
  venue: VenuePlan;
  schedule: SchedulePlan;
  food: FoodPlan;
  judging: JudgingPlan;
  budget: BudgetPlan;
}

export interface InvariantCheck {
  id: string;
  area: PlanArea | 'cross-area';
  label: string;
  passed: boolean;
  detail: string;
}

export interface PlanValidationResult {
  valid: boolean;
  checks: InvariantCheck[];
  errors: string[];
}

export interface TokenUsage {
  promptTokens: number;
  candidatesTokens: number;
  thoughtsTokens: number;
  totalTokens: number;
}

export interface TraceEntry {
  callNumber: number;
  phase: 'initial' | 'update';
  updateBatchIndex?: number;
  modelName: string;
  area: AreaTag;
  input: string;
  output: string;
  tokens: TokenUsage;
  durationMs: number;
  timestamp: string;
  conflictNotes: string[];
}

export interface TraceSummary {
  totalCalls: number;
  totalPromptTokens: number;
  totalCandidatesTokens: number;
  totalThoughtsTokens: number;
  grandTotalTokens: number;
}

export interface AgentSessionState {
  sessionId: string;
  createdAt: string;
  updatedAt: string;
  updateCount: number;
  rawMessages: RawMessage[];
  assessments: MessageAssessment[];
  plan: HackathonPlan | null;
  validation: PlanValidationResult | null;
  trace: TraceEntry[];
  traceSummary: TraceSummary;
  lastRunDurationMs: number;
  lastRunError: string | null;
}
