import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { parseMessagePack } from './parser.ts';
import { computeTokenTotals } from './traceFormatter.ts';
import { validatePlanInvariants } from './validator.ts';
import type {
  AgentSessionState,
  AreaTag,
  BudgetPlan,
  EventParameters,
  FoodPlan,
  HackathonPlan,
  JudgingPlan,
  MessageAssessment,
  PlanArea,
  RawMessage,
  SchedulePlan,
  TokenUsage,
  TraceEntry,
  VenuePlan,
} from './types.ts';

const PRIMARY_MODEL = 'gemini-4-hydrogen';
const LITE_MODEL = 'gemini-3.1-flash-lite';
const quotaExhaustedUntil = new Map<string, number>();

function isModelTemporarilyExhausted(modelName: string): boolean {
  const until = quotaExhaustedUntil.get(modelName);
  if (!until) return false;
  if (Date.now() > until) {
    quotaExhaustedUntil.delete(modelName);
    return false;
  }
  return true;
}

function getClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function formatGeminiError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err);
  try {
    const parsed = JSON.parse(raw) as {
      error?: { code?: number; message?: string; status?: string };
    };
    if (parsed?.error) {
      const code = parsed.error.code ?? '';
      const status = parsed.error.status ?? '';
      const msg = parsed.error.message ?? raw;
      if (code === 429 || status === 'RESOURCE_EXHAUSTED') {
        return `Gemini API quota exceeded (${status || 429}). Free-tier daily request limits were reached. Upgrade or select a billing-enabled API key in Settings > Secrets to run unlimited packs. Details: ${msg.split('\n')[0]}`;
      }
      if (code === 403 || code === 400 || status === 'PERMISSION_DENIED') {
        return `Gemini API authentication/request error (${code}): Please verify your API key in Settings > Secrets. ${msg.split('\n')[0]}`;
      }
      return `Gemini API error (${code} ${status}): ${msg.split('\n')[0]}`;
    }
  } catch {
    // Not JSON
  }
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return 'Gemini API rate/quota limit reached (429 RESOURCE_EXHAUSTED). Please select a billing-enabled API key in Settings > Secrets or retry later.';
  }
  return raw;
}

function isQuotaError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return msg.includes('RESOURCE_EXHAUSTED') || msg.includes('"code":429') || msg.includes('429');
}

function isTransientError(err: unknown): boolean {
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  return (
    msg.includes('503') ||
    msg.includes('unavailable') ||
    msg.includes('high demand') ||
    msg.includes('overloaded') ||
    msg.includes('500') ||
    msg.includes('502') ||
    msg.includes('504') ||
    msg.includes('econnreset') ||
    msg.includes('etimedout') ||
    msg.includes('fetch failed')
  );
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

interface ModelCallOptions {
  ai: GoogleGenAI;
  preferredModel?: string;
  area: AreaTag;
  phase: 'initial' | 'update';
  updateBatchIndex?: number;
  callNumber: number;
  systemInstruction: string;
  prompt: string;
  responseSchema: Record<string, unknown>;
  deadlineAt: number;
  thinkingLevel?: ThinkingLevel;
}

function sanitizeConflictNote(raw?: string): string[] {
  if (!raw) return [];
  const trimmed = raw.trim();
  if (!trimmed) return [];
  const lower = trimmed.toLowerCase().replace(/[.\s]+$/g, '');
  if (
    lower === 'none' ||
    lower === 'n/a' ||
    lower === 'na' ||
    lower === 'null' ||
    lower === 'nil' ||
    lower === 'no' ||
    lower === 'no conflict' ||
    lower === 'no conflicts' ||
    lower === 'no conflict detected' ||
    lower === '-'
  ) {
    return [];
  }
  return [trimmed];
}

async function invokeSingleModel(
  ai: GoogleGenAI,
  modelName: string,
  opts: ModelCallOptions,
  remainingMs: number
) {
  const callPromise = ai.models.generateContent({
    model: modelName,
    contents: opts.prompt,
    config: {
      systemInstruction: opts.systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: opts.responseSchema as never,
      thinkingConfig: {
        thinkingLevel: opts.thinkingLevel ?? ThinkingLevel.LOW,
      },
    },
  });

  const timeoutPromise = new Promise<never>((_, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`Model call #${opts.callNumber} (${opts.area}) exceeded time limit.`));
    }, remainingMs);
    callPromise.finally(() => clearTimeout(timer)).catch(() => clearTimeout(timer));
  });

  return Promise.race([callPromise, timeoutPromise]);
}

async function executeTrackedModelCall<T>(
  opts: ModelCallOptions,
  extractConflicts: (parsed: T) => string[]
): Promise<{ parsed: T; traceEntry: TraceEntry }> {
  const remainingMs = opts.deadlineAt - Date.now();
  if (remainingMs <= 1500) {
    throw new Error(`Execution cutoff reached before ${opts.area} model call (#${opts.callNumber}).`);
  }

  const startedAt = Date.now();
  const requested = opts.preferredModel ?? PRIMARY_MODEL;
  const alternate = requested === PRIMARY_MODEL ? LITE_MODEL : PRIMARY_MODEL;
  const primary =
    isModelTemporarilyExhausted(requested) && !isModelTemporarilyExhausted(alternate)
      ? alternate
      : requested;
  const fallback = primary === PRIMARY_MODEL ? LITE_MODEL : PRIMARY_MODEL;

  const attemptSequence: Array<{ model: string; backoffMs: number }> = [
    { model: primary, backoffMs: 0 },
    { model: fallback, backoffMs: 400 },
    { model: primary, backoffMs: 1200 },
    { model: fallback, backoffMs: 2500 },
  ];

  let usedModel = primary;
  let response;
  let lastError: unknown = null;

  for (let i = 0; i < attemptSequence.length; i++) {
    const { model, backoffMs } = attemptSequence[i];
    if (isModelTemporarilyExhausted(model) && i > 0) {
      continue;
    }

    if (backoffMs > 0) {
      const waitMs = Math.min(backoffMs, Math.max(0, opts.deadlineAt - Date.now() - 2000));
      if (waitMs > 0) {
        await sleep(waitMs);
      }
    }

    const attemptRemaining = opts.deadlineAt - Date.now();
    if (attemptRemaining <= 1500) {
      break;
    }

    usedModel = model;
    try {
      response = await invokeSingleModel(opts.ai, model, opts, attemptRemaining);
      lastError = null;
      break;
    } catch (err) {
      lastError = err;
      if (isQuotaError(err)) {
        quotaExhaustedUntil.set(model, Date.now() + 15 * 60 * 1000);
        continue;
      }
      if (isTransientError(err)) {
        continue;
      }
      throw new Error(formatGeminiError(err));
    }
  }

  if (!response) {
    throw new Error(formatGeminiError(lastError ?? new Error('Gemini API call failed after retries.')));
  }

  const durationMs = Date.now() - startedAt;

  const rawOutput = (response.text ?? '{}').trim();
  const usage = response.usageMetadata;
  const promptTokens = usage?.promptTokenCount ?? 0;
  const candidatesTokens = usage?.candidatesTokenCount ?? 0;
  const thoughtsTokens = usage?.thoughtsTokenCount ?? 0;
  const totalTokens =
    usage?.totalTokenCount ?? promptTokens + candidatesTokens + thoughtsTokens;

  const tokens: TokenUsage = {
    promptTokens,
    candidatesTokens,
    thoughtsTokens,
    totalTokens,
  };

  let parsed: T;
  try {
    parsed = JSON.parse(rawOutput) as T;
  } catch (err) {
    throw new Error(
      `Model call #${opts.callNumber} (${opts.area}) returned invalid JSON: ${(err as Error).message}`
    );
  }

  const conflictNotes = extractConflicts(parsed);

  const traceEntry: TraceEntry = {
    callNumber: opts.callNumber,
    phase: opts.phase,
    updateBatchIndex: opts.updateBatchIndex,
    modelName: usedModel,
    area: opts.area,
    input: opts.prompt,
    output: rawOutput,
    tokens,
    durationMs,
    timestamp: new Date().toISOString(),
    conflictNotes,
  };

  return { parsed, traceEntry };
}

interface ReadingOutput {
  parameters: EventParameters;
  messageAssessments: Array<{
    messageId: string;
    sender: string;
    channel: string;
    language: 'English' | 'Roman Urdu' | 'Mixed' | 'Other';
    status: 'accepted' | 'outdated' | 'irrelevant' | 'rejected_conflict';
    summary: string;
    affectedAreas: PlanArea[];
    reason: string;
    supersededById?: string;
  }>;
  factsByArea: {
    venue: string[];
    schedule: string[];
    food: string[];
    judging: string[];
    budget: string[];
    generalAndNovelConstraints: string[];
  };
  conflictSummary: string[];
}

const READING_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    parameters: {
      type: Type.OBJECT,
      properties: {
        eventName: { type: Type.STRING },
        city: { type: Type.STRING },
        format: { type: Type.STRING },
        targetStudents: { type: Type.INTEGER },
        targetTeams: { type: Type.INTEGER },
        targetHours: { type: Type.NUMBER },
        totalStaffAndJudges: { type: Type.INTEGER },
        novelConstraints: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: [
        'eventName',
        'city',
        'format',
        'targetStudents',
        'targetTeams',
        'targetHours',
        'totalStaffAndJudges',
        'novelConstraints',
      ],
    },
    messageAssessments: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          messageId: { type: Type.STRING },
          sender: { type: Type.STRING },
          channel: { type: Type.STRING },
          language: {
            type: Type.STRING,
            enum: ['English', 'Roman Urdu', 'Mixed', 'Other'],
          },
          status: {
            type: Type.STRING,
            enum: ['accepted', 'outdated', 'irrelevant', 'rejected_conflict'],
          },
          summary: { type: Type.STRING },
          affectedAreas: {
            type: Type.ARRAY,
            items: {
              type: Type.STRING,
              enum: ['venue', 'schedule', 'food', 'judging', 'budget'],
            },
          },
          reason: { type: Type.STRING },
          supersededById: { type: Type.STRING },
        },
        required: [
          'messageId',
          'sender',
          'channel',
          'language',
          'status',
          'summary',
          'affectedAreas',
          'reason',
        ],
      },
    },
    factsByArea: {
      type: Type.OBJECT,
      properties: {
        venue: { type: Type.ARRAY, items: { type: Type.STRING } },
        schedule: { type: Type.ARRAY, items: { type: Type.STRING } },
        food: { type: Type.ARRAY, items: { type: Type.STRING } },
        judging: { type: Type.ARRAY, items: { type: Type.STRING } },
        budget: { type: Type.ARRAY, items: { type: Type.STRING } },
        generalAndNovelConstraints: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: [
        'venue',
        'schedule',
        'food',
        'judging',
        'budget',
        'generalAndNovelConstraints',
      ],
    },
    conflictSummary: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: ['parameters', 'messageAssessments', 'factsByArea', 'conflictSummary'],
};

const VENUE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    venueName: { type: Type.STRING },
    addressOrSector: { type: Type.STRING },
    capacitySeats: { type: Type.INTEGER },
    requiredCapacity: { type: Type.INTEGER },
    accessWindowStart: { type: Type.STRING },
    accessWindowEnd: { type: Type.STRING },
    lockdownCurfew: { type: Type.STRING },
    zones: { type: Type.ARRAY, items: { type: Type.STRING } },
    powerAndNetwork: { type: Type.STRING },
    accessibilityAndSafety: { type: Type.ARRAY, items: { type: Type.STRING } },
    venueCostPkr: { type: Type.NUMBER },
    constraintsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    notes: { type: Type.STRING },
    conflictDetected: { type: Type.STRING },
  },
  required: [
    'venueName',
    'addressOrSector',
    'capacitySeats',
    'requiredCapacity',
    'accessWindowStart',
    'accessWindowEnd',
    'lockdownCurfew',
    'zones',
    'powerAndNetwork',
    'accessibilityAndSafety',
    'venueCostPkr',
    'constraintsRespected',
    'notes',
  ],
};

const SCHEDULE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    eventDateNote: { type: Type.STRING },
    doorsOpen: { type: Type.STRING },
    hardExitBy: { type: Type.STRING },
    coreEventDurationMinutes: { type: Type.INTEGER },
    slots: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          startTime: { type: Type.STRING },
          endTime: { type: Type.STRING },
          startMinuteOfDay: { type: Type.INTEGER },
          endMinuteOfDay: { type: Type.INTEGER },
          durationMinutes: { type: Type.INTEGER },
          activity: { type: Type.STRING },
          zone: { type: Type.STRING },
          owner: { type: Type.STRING },
          constraintsNote: { type: Type.STRING },
        },
        required: [
          'id',
          'startTime',
          'endTime',
          'startMinuteOfDay',
          'endMinuteOfDay',
          'durationMinutes',
          'activity',
          'zone',
          'owner',
          'constraintsNote',
        ],
      },
    },
    constraintsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    conflictDetected: { type: Type.STRING },
  },
  required: [
    'eventDateNote',
    'doorsOpen',
    'hardExitBy',
    'coreEventDurationMinutes',
    'slots',
    'constraintsRespected',
  ],
};

const FOOD_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    vendor: { type: Type.STRING },
    totalHeadcountCovered: { type: Type.INTEGER },
    studentsCount: { type: Type.INTEGER },
    judgesAndVolunteersCount: { type: Type.INTEGER },
    halalCertified: { type: Type.BOOLEAN },
    allergenFreeGuarantee: { type: Type.STRING },
    vegetarianBoxes: { type: Type.INTEGER },
    standardBoxes: { type: Type.INTEGER },
    servingWindow: { type: Type.STRING },
    servingZone: { type: Type.STRING },
    items: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          item: { type: Type.STRING },
          quantity: { type: Type.INTEGER },
          unitCostPkr: { type: Type.NUMBER },
          totalCostPkr: { type: Type.NUMBER },
          dietaryTag: { type: Type.STRING },
        },
        required: ['item', 'quantity', 'unitCostPkr', 'totalCostPkr', 'dietaryTag'],
      },
    },
    totalFoodCostPkr: { type: Type.NUMBER },
    constraintsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    conflictDetected: { type: Type.STRING },
  },
  required: [
    'vendor',
    'totalHeadcountCovered',
    'studentsCount',
    'judgesAndVolunteersCount',
    'halalCertified',
    'allergenFreeGuarantee',
    'vegetarianBoxes',
    'standardBoxes',
    'servingWindow',
    'servingZone',
    'items',
    'totalFoodCostPkr',
    'constraintsRespected',
  ],
};

const JUDGING_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    totalTeams: { type: Type.INTEGER },
    parallelPanels: { type: Type.INTEGER },
    teamsPerPanel: { type: Type.INTEGER },
    minutesPerTeam: { type: Type.NUMBER },
    judgingWindowMinutes: { type: Type.INTEGER },
    totalJudges: { type: Type.INTEGER },
    judgeBreakdown: { type: Type.ARRAY, items: { type: Type.STRING } },
    panelAssignments: { type: Type.ARRAY, items: { type: Type.STRING } },
    rubricCriteria: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          criterion: { type: Type.STRING },
          weightPercent: { type: Type.NUMBER },
          description: { type: Type.STRING },
        },
        required: ['criterion', 'weightPercent', 'description'],
      },
    },
    prizesAndHonorariaPkr: { type: Type.NUMBER },
    prizesBreakdown: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          amountPkr: { type: Type.NUMBER },
        },
        required: ['label', 'amountPkr'],
      },
    },
    constraintsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    mathVerificationNote: { type: Type.STRING },
    conflictDetected: { type: Type.STRING },
  },
  required: [
    'totalTeams',
    'parallelPanels',
    'teamsPerPanel',
    'minutesPerTeam',
    'judgingWindowMinutes',
    'totalJudges',
    'judgeBreakdown',
    'panelAssignments',
    'rubricCriteria',
    'prizesAndHonorariaPkr',
    'prizesBreakdown',
    'constraintsRespected',
    'mathVerificationNote',
  ],
};

const BUDGET_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    currency: { type: Type.STRING },
    hardBudgetCap: { type: Type.NUMBER },
    totalPlannedSpend: { type: Type.NUMBER },
    remainingBuffer: { type: Type.NUMBER },
    lineItems: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: {
            type: Type.STRING,
            enum: ['venue', 'schedule', 'food', 'judging', 'budget', 'operations', 'contingency'],
          },
          description: { type: Type.STRING },
          amountPkr: { type: Type.NUMBER },
          sourceMessageId: { type: Type.STRING },
        },
        required: ['category', 'description', 'amountPkr', 'sourceMessageId'],
      },
    },
    fundingSources: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          source: { type: Type.STRING },
          amountPkr: { type: Type.NUMBER },
        },
        required: ['source', 'amountPkr'],
      },
    },
    constraintsRespected: { type: Type.ARRAY, items: { type: Type.STRING } },
    conflictDetected: { type: Type.STRING },
  },
  required: [
    'currency',
    'hardBudgetCap',
    'totalPlannedSpend',
    'remainingBuffer',
    'lineItems',
    'fundingSources',
    'constraintsRespected',
  ],
};

function formatRawMessagesForPrompt(messages: RawMessage[]): string {
  return messages
    .map((m) => `[${m.id}] (Channel hint: ${m.channelHint})\n${m.rawText}`)
    .join('\n\n---\n\n');
}

function mergeAssessments(
  rawMessages: RawMessage[],
  modelAssessments: ReadingOutput['messageAssessments']
): MessageAssessment[] {
  const byId = new Map(modelAssessments.map((a) => [a.messageId, a]));
  return rawMessages.map((msg) => {
    const assessed = byId.get(msg.id);
    if (!assessed) {
      return {
        messageId: msg.id,
        rawText: msg.rawText,
        sender: msg.senderHint,
        channel: msg.channelHint,
        language: 'English',
        status: 'irrelevant',
        summary: 'Not referenced in extracted active constraints.',
        affectedAreas: [],
        reason: 'Message did not contribute actionable constraints.',
      };
    }
    return {
      messageId: msg.id,
      rawText: msg.rawText,
      sender: assessed.sender || msg.senderHint,
      channel: assessed.channel || msg.channelHint,
      language: assessed.language,
      status: assessed.status,
      summary: assessed.summary,
      affectedAreas: assessed.affectedAreas,
      reason: assessed.reason,
      supersededById: assessed.supersededById || undefined,
    };
  });
}

export async function runFullPlan(
  rawPackText: string,
  deadlineMs = 115_000
): Promise<AgentSessionState> {
  const startedAt = Date.now();
  const deadlineAt = startedAt + deadlineMs;
  const ai = getClient();

  const rawMessages = parseMessagePack(rawPackText, 1);
  if (rawMessages.length === 0) {
    throw new Error('The provided message pack is empty. Please provide at least one message.');
  }

  const trace: TraceEntry[] = [];
  let callCounter = 0;

  // 1. READING CALL (uses PRIMARY_MODEL with automatic fallback to LITE_MODEL on 429)
  callCounter += 1;
  const readingPrompt = `Read the following ${rawMessages.length} verbatim messages from a hackathon planning pack (English and/or Roman Urdu).
Baseline mission context (unless authoritative messages specify updated figures): 4-hour physical hackathon in Islamabad for 150 students in 50 teams.
Classify EVERY message ID (${rawMessages.map((m) => m.id).join(', ')}):
- "accepted": valid, current, authoritative fact or constraint.
- "outdated": superseded by a newer/corrected message (cite supersededById).
- "irrelevant": spam, casual banter, off-topic chatter.
- "rejected_conflict": contradicts a hard hackathon rule (e.g., 4-hour physical Islamabad event, 150 students / 50 teams), physical impossibility, unverified override, or mathematical/budget/schedule impossibility. Give exact rejection reason.

Extract ALL facts and constraints faithfully from the messages (including novel constraints such as prayer breaks, allergies, gender spaces, accessibility, sponsor conditions, power/internet, curfew, contingency reserves, etc.). NEVER invent facts not present in the messages.
IMPORTANT: Whenever a message states a cost/price for venue, food, or judging/prizes, include that exact cost fact inside BOTH that area's factsByArea array (venue/food/judging) AND factsByArea.budget so each area agent has its exact pricing.

MESSAGES:
${formatRawMessagesForPrompt(rawMessages)}`;

  const readingStep = await executeTrackedModelCall<ReadingOutput>(
    {
      ai,
      preferredModel: PRIMARY_MODEL,
      area: 'reading',
      phase: 'initial',
      callNumber: callCounter,
      systemInstruction:
        'You are the Reading & Constraint Extraction Agent for an Islamabad physical hackathon planning system. You fluently understand English and Roman Urdu. Extract only facts present in the text, resolve superseding updates, reject rule conflicts with clear reasons, and preserve exact numbers.',
      prompt: readingPrompt,
      responseSchema: READING_SCHEMA,
      deadlineAt,
      thinkingLevel: ThinkingLevel.MEDIUM,
    },
    (out) => {
      const notes: string[] = [];
      for (const a of out.messageAssessments) {
        if (a.status === 'rejected_conflict' || a.status === 'outdated') {
          notes.push(`${a.messageId} [${a.status}]: ${a.reason}`);
        }
      }
      if (notes.length === 0 && out.conflictSummary?.length) {
        notes.push(...out.conflictSummary);
      }
      return notes;
    }
  );
  trace.push(readingStep.traceEntry);

  const reading = readingStep.parsed;
  const assessments = mergeAssessments(rawMessages, reading.messageAssessments);
  const novelList = reading.factsByArea.generalAndNovelConstraints.join('\n- ');
  const budgetFactsContext = reading.factsByArea.budget.join('\n- ');

  // 2. VENUE CALL (uses LITE_MODEL with fallback)
  callCounter += 1;
  const venuePrompt = `Plan the VENUE area using ONLY the accepted facts below.
Event Parameters: ${JSON.stringify(reading.parameters)}
Accepted Venue Facts:
- ${reading.factsByArea.venue.join('\n- ')}
Pricing & Budget Context (extract ONLY the venue rent/cost for venueCostPkr, do NOT include food, prizes, or ops costs):
- ${budgetFactsContext}
Novel & General Constraints:
- ${novelList}

Ensure capacitySeats >= requiredCapacity (students + staff/judges), specify zones, power/network, accessibility/safety, exact access window and lockdown curfew, and exact venueCostPkr matching ONLY the venue rent. Set conflictDetected to "" if there is no conflict.`;

  const venueStep = await executeTrackedModelCall<VenuePlan & { conflictDetected?: string }>(
    {
      ai,
      preferredModel: LITE_MODEL,
      area: 'venue',
      phase: 'initial',
      callNumber: callCounter,
      systemInstruction:
        'You are the Venue Planning Agent. Output a strictly valid venue plan respecting capacity, curfew, zones, power/WiFi, accessibility, and safety constraints. Return "" for conflictDetected when valid.',
      prompt: venuePrompt,
      responseSchema: VENUE_SCHEMA,
      deadlineAt,
      thinkingLevel: ThinkingLevel.LOW,
    },
    (out) => sanitizeConflictNote(out.conflictDetected)
  );
  trace.push(venueStep.traceEntry);
  const venuePlan: VenuePlan = venueStep.parsed;

  // 3. SCHEDULE CALL
  callCounter += 1;
  const schedulePrompt = `Plan the SCHEDULE area strictly respecting the venue window and all timing/prayer/sponsor/hacking constraints.
Event Parameters: ${JSON.stringify(reading.parameters)}
Confirmed Venue Window: Open ${venuePlan.accessWindowStart}, Close/Lockdown ${venuePlan.lockdownCurfew || venuePlan.accessWindowEnd}
Accepted Schedule Facts:
- ${reading.factsByArea.schedule.join('\n- ')}
Novel & General Constraints:
- ${novelList}

CRITICAL RULES:
- Every slot must be chronological with startMinuteOfDay < endMinuteOfDay (minutes from midnight, e.g., 1:00 PM = 780, 6:30 PM = 1110) and no overlaps.
- First slot >= venue accessWindowStart; last slot <= venue lockdownCurfew.
- Include any mandatory prayer break, sponsor intro slot, meal service window, hacking blocks, judging window, and awards/cleanup before hard exit.
- Set conflictDetected to "" if valid.`;

  const scheduleStep = await executeTrackedModelCall<SchedulePlan & { conflictDetected?: string }>(
    {
      ai,
      preferredModel: LITE_MODEL,
      area: 'schedule',
      phase: 'initial',
      callNumber: callCounter,
      systemInstruction:
        'You are the Schedule Planning Agent. Produce a mathematically consistent, non-overlapping minute-by-minute schedule fitting strictly inside the venue curfew. Return "" for conflictDetected when valid.',
      prompt: schedulePrompt,
      responseSchema: SCHEDULE_SCHEMA,
      deadlineAt,
      thinkingLevel: ThinkingLevel.MEDIUM,
    },
    (out) => sanitizeConflictNote(out.conflictDetected)
  );
  trace.push(scheduleStep.traceEntry);
  const schedulePlan: SchedulePlan = scheduleStep.parsed;

  // 4. FOOD CALL
  callCounter += 1;
  const foodPrompt = `Plan the FOOD & CATERING area using ONLY accepted facts.
Event Parameters: ${JSON.stringify(reading.parameters)}
Venue Dining Constraints: Zones=${JSON.stringify(venuePlan.zones)}; Safety=${JSON.stringify(venuePlan.accessibilityAndSafety)}
Schedule Reference: ${JSON.stringify(schedulePlan.slots.map((s) => `${s.startTime}-${s.endTime}: ${s.activity}`))}
Accepted Food Facts:
- ${reading.factsByArea.food.join('\n- ')}
Pricing & Budget Context (use ONLY food/catering unit rates):
- ${budgetFactsContext}
Novel & General Constraints:
- ${novelList}

CRITICAL RULES:
- Cover ALL students (${reading.parameters.targetStudents}) PLUS staff/judges (${reading.parameters.totalStaffAndJudges}) if specified in food facts.
- Respect minimum vegetarian counts, halal requirements, nut/allergen bans, and dining zone rules (e.g. pre-packed boxes, no open flames).
- Include ONLY food, meal boxes, snacks, and beverage items in items[] (NEVER put emergency contingency reserves or non-food ops items inside food items[]).
- Ensure totalFoodCostPkr equals the exact sum of items' totalCostPkr. Set conflictDetected to "" if valid.`;

  const foodStep = await executeTrackedModelCall<FoodPlan & { conflictDetected?: string }>(
    {
      ai,
      preferredModel: LITE_MODEL,
      area: 'food',
      phase: 'initial',
      callNumber: callCounter,
      systemInstruction:
        'You are the Food & Catering Planning Agent. Ensure complete headcount coverage, strict dietary/allergy compliance, and exact line-item arithmetic. Return "" for conflictDetected when valid.',
      prompt: foodPrompt,
      responseSchema: FOOD_SCHEMA,
      deadlineAt,
      thinkingLevel: ThinkingLevel.LOW,
    },
    (out) => sanitizeConflictNote(out.conflictDetected)
  );
  trace.push(foodStep.traceEntry);
  const foodPlan: FoodPlan = foodStep.parsed;

  // 5. JUDGING CALL
  callCounter += 1;
  const judgingPrompt = `Plan the JUDGING area using ONLY accepted facts.
Event Parameters: ${JSON.stringify(reading.parameters)}
Judging Window from Schedule: ${JSON.stringify(schedulePlan.slots.filter((s) => s.activity.toLowerCase().includes('judg') || s.activity.toLowerCase().includes('demo') || s.activity.toLowerCase().includes('pitch')))}
Accepted Judging Facts:
- ${reading.factsByArea.judging.join('\n- ')}
Pricing & Budget Context (use ONLY exact prize amounts and judge honoraria from the messages; do NOT invent larger prizes):
- ${budgetFactsContext}
Novel & General Constraints:
- ${novelList}

CRITICAL MATH CHECK:
- totalTeams (${reading.parameters.targetTeams}) * minutesPerTeam MUST BE <= parallelPanels * judgingWindowMinutes.
- Include sponsor judge obligations, exact judge stipends/honoraria, and exact prizesBreakdown summing to prizesAndHonorariaPkr. Set conflictDetected to "" if valid.`;

  const judgingStep = await executeTrackedModelCall<JudgingPlan & { conflictDetected?: string }>(
    {
      ai,
      preferredModel: LITE_MODEL,
      area: 'judging',
      phase: 'initial',
      callNumber: callCounter,
      systemInstruction:
        'You are the Judging & Scoring Operations Agent. Prove throughput math fits the allotted judging window across parallel panels and use ONLY the exact prizes and honoraria stated in the messages. Return "" for conflictDetected when valid.',
      prompt: judgingPrompt,
      responseSchema: JUDGING_SCHEMA,
      deadlineAt,
      thinkingLevel: ThinkingLevel.MEDIUM,
    },
    (out) => sanitizeConflictNote(out.conflictDetected)
  );
  trace.push(judgingStep.traceEntry);
  const judgingPlan: JudgingPlan = judgingStep.parsed;

  // 6. BUDGET CALL
  callCounter += 1;
  const budgetPrompt = `Reconcile the complete BUDGET using the confirmed area costs and all accepted budget/operations facts.
Accepted Budget & Operations Facts:
- ${reading.factsByArea.budget.join('\n- ')}
Novel & General Constraints:
- ${novelList}

Confirmed Area Costs:
- Venue Cost: ${venuePlan.venueCostPkr} (${venuePlan.venueName})
- Food Total Cost: ${foodPlan.totalFoodCostPkr} (${foodPlan.items.map((i) => `${i.item}: ${i.totalCostPkr}`).join(', ')})
- Judging Prizes & Stipends: ${judgingPlan.prizesAndHonorariaPkr} (${judgingPlan.prizesBreakdown.map((p) => `${p.label}: ${p.amountPkr}`).join(', ')})

CRITICAL RULES:
- Include all additional ops/printing/backup/volunteer/contingency line items stated in the pack.
- totalPlannedSpend MUST equal the exact sum of lineItems' amountPkr.
- totalPlannedSpend MUST BE <= hardBudgetCap.
- remainingBuffer = hardBudgetCap - totalPlannedSpend. Set conflictDetected to "" if valid.`;

  const budgetStep = await executeTrackedModelCall<BudgetPlan & { conflictDetected?: string }>(
    {
      ai,
      preferredModel: PRIMARY_MODEL,
      area: 'budget',
      phase: 'initial',
      callNumber: callCounter,
      systemInstruction:
        'You are the Budget Reconciliation Agent. Sum every cost accurately, enforce the hard budget cap, preserve required contingency reserves, and cite sourceMessageId for each line item. Return "" for conflictDetected when valid.',
      prompt: budgetPrompt,
      responseSchema: BUDGET_SCHEMA,
      deadlineAt,
      thinkingLevel: ThinkingLevel.MEDIUM,
    },
    (out) => sanitizeConflictNote(out.conflictDetected)
  );
  trace.push(budgetStep.traceEntry);
  const budgetPlan: BudgetPlan = budgetStep.parsed;

  const plan: HackathonPlan = {
    parameters: reading.parameters,
    venue: venuePlan,
    schedule: schedulePlan,
    food: foodPlan,
    judging: judgingPlan,
    budget: budgetPlan,
  };

  const validation = validatePlanInvariants(plan);
  if (!validation.valid) {
    trace[trace.length - 1].conflictNotes.push(
      ...validation.errors.map((e) => `Invariant warning: ${e}`)
    );
  }

  return {
    sessionId: `sess-${Date.now()}`,
    createdAt: new Date(startedAt).toISOString(),
    updatedAt: new Date().toISOString(),
    updateCount: 0,
    rawMessages,
    assessments,
    plan,
    validation,
    trace,
    traceSummary: computeTokenTotals(trace),
    lastRunDurationMs: Date.now() - startedAt,
    lastRunError: null,
  };
}

interface UpdateTriageOutput {
  assessments: Array<{
    messageId: string;
    sender: string;
    channel: string;
    language: 'English' | 'Roman Urdu' | 'Mixed' | 'Other';
    status: 'accepted' | 'outdated' | 'irrelevant' | 'rejected_conflict';
    summary: string;
    affectedAreas: PlanArea[];
    reason: string;
    supersededById?: string;
  }>;
  shouldUpdatePlan: boolean;
  impactedAreasInOrder: PlanArea[];
  updateInstructionsByArea: {
    venue: string;
    schedule: string;
    food: string;
    judging: string;
    budget: string;
  };
  rejectionOrConflictReason: string;
}

const UPDATE_TRIAGE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    assessments: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          messageId: { type: Type.STRING },
          sender: { type: Type.STRING },
          channel: { type: Type.STRING },
          language: {
            type: Type.STRING,
            enum: ['English', 'Roman Urdu', 'Mixed', 'Other'],
          },
          status: {
            type: Type.STRING,
            enum: ['accepted', 'outdated', 'irrelevant', 'rejected_conflict'],
          },
          summary: { type: Type.STRING },
          affectedAreas: {
            type: Type.ARRAY,
            items: {
              type: Type.STRING,
              enum: ['venue', 'schedule', 'food', 'judging', 'budget'],
            },
          },
          reason: { type: Type.STRING },
          supersededById: { type: Type.STRING },
        },
        required: [
          'messageId',
          'sender',
          'channel',
          'language',
          'status',
          'summary',
          'affectedAreas',
          'reason',
        ],
      },
    },
    shouldUpdatePlan: { type: Type.BOOLEAN },
    impactedAreasInOrder: {
      type: Type.ARRAY,
      items: {
        type: Type.STRING,
        enum: ['venue', 'schedule', 'food', 'judging', 'budget'],
      },
    },
    updateInstructionsByArea: {
      type: Type.OBJECT,
      properties: {
        venue: { type: Type.STRING },
        schedule: { type: Type.STRING },
        food: { type: Type.STRING },
        judging: { type: Type.STRING },
        budget: { type: Type.STRING },
      },
      required: ['venue', 'schedule', 'food', 'judging', 'budget'],
    },
    rejectionOrConflictReason: { type: Type.STRING },
  },
  required: [
    'assessments',
    'shouldUpdatePlan',
    'impactedAreasInOrder',
    'updateInstructionsByArea',
    'rejectionOrConflictReason',
  ],
};

export async function runIncrementalUpdate(
  currentState: AgentSessionState,
  newRawText: string,
  deadlineMs = 55_000
): Promise<AgentSessionState> {
  if (!currentState.plan) {
    throw new Error('Cannot run an incremental update before an initial plan exists.');
  }

  const startedAt = Date.now();
  const deadlineAt = startedAt + deadlineMs;
  const ai = getClient();

  const nextStartIdx = currentState.rawMessages.length + 1;
  const newMessages = parseMessagePack(newRawText, nextStartIdx);
  if (newMessages.length === 0) {
    throw new Error('No message content provided for the update.');
  }

  const MAX_UPDATE_CALLS = 5;
  let callsInThisUpdate = 0;
  let nextCallNumber = currentState.trace.length + 1;
  const updateBatchIndex = currentState.updateCount + 1;
  const newTraceEntries: TraceEntry[] = [];

  // Call #1 of Update (<= 5 total): [reading] Triage & Conflict Check
  callsInThisUpdate += 1;
  const triagePrompt = `An active hackathon plan already exists. Evaluate the NEW incoming message(s) verbatim (English and/or Roman Urdu).
Determine if each new message is:
- "accepted": valid new requirement, correction, or constraint change.
- "irrelevant": spam or unrelated chatter.
- "outdated": superseded or stale compared to existing authoritative plan.
- "rejected_conflict": conflicts with core hackathon rules (e.g., 4-hour physical Islamabad event, 150 students in 50 teams, unless legitimately authorized), violates hard venue curfew/safety/dietary rules, breaks judging math, or violates the hard budget cap without an accompanying cap increase.

If ANY conflict/rejection occurs, set shouldUpdatePlan=false (unless another valid message in the batch requires an update) and state the exact conflict reason in rejectionOrConflictReason.
If valid update(s) apply, list ONLY the affected areas in dependency order (maximum 4 areas, prioritizing venue -> schedule -> food -> judging -> budget, always putting budget last if costs change).

CURRENT PLAN SUMMARY:
${JSON.stringify(currentState.plan)}

PRIOR ACCEPTED/REJECTED MESSAGES SUMMARY:
${currentState.assessments.map((a) => `${a.messageId} [${a.status}]: ${a.summary}`).join('\n')}

NEW INCOMING MESSAGE(S):
${formatRawMessagesForPrompt(newMessages)}`;

  const triageStep = await executeTrackedModelCall<UpdateTriageOutput>(
    {
      ai,
      preferredModel: PRIMARY_MODEL,
      area: 'reading',
      phase: 'update',
      updateBatchIndex,
      callNumber: nextCallNumber++,
      systemInstruction:
        'You are the Incremental Update Triage Agent. Protect plan validity above all else. Reject messages that conflict with rules or hard constraints with a crystal-clear reason. Only schedule impacted areas for update (max 4 area calls).',
      prompt: triagePrompt,
      responseSchema: UPDATE_TRIAGE_SCHEMA,
      deadlineAt,
      thinkingLevel: ThinkingLevel.MEDIUM,
    },
    (out) => {
      const notes: string[] = [];
      notes.push(...sanitizeConflictNote(out.rejectionOrConflictReason));
      for (const a of out.assessments) {
        if (a.status === 'rejected_conflict' || a.status === 'outdated') {
          notes.push(`${a.messageId} [${a.status}]: ${a.reason}`);
        }
      }
      return notes;
    }
  );
  newTraceEntries.push(triageStep.traceEntry);

  const triage = triageStep.parsed;
  const newAssessments = mergeAssessments(newMessages, triage.assessments);

  const candidatePlan: HackathonPlan = JSON.parse(JSON.stringify(currentState.plan)) as HackathonPlan;
  let abortedDueToConflict = false;
  let abortReason = '';
  let budgetUpdatedInLoop = false;

  if (triage.shouldUpdatePlan && triage.impactedAreasInOrder.length > 0) {
    const remainingCallBudget = MAX_UPDATE_CALLS - callsInThisUpdate;
    const areasToRun = triage.impactedAreasInOrder.slice(0, remainingCallBudget);

    for (const area of areasToRun) {
      if (callsInThisUpdate >= MAX_UPDATE_CALLS) {
        break;
      }
      callsInThisUpdate += 1;

      if (area === 'venue') {
        const step = await executeTrackedModelCall<VenuePlan & { conflictDetected?: string }>(
          {
            ai,
            preferredModel: LITE_MODEL,
            area: 'venue',
            phase: 'update',
            updateBatchIndex,
            callNumber: nextCallNumber++,
            systemInstruction:
              'You are updating the VENUE plan. If the new requirement violates physical capacity, safety, or core rules, report it in conflictDetected and keep the previous valid venue values.',
            prompt: `Current Venue Plan: ${JSON.stringify(candidatePlan.venue)}
Event Parameters: ${JSON.stringify(candidatePlan.parameters)}
Update Instruction: ${triage.updateInstructionsByArea.venue}
New Message(s): ${formatRawMessagesForPrompt(newMessages)}`,
            responseSchema: VENUE_SCHEMA,
            deadlineAt,
            thinkingLevel: ThinkingLevel.LOW,
          },
          (out) => sanitizeConflictNote(out.conflictDetected)
        );
        newTraceEntries.push(step.traceEntry);
        if (sanitizeConflictNote(step.parsed.conflictDetected).length > 0) {
          abortedDueToConflict = true;
          abortReason = step.parsed.conflictDetected!;
          break;
        }
        candidatePlan.venue = step.parsed;
      } else if (area === 'schedule') {
        const step = await executeTrackedModelCall<SchedulePlan & { conflictDetected?: string }>(
          {
            ai,
            preferredModel: LITE_MODEL,
            area: 'schedule',
            phase: 'update',
            updateBatchIndex,
            callNumber: nextCallNumber++,
            systemInstruction:
              'You are updating the SCHEDULE plan. Keep chronological continuity and stay strictly inside venue curfew. If impossible, set conflictDetected and preserve validity; otherwise set conflictDetected to "".',
            prompt: `Current Schedule Plan: ${JSON.stringify(candidatePlan.schedule)}
Venue Window: ${candidatePlan.venue.accessWindowStart} - ${candidatePlan.venue.lockdownCurfew || candidatePlan.venue.accessWindowEnd}
Update Instruction: ${triage.updateInstructionsByArea.schedule}
New Message(s): ${formatRawMessagesForPrompt(newMessages)}`,
            responseSchema: SCHEDULE_SCHEMA,
            deadlineAt,
            thinkingLevel: ThinkingLevel.MEDIUM,
          },
          (out) => sanitizeConflictNote(out.conflictDetected)
        );
        newTraceEntries.push(step.traceEntry);
        if (sanitizeConflictNote(step.parsed.conflictDetected).length > 0) {
          abortedDueToConflict = true;
          abortReason = step.parsed.conflictDetected!;
          break;
        }
        candidatePlan.schedule = step.parsed;
      } else if (area === 'food') {
        const step = await executeTrackedModelCall<FoodPlan & { conflictDetected?: string }>(
          {
            ai,
            preferredModel: LITE_MODEL,
            area: 'food',
            phase: 'update',
            updateBatchIndex,
            callNumber: nextCallNumber++,
            systemInstruction:
              'You are updating the FOOD plan. Preserve full headcount coverage, dietary/allergen guarantees, and exact item cost math. If the new request breaks a constraint, report conflictDetected; otherwise set conflictDetected to "".',
            prompt: `Current Food Plan: ${JSON.stringify(candidatePlan.food)}
Budget Cap Reference: ${candidatePlan.budget.hardBudgetCap} ${candidatePlan.budget.currency}
Update Instruction: ${triage.updateInstructionsByArea.food}
New Message(s): ${formatRawMessagesForPrompt(newMessages)}`,
            responseSchema: FOOD_SCHEMA,
            deadlineAt,
            thinkingLevel: ThinkingLevel.LOW,
          },
          (out) => sanitizeConflictNote(out.conflictDetected)
        );
        newTraceEntries.push(step.traceEntry);
        if (sanitizeConflictNote(step.parsed.conflictDetected).length > 0) {
          abortedDueToConflict = true;
          abortReason = step.parsed.conflictDetected!;
          break;
        }
        candidatePlan.food = step.parsed;
      } else if (area === 'judging') {
        const step = await executeTrackedModelCall<JudgingPlan & { conflictDetected?: string }>(
          {
            ai,
            preferredModel: LITE_MODEL,
            area: 'judging',
            phase: 'update',
            updateBatchIndex,
            callNumber: nextCallNumber++,
            systemInstruction:
              'You are updating the JUDGING plan. Verify teams * minutesPerTeam <= parallelPanels * judgingWindowMinutes. If impossible, report conflictDetected; otherwise set conflictDetected to "".',
            prompt: `Current Judging Plan: ${JSON.stringify(candidatePlan.judging)}
Schedule Judging Slots: ${JSON.stringify(candidatePlan.schedule.slots)}
Update Instruction: ${triage.updateInstructionsByArea.judging}
New Message(s): ${formatRawMessagesForPrompt(newMessages)}`,
            responseSchema: JUDGING_SCHEMA,
            deadlineAt,
            thinkingLevel: ThinkingLevel.MEDIUM,
          },
          (out) => sanitizeConflictNote(out.conflictDetected)
        );
        newTraceEntries.push(step.traceEntry);
        if (sanitizeConflictNote(step.parsed.conflictDetected).length > 0) {
          abortedDueToConflict = true;
          abortReason = step.parsed.conflictDetected!;
          break;
        }
        candidatePlan.judging = step.parsed;
      } else if (area === 'budget') {
        budgetUpdatedInLoop = true;
        const step = await executeTrackedModelCall<BudgetPlan & { conflictDetected?: string }>(
          {
            ai,
            preferredModel: PRIMARY_MODEL,
            area: 'budget',
            phase: 'update',
            updateBatchIndex,
            callNumber: nextCallNumber++,
            systemInstruction:
              'You are updating the BUDGET plan. Reconcile updated area costs against hardBudgetCap. If totalPlannedSpend would exceed hardBudgetCap and cannot be balanced without breaking mandatory commitments, report conflictDetected; otherwise set conflictDetected to "".',
            prompt: `Current Budget Plan: ${JSON.stringify(candidatePlan.budget)}
Updated Venue Cost: ${candidatePlan.venue.venueCostPkr}
Updated Food Cost: ${candidatePlan.food.totalFoodCostPkr}
Updated Judging Cost: ${candidatePlan.judging.prizesAndHonorariaPkr}
Update Instruction: ${triage.updateInstructionsByArea.budget}
New Message(s): ${formatRawMessagesForPrompt(newMessages)}`,
            responseSchema: BUDGET_SCHEMA,
            deadlineAt,
            thinkingLevel: ThinkingLevel.MEDIUM,
          },
          (out) => sanitizeConflictNote(out.conflictDetected)
        );
        newTraceEntries.push(step.traceEntry);
        if (sanitizeConflictNote(step.parsed.conflictDetected).length > 0) {
          abortedDueToConflict = true;
          abortReason = step.parsed.conflictDetected!;
          break;
        }
        candidatePlan.budget = step.parsed;
      }
    }

    // Auto-reconcile budget if another area changed costs and budget wasn't run yet (and call budget allows)
    const costChanged =
      candidatePlan.venue.venueCostPkr !== currentState.plan.venue.venueCostPkr ||
      candidatePlan.food.totalFoodCostPkr !== currentState.plan.food.totalFoodCostPkr ||
      candidatePlan.judging.prizesAndHonorariaPkr !== currentState.plan.judging.prizesAndHonorariaPkr;

    if (!abortedDueToConflict && costChanged && !budgetUpdatedInLoop && callsInThisUpdate < MAX_UPDATE_CALLS) {
      callsInThisUpdate += 1;
      const step = await executeTrackedModelCall<BudgetPlan & { conflictDetected?: string }>(
        {
          ai,
          preferredModel: PRIMARY_MODEL,
          area: 'budget',
          phase: 'update',
          updateBatchIndex,
          callNumber: nextCallNumber++,
          systemInstruction:
            'Reconcile the BUDGET after an upstream area cost update. If totalPlannedSpend exceeds hardBudgetCap and cannot be balanced, set conflictDetected; otherwise set conflictDetected to "".',
          prompt: `Current Budget Plan: ${JSON.stringify(candidatePlan.budget)}
Updated Venue Cost: ${candidatePlan.venue.venueCostPkr}
Updated Food Cost: ${candidatePlan.food.totalFoodCostPkr}
Updated Judging Cost: ${candidatePlan.judging.prizesAndHonorariaPkr}
New Message(s): ${formatRawMessagesForPrompt(newMessages)}`,
          responseSchema: BUDGET_SCHEMA,
          deadlineAt,
          thinkingLevel: ThinkingLevel.MEDIUM,
        },
        (out) => sanitizeConflictNote(out.conflictDetected)
      );
      newTraceEntries.push(step.traceEntry);
      if (sanitizeConflictNote(step.parsed.conflictDetected).length > 0) {
        abortedDueToConflict = true;
        abortReason = step.parsed.conflictDetected!;
      } else {
        candidatePlan.budget = step.parsed;
      }
    }
  }

  // Deterministic invariant guard: NEVER commit an invalid candidate plan!
  let finalPlan = currentState.plan;
  let finalValidation = currentState.validation ?? validatePlanInvariants(currentState.plan);
  let finalNewAssessments = newAssessments;

  if (triage.shouldUpdatePlan && !abortedDueToConflict) {
    const candidateValidation = validatePlanInvariants(candidatePlan);
    if (candidateValidation.valid || !finalValidation.valid) {
      finalPlan = candidatePlan;
      finalValidation = candidateValidation;
    } else {
      abortedDueToConflict = true;
      abortReason = `Plan invariant check rejected update to keep plan valid: ${candidateValidation.errors.join(' | ')}`;
      if (newTraceEntries.length > 0) {
        newTraceEntries[newTraceEntries.length - 1].conflictNotes.push(abortReason);
      }
    }
  }

  if (abortedDueToConflict) {
    finalPlan = currentState.plan;
    finalValidation = currentState.validation ?? validatePlanInvariants(currentState.plan);
    finalNewAssessments = newAssessments.map((a) =>
      a.status === 'accepted'
        ? {
            ...a,
            status: 'rejected_conflict',
            reason: abortReason || 'Rejected to preserve plan validity.',
          }
        : a
    );
  }

  const combinedTrace = [...currentState.trace, ...newTraceEntries];

  return {
    ...currentState,
    updatedAt: new Date().toISOString(),
    updateCount: updateBatchIndex,
    rawMessages: [...currentState.rawMessages, ...newMessages],
    assessments: [...currentState.assessments, ...finalNewAssessments],
    plan: finalPlan,
    validation: finalValidation,
    trace: combinedTrace,
    traceSummary: computeTokenTotals(combinedTrace),
    lastRunDurationMs: Date.now() - startedAt,
    lastRunError: null,
  };
}
