import type { HackathonPlan, InvariantCheck, PlanValidationResult } from './types.ts';

export function parseTimeToMinutes(timeStr: string): number | null {
  if (!timeStr) return null;
  const trimmed = timeStr.trim();

  // 12-hour format e.g. "1:30 PM", "12:30 PM", "6:30 pm"
  const match12 = trimmed.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (match12) {
    let hours = Number(match12[1]);
    const mins = Number(match12[2]);
    const meridiem = match12[3].toUpperCase();
    if (hours < 1 || hours > 12 || mins < 0 || mins > 59) return null;
    if (meridiem === 'AM') {
      if (hours === 12) hours = 0;
    } else {
      if (hours !== 12) hours += 12;
    }
    return hours * 60 + mins;
  }

  // 24-hour format e.g. "13:30", "18:30"
  const match24 = trimmed.match(/^(\d{1,2}):(\d{2})$/);
  if (match24) {
    const hours = Number(match24[1]);
    const mins = Number(match24[2]);
    if (hours < 0 || hours > 23 || mins < 0 || mins > 59) return null;
    return hours * 60 + mins;
  }

  return null;
}

export function validatePlanInvariants(plan: HackathonPlan): PlanValidationResult {
  const checks: InvariantCheck[] = [];

  // 1. Venue capacity >= required capacity (students + staff/judges or students)
  const requiredMinSeats = Math.max(
    plan.parameters.targetStudents,
    plan.venue.requiredCapacity || plan.parameters.targetStudents
  );
  const venueCapacityOk = plan.venue.capacitySeats >= requiredMinSeats && plan.venue.capacitySeats > 0;
  checks.push({
    id: 'venue-capacity',
    area: 'venue',
    label: 'Venue Seating Capacity',
    passed: venueCapacityOk,
    detail: venueCapacityOk
      ? `${plan.venue.capacitySeats} seats available >= ${requiredMinSeats} required attendees.`
      : `Venue seats (${plan.venue.capacitySeats}) are below required attendees (${requiredMinSeats}).`,
  });

  // 2. Schedule chronological order and venue curfew bounds
  const slots = plan.schedule.slots ?? [];
  let chronologyOk = slots.length > 0;
  let chronologyDetail = `${slots.length} timeline slots ordered chronologically.`;
  for (let i = 0; i < slots.length; i++) {
    const s = slots[i];
    const start = Number.isFinite(s.startMinuteOfDay) && s.startMinuteOfDay > 0
      ? s.startMinuteOfDay
      : (parseTimeToMinutes(s.startTime) ?? -1);
    const end = Number.isFinite(s.endMinuteOfDay) && s.endMinuteOfDay > 0
      ? s.endMinuteOfDay
      : (parseTimeToMinutes(s.endTime) ?? -1);

    if (start < 0 || end <= start) {
      chronologyOk = false;
      chronologyDetail = `Invalid slot time range in "${s.activity}" (${s.startTime} - ${s.endTime}).`;
      break;
    }
    if (i > 0) {
      const prev = slots[i - 1];
      const prevEnd = Number.isFinite(prev.endMinuteOfDay) && prev.endMinuteOfDay > 0
        ? prev.endMinuteOfDay
        : (parseTimeToMinutes(prev.endTime) ?? -1);
      if (start < prevEnd) {
        chronologyOk = false;
        chronologyDetail = `Slot "${s.activity}" (${s.startTime}) overlaps preceding slot "${prev.activity}" ending at ${prev.endTime}.`;
        break;
      }
    }
  }
  checks.push({
    id: 'schedule-chronology',
    area: 'schedule',
    label: 'Timeline Continuity',
    passed: chronologyOk,
    detail: chronologyDetail,
  });

  // 3. Schedule fits inside venue access window / curfew
  const venueStart = parseTimeToMinutes(plan.venue.accessWindowStart);
  const venueEnd = parseTimeToMinutes(plan.venue.lockdownCurfew || plan.venue.accessWindowEnd);
  let curfewOk = true;
  let curfewDetail = 'Schedule fits within venue access and lockdown curfew.';
  if (slots.length > 0 && venueStart !== null && venueEnd !== null) {
    const firstStart = parseTimeToMinutes(slots[0].startTime) ?? slots[0].startMinuteOfDay;
    const lastEnd = parseTimeToMinutes(slots[slots.length - 1].endTime) ?? slots[slots.length - 1].endMinuteOfDay;
    if (firstStart < venueStart || lastEnd > venueEnd) {
      curfewOk = false;
      curfewDetail = `Schedule (${slots[0].startTime}–${slots[slots.length - 1].endTime}) exceeds venue window (${plan.venue.accessWindowStart}–${plan.venue.lockdownCurfew || plan.venue.accessWindowEnd}).`;
    }
  }
  checks.push({
    id: 'schedule-curfew',
    area: 'cross-area',
    label: 'Venue Curfew Alignment',
    passed: curfewOk,
    detail: curfewDetail,
  });

  // 4. Food headcount coverage >= target students
  const minFoodHeadcount = plan.parameters.targetStudents + plan.parameters.totalStaffAndJudges;
  const foodCoverageOk =
    plan.food.totalHeadcountCovered >= plan.parameters.targetStudents &&
    plan.food.totalHeadcountCovered >= minFoodHeadcount &&
    plan.food.vegetarianBoxes + plan.food.standardBoxes >= plan.food.totalHeadcountCovered;
  checks.push({
    id: 'food-coverage',
    area: 'food',
    label: 'Meal Headcount Coverage',
    passed: foodCoverageOk,
    detail: foodCoverageOk
      ? `${plan.food.totalHeadcountCovered} people covered (${plan.food.vegetarianBoxes} veg + ${plan.food.standardBoxes} standard boxes).`
      : `Meal coverage (${plan.food.totalHeadcountCovered}, boxes: ${plan.food.vegetarianBoxes + plan.food.standardBoxes}) does not cover required ${minFoodHeadcount} attendees.`,
  });

  // 5. Judging throughput math: teams * minutesPerTeam <= parallelPanels * judgingWindowMinutes
  const requiredTeamMinutes = plan.judging.totalTeams * plan.judging.minutesPerTeam;
  const availablePanelMinutes = plan.judging.parallelPanels * plan.judging.judgingWindowMinutes;
  const judgingMathOk =
    plan.judging.totalTeams >= plan.parameters.targetTeams &&
    plan.judging.parallelPanels > 0 &&
    plan.judging.minutesPerTeam > 0 &&
    requiredTeamMinutes <= availablePanelMinutes;
  checks.push({
    id: 'judging-throughput',
    area: 'judging',
    label: 'Judging Throughput Math',
    passed: judgingMathOk,
    detail: judgingMathOk
      ? `${plan.judging.totalTeams} teams × ${plan.judging.minutesPerTeam}m = ${requiredTeamMinutes} team-min <= ${plan.judging.parallelPanels} panels × ${plan.judging.judgingWindowMinutes}m (${availablePanelMinutes} capacity-min).`
      : `Judging capacity (${availablePanelMinutes} panel-min) cannot fit ${plan.judging.totalTeams} teams × ${plan.judging.minutesPerTeam}m (${requiredTeamMinutes} team-min).`,
  });

  // 6. Budget cap and line-item arithmetic
  const summedLineItems = (plan.budget.lineItems ?? []).reduce(
    (acc, item) => acc + (Number(item.amountPkr) || 0),
    0
  );
  const effectiveTotal = Math.max(summedLineItems, plan.budget.totalPlannedSpend);
  const budgetCapOk =
    plan.budget.hardBudgetCap > 0 &&
    effectiveTotal <= plan.budget.hardBudgetCap &&
    Math.abs(summedLineItems - plan.budget.totalPlannedSpend) <= 1;
  checks.push({
    id: 'budget-cap',
    area: 'budget',
    label: 'Budget Cap Reconciliation',
    passed: budgetCapOk,
    detail: budgetCapOk
      ? `${summedLineItems.toLocaleString()} ${plan.budget.currency} line-item total <= ${plan.budget.hardBudgetCap.toLocaleString()} ${plan.budget.currency} hard cap.`
      : `Budget mismatch or overrun: items sum to ${summedLineItems.toLocaleString()}, reported spend ${plan.budget.totalPlannedSpend.toLocaleString()}, hard cap ${plan.budget.hardBudgetCap.toLocaleString()}.`,
  });

  const errors = checks.filter((c) => !c.passed).map((c) => c.detail);

  return {
    valid: errors.length === 0,
    checks,
    errors,
  };
}
