import test from 'node:test';
import assert from 'node:assert/strict';
import { parseMessagePack } from './parser.ts';
import { parseTimeToMinutes, validatePlanInvariants } from './validator.ts';
import { computeTokenTotals, formatTraceText } from './traceFormatter.ts';
import type { HackathonPlan, TraceEntry } from './types.ts';

test('parseMessagePack splits horizontal rule packs verbatim and infers channels', () => {
  const raw = `---
From: Ali <ali@example.com>
Subject: Hall Booking
Hall seats 180.
---
[WhatsApp - 10:00 AM] Sara:
Bhai biryani 550 ki hai per plate.
---
[Notice - Security]
Gate closes at 6:30 PM sharp.`;

  const messages = parseMessagePack(raw);
  assert.equal(messages.length, 3);
  assert.equal(messages[0].id, 'M01');
  assert.equal(messages[0].channelHint, 'email');
  assert.ok(messages[0].rawText.includes('Hall seats 180.'));
  assert.equal(messages[1].id, 'M02');
  assert.equal(messages[1].channelHint, 'whatsapp');
  assert.ok(messages[1].rawText.includes('Bhai biryani 550 ki hai per plate.'));
  assert.equal(messages[2].id, 'M03');
  assert.equal(messages[2].channelHint, 'notice');
});

test('parseMessagePack preserves single message on update without splitting paragraphs', () => {
  const single = `[WhatsApp - 14 Nov] Sponsor Update:\nWe added PKR 20,000 for extra snacks.\n\nPlease update food plan.`;
  const messages = parseMessagePack(single, 11);
  assert.equal(messages.length, 1);
  assert.equal(messages[0].id, 'M11');
  assert.equal(messages[0].index, 11);
  assert.equal(messages[0].rawText, single);
});

test('parseTimeToMinutes parses 12h and 24h formats accurately', () => {
  assert.equal(parseTimeToMinutes('12:30 PM'), 750);
  assert.equal(parseTimeToMinutes('1:00 PM'), 780);
  assert.equal(parseTimeToMinutes('6:30 PM'), 1110);
  assert.equal(parseTimeToMinutes('18:30'), 1110);
  assert.equal(parseTimeToMinutes('12:00 AM'), 0);
  assert.equal(parseTimeToMinutes('invalid'), null);
});

function createValidSamplePlan(): HackathonPlan {
  return {
    parameters: {
      eventName: 'Islamabad 4-Hour Hackathon',
      city: 'Islamabad',
      format: '4-hour physical hackathon',
      targetStudents: 150,
      targetTeams: 50,
      targetHours: 4,
      totalStaffAndJudges: 20,
      novelConstraints: ['Asr prayer break 15 mins', 'Nut-free food boxes'],
    },
    venue: {
      venueName: 'Al-Hamra Tech Hub',
      addressOrSector: 'Sector F-8, Islamabad',
      capacitySeats: 200,
      requiredCapacity: 170,
      accessWindowStart: '12:30 PM',
      accessWindowEnd: '6:30 PM',
      lockdownCurfew: '6:30 PM',
      zones: ['Main Hall', 'Lobby Dining', 'Quiet Prayer Corner'],
      powerAndNetwork: '55 power strips + 2 backup routers',
      accessibilityAndSafety: ['Wheelchair ramp via Gate 2', 'No open flames'],
      venueCostPkr: 65000,
      constraintsRespected: ['Capacity >= 170', 'Curfew 6:30 PM'],
      notes: 'Confirmed',
    },
    schedule: {
      eventDateNote: 'Nov 2026',
      doorsOpen: '12:30 PM',
      hardExitBy: '6:30 PM',
      coreEventDurationMinutes: 240,
      slots: [
        {
          id: 'S1',
          startTime: '1:00 PM',
          endTime: '1:30 PM',
          startMinuteOfDay: 780,
          endMinuteOfDay: 810,
          durationMinutes: 30,
          activity: 'Check-in',
          zone: 'Lobby',
          owner: 'Ops',
          constraintsNote: '',
        },
        {
          id: 'S2',
          startTime: '4:45 PM',
          endTime: '5:45 PM',
          startMinuteOfDay: 1005,
          endMinuteOfDay: 1065,
          durationMinutes: 60,
          activity: 'Judging',
          zone: 'Main Hall',
          owner: 'Judges',
          constraintsNote: '5 parallel panels',
        },
      ],
      constraintsRespected: ['Ends before 6:30 PM'],
    },
    food: {
      vendor: 'Tehzeeb / Savour',
      totalHeadcountCovered: 170,
      studentsCount: 150,
      judgesAndVolunteersCount: 20,
      halalCertified: true,
      allergenFreeGuarantee: 'Nut-free verified',
      vegetarianBoxes: 25,
      standardBoxes: 145,
      servingWindow: '3:00 PM - 3:30 PM',
      servingZone: 'Lobby Dining Zone',
      items: [
        { item: 'Chicken Wrap Box', quantity: 145, unitCostPkr: 550, totalCostPkr: 79750, dietaryTag: 'Halal' },
        { item: 'Veg Falafel Box', quantity: 25, unitCostPkr: 500, totalCostPkr: 12500, dietaryTag: 'Vegetarian' },
      ],
      totalFoodCostPkr: 92250,
      constraintsRespected: ['>= 25 veg boxes', 'Nut-free'],
    },
    judging: {
      totalTeams: 50,
      parallelPanels: 5,
      teamsPerPanel: 10,
      minutesPerTeam: 6,
      judgingWindowMinutes: 60,
      totalJudges: 10,
      judgeBreakdown: ['6 External', '2 Sponsor', '2 Faculty'],
      panelAssignments: ['Panel A: 10 teams', 'Panel B: 10 teams', 'Panel C: 10 teams', 'Panel D: 10 teams', 'Panel E: 10 teams'],
      rubricCriteria: [{ criterion: 'Execution', weightPercent: 100, description: 'Working demo' }],
      prizesAndHonorariaPkr: 78000,
      prizesBreakdown: [
        { label: '1st Prize', amountPkr: 30000 },
        { label: '2nd Prize', amountPkr: 20000 },
        { label: '3rd Prize', amountPkr: 10000 },
        { label: 'External Judge Stipends', amountPkr: 18000 },
      ],
      constraintsRespected: ['50 teams judged in 60m'],
      mathVerificationNote: '50 * 6 = 300 <= 5 * 60',
    },
    budget: {
      currency: 'PKR',
      hardBudgetCap: 250000,
      totalPlannedSpend: 235250,
      remainingBuffer: 14750,
      lineItems: [
        { category: 'venue', description: 'Venue Rent', amountPkr: 65000, sourceMessageId: 'M02' },
        { category: 'food', description: 'Meals', amountPkr: 92250, sourceMessageId: 'M07' },
        { category: 'judging', description: 'Prizes & Stipends', amountPkr: 78000, sourceMessageId: 'M08' },
      ],
      fundingSources: [
        { source: 'University', amountPkr: 180000 },
        { source: 'CloudPak', amountPkr: 70000 },
      ],
      constraintsRespected: ['Total <= 250,000 PKR'],
    },
  };
}

test('validatePlanInvariants passes for a consistent plan and catches math/curfew violations', () => {
  const validPlan = createValidSamplePlan();
  const res = validatePlanInvariants(validPlan);
  assert.equal(res.valid, true);
  assert.equal(res.errors.length, 0);

  // Break judging throughput (1 panel instead of 5)
  const badJudging = createValidSamplePlan();
  badJudging.judging.parallelPanels = 1;
  const badJudgingRes = validatePlanInvariants(badJudging);
  assert.equal(badJudgingRes.valid, false);
  assert.ok(badJudgingRes.errors.some((e) => e.includes('Judging capacity')));

  // Break budget cap
  const overBudget = createValidSamplePlan();
  overBudget.budget.hardBudgetCap = 200000;
  const overBudgetRes = validatePlanInvariants(overBudget);
  assert.equal(overBudgetRes.valid, false);
  assert.ok(overBudgetRes.errors.some((e) => e.includes('Budget')));
});

test('computeTokenTotals and formatTraceText format numbered calls and end with Total Tokens', () => {
  const entries: TraceEntry[] = [
    {
      callNumber: 1,
      phase: 'initial',
      modelName: 'gemini-4-hydrogen',
      area: 'reading',
      input: 'Read pack',
      output: '{"ok":true}',
      tokens: { promptTokens: 500, candidatesTokens: 200, thoughtsTokens: 100, totalTokens: 800 },
      durationMs: 1200,
      timestamp: '2026-11-18T00:00:00Z',
      conflictNotes: ['Rejected M09: Conflicts with 4-hour rule'],
    },
    {
      callNumber: 2,
      phase: 'initial',
      modelName: 'gemini-4-hydrogen',
      area: 'venue',
      input: 'Plan venue',
      output: '{"venue":"Al-Hamra"}',
      tokens: { promptTokens: 300, candidatesTokens: 150, thoughtsTokens: 50, totalTokens: 500 },
      durationMs: 900,
      timestamp: '2026-11-18T00:00:02Z',
      conflictNotes: [],
    },
  ];

  const totals = computeTokenTotals(entries);
  assert.equal(totals.totalCalls, 2);
  assert.equal(totals.totalPromptTokens, 800);
  assert.equal(totals.totalCandidatesTokens, 350);
  assert.equal(totals.totalThoughtsTokens, 150);
  assert.equal(totals.grandTotalTokens, 1300);

  const formatted = formatTraceText(entries, totals);
  assert.ok(formatted.includes('Model Call #1'));
  assert.ok(formatted.includes('Area: reading'));
  assert.ok(formatted.includes('Rejected M09: Conflicts with 4-hour rule'));
  assert.ok(formatted.trim().endsWith('Total Tokens: 1300'));
});
