import type { RawMessage } from './types.ts';

function inferChannel(text: string): RawMessage['channelHint'] {
  const lower = text.toLowerCase();
  if (lower.includes('whatsapp') || /^\[\s*whatsapp/im.test(text)) {
    return 'whatsapp';
  }
  if (
    /^from:\s/im.test(text) ||
    /^subject:\s/im.test(text) ||
    /^[a-z0-9._%+-]+@[a-z0-9.-]+/im.test(text)
  ) {
    return 'email';
  }
  if (/^\[?\s*notice/im.test(text) || /^mandatory\s/im.test(text)) {
    return 'notice';
  }
  return 'unknown';
}

function inferSender(text: string): string {
  const fromMatch = text.match(/^From:\s*(.+)$/im);
  if (fromMatch?.[1]) {
    return fromMatch[1].trim();
  }
  const bracketMatch = text.match(/^\[(?:WhatsApp|Notice|Email|SMS|Message)[^\]]*\]\s*([^\n:]{2,60}):?/im);
  if (bracketMatch?.[1]) {
    return bracketMatch[1].trim();
  }
  const firstLine = text.split('\n')[0]?.trim() ?? 'Unknown Sender';
  return firstLine.slice(0, 64);
}

/**
 * Splits a raw text file or pasted pack into individual verbatim messages.
 * Preserves every character of each message without injecting hints or rewriting facts.
 */
export function parseMessagePack(rawText: string, startIndex = 1): RawMessage[] {
  const normalized = rawText.replace(/\r\n/g, '\n').trim();
  if (!normalized) {
    return [];
  }

  let chunks: string[] = [];

  // 1. Check for explicit horizontal rule separators (---, ===, ***, ___)
  const hrSplitPattern = /(?:^|\n)\s*(?:-{3,}|={3,}|\*{3,}|_{3,})(?:\s*(?:Message|Email|WhatsApp|Notice|Msg)?\s*#?\d*\s*(?:-{3,}|={3,}|\*{3,}|_{3,})?)?\s*(?:\n|$)/gi;
  if (hrSplitPattern.test(normalized)) {
    chunks = normalized
      .split(/(?:^|\n)\s*(?:-{3,}|={3,}|\*{3,}|_{3,})(?:\s*(?:Message|Email|WhatsApp|Notice|Msg)?\s*#?\d*\s*(?:-{3,}|={3,}|\*{3,}|_{3,})?)?\s*(?:\n|$)/gi)
      .map((c) => c.trim())
      .filter((c) => c.length > 0);
  } else {
    // 2. Check for explicit message headers like "Message 1:", "[Message 1]", "Email 1:", "[WhatsApp ...]", "From: ..."
    const headerSplitPattern = /\n(?=\s*(?:\[(?:Message|Msg|WhatsApp|Notice|Email|SMS)\b|\b(?:Message|Msg|Email|Notice)\s*#?\d+\s*[:\]]|From:\s))/gi;
    const byHeaders = normalized
      .split(headerSplitPattern)
      .map((c) => c.trim())
      .filter((c) => c.length > 0);

    if (byHeaders.length > 1) {
      chunks = byHeaders;
    } else {
      // 3. Check for numbered message blocks ("1) ...", "1. ...") separated by blank lines
      const numberedSplit = normalized
        .split(/\n\s*\n(?=\s*(?:\d+[.)]\s+|#\d+\s+))/g)
        .map((c) => c.trim())
        .filter((c) => c.length > 0);

      if (numberedSplit.length > 1) {
        chunks = numberedSplit;
      } else {
        // 4. Single message (or cohesive single block)
        chunks = [normalized];
      }
    }
  }

  return chunks.map((chunk, idx) => {
    const absoluteIndex = startIndex + idx;
    const id = `M${String(absoluteIndex).padStart(2, '0')}`;
    return {
      id,
      index: absoluteIndex,
      rawText: chunk,
      senderHint: inferSender(chunk),
      channelHint: inferChannel(chunk),
    };
  });
}
