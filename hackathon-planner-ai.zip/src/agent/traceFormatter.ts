import type { TraceEntry, TraceSummary } from './types.ts';

export function computeTokenTotals(entries: TraceEntry[]): TraceSummary {
  return entries.reduce<TraceSummary>(
    (acc, entry) => {
      acc.totalCalls += 1;
      acc.totalPromptTokens += entry.tokens.promptTokens || 0;
      acc.totalCandidatesTokens += entry.tokens.candidatesTokens || 0;
      acc.totalThoughtsTokens += entry.tokens.thoughtsTokens || 0;
      acc.grandTotalTokens += entry.tokens.totalTokens || 0;
      return acc;
    },
    {
      totalCalls: 0,
      totalPromptTokens: 0,
      totalCandidatesTokens: 0,
      totalThoughtsTokens: 0,
      grandTotalTokens: 0,
    }
  );
}

export function formatTraceText(entries: TraceEntry[], summary: TraceSummary): string {
  if (entries.length === 0) {
    return '=== EXECUTION TRACE ===\nNo model calls recorded yet.\n\n=== TRACE TOTALS ===\nTotal Tokens: 0\n';
  }

  const lines: string[] = ['=== EXECUTION TRACE ===', ''];

  for (const entry of entries) {
    const phaseLabel =
      entry.phase === 'update'
        ? `update #${entry.updateBatchIndex ?? 1}`
        : 'initial run';
    lines.push(`--- Model Call #${entry.callNumber} (${phaseLabel}) ---`);
    lines.push(`Model: ${entry.modelName}`);
    lines.push(`Area: ${entry.area}`);
    lines.push(
      `Tokens: prompt=${entry.tokens.promptTokens}, output=${entry.tokens.candidatesTokens}, thinking=${entry.tokens.thoughtsTokens}, total=${entry.tokens.totalTokens}`
    );
    lines.push(`Duration: ${entry.durationMs}ms`);
    if (entry.conflictNotes.length > 0) {
      lines.push('Conflicts / Rejections Noted:');
      for (const note of entry.conflictNotes) {
        lines.push(`  - ${note}`);
      }
    }
    lines.push('Input:');
    lines.push(entry.input.trim());
    lines.push('Output:');
    lines.push(entry.output.trim());
    lines.push('');
  }

  lines.push('=== TRACE TOTALS ===');
  lines.push(`Total Model Calls: ${summary.totalCalls}`);
  lines.push(`Total Prompt Tokens: ${summary.totalPromptTokens}`);
  lines.push(`Total Output Tokens: ${summary.totalCandidatesTokens}`);
  lines.push(`Total Thinking Tokens: ${summary.totalThoughtsTokens}`);
  lines.push(`Total Tokens: ${summary.grandTotalTokens}`);

  return lines.join('\n');
}
