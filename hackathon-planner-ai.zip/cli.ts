import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { runFullPlan, runIncrementalUpdate } from './src/agent/engine.ts';
import { formatTraceText } from './src/agent/traceFormatter.ts';
import type { AgentSessionState } from './src/agent/types.ts';

const STATE_FILE = path.resolve(process.cwd(), '.plan-state.json');

function printSummary(state: AgentSessionState): void {
  const { plan, validation, assessments, trace, traceSummary } = state;

  console.log('\n============================================================');
  console.log('HACKATHON PLAN');
  console.log('============================================================');
  if (plan) {
    console.log(
      `Event: ${plan.parameters.eventName} | ${plan.parameters.city} | ${plan.parameters.targetHours}h | ${plan.parameters.targetStudents} students | ${plan.parameters.targetTeams} teams`
    );
    console.log('\n[1. VENUE]');
    console.log(
      `  ${plan.venue.venueName} (${plan.venue.addressOrSector}) — Seats: ${plan.venue.capacitySeats}/${plan.venue.requiredCapacity} | Window: ${plan.venue.accessWindowStart}–${plan.venue.lockdownCurfew} | Cost: PKR ${plan.venue.venueCostPkr.toLocaleString()}`
    );
    console.log(`  Zones: ${plan.venue.zones.join(', ')}`);

    console.log('\n[2. SCHEDULE]');
    for (const slot of plan.schedule.slots) {
      console.log(`  ${slot.startTime} - ${slot.endTime} (${slot.durationMinutes}m): ${slot.activity} [${slot.zone}]`);
    }

    console.log('\n[3. FOOD]');
    console.log(
      `  Vendor: ${plan.food.vendor} | Covered: ${plan.food.totalHeadcountCovered} (${plan.food.vegetarianBoxes} veg, ${plan.food.standardBoxes} standard) | Allergen: ${plan.food.allergenFreeGuarantee} | Cost: PKR ${plan.food.totalFoodCostPkr.toLocaleString()}`
    );

    console.log('\n[4. JUDGING]');
    console.log(
      `  ${plan.judging.totalTeams} teams across ${plan.judging.parallelPanels} panels (${plan.judging.minutesPerTeam}m/team in ${plan.judging.judgingWindowMinutes}m window) | Judges: ${plan.judging.totalJudges} | Prizes & Honoraria: PKR ${plan.judging.prizesAndHonorariaPkr.toLocaleString()}`
    );
    console.log(`  Math: ${plan.judging.mathVerificationNote}`);

    console.log('\n[5. BUDGET]');
    console.log(
      `  Cap: ${plan.budget.currency} ${plan.budget.hardBudgetCap.toLocaleString()} | Planned: ${plan.budget.currency} ${plan.budget.totalPlannedSpend.toLocaleString()} | Buffer: ${plan.budget.currency} ${plan.budget.remainingBuffer.toLocaleString()}`
    );
    for (const item of plan.budget.lineItems) {
      console.log(`  - [${item.category}] ${item.description}: ${plan.budget.currency} ${item.amountPkr.toLocaleString()} (${item.sourceMessageId})`);
    }
  }

  if (validation) {
    console.log(`\nInvariant Validation: ${validation.valid ? 'VALID' : 'ISSUES FOUND'}`);
    for (const check of validation.checks) {
      console.log(`  [${check.passed ? 'PASS' : 'FAIL'}] ${check.label}: ${check.detail}`);
    }
  }

  console.log('\n============================================================');
  console.log('MESSAGE ASSESSMENTS & REJECTIONS');
  console.log('============================================================');
  for (const m of assessments) {
    console.log(`[${m.messageId}] ${m.status.toUpperCase()} (${m.language} / ${m.channel}) — ${m.sender}`);
    console.log(`  Reason: ${m.reason}`);
  }

  console.log('\n' + formatTraceText(trace, traceSummary));
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0) {
    console.error('Usage:');
    console.error('  npx tsx cli.ts <message-pack.txt>        Run full plan from a text file');
    console.error('  npx tsx cli.ts update <new-msg.txt>      Update existing plan with new message file (<= 5 calls)');
    console.error('  npx tsx cli.ts reset                     Clear saved plan state');
    process.exit(1);
  }

  if (args[0] === 'reset') {
    if (fs.existsSync(STATE_FILE)) fs.unlinkSync(STATE_FILE);
    console.log('Cleared saved plan state.');
    return;
  }

  if (args[0] === 'update') {
    const filePath = args[1];
    if (!filePath) {
      console.error('Provide a path to the new message .txt file.');
      process.exit(1);
    }
    if (!fs.existsSync(STATE_FILE)) {
      console.error('No active plan state found. Run `npx tsx cli.ts <pack.txt>` first.');
      process.exit(1);
    }
    const currentState = JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8')) as AgentSessionState;
    const newText = fs.readFileSync(path.resolve(process.cwd(), filePath), 'utf-8');
    const updated = await runIncrementalUpdate(currentState, newText, 55_000);
    fs.writeFileSync(STATE_FILE, JSON.stringify(updated, null, 2), 'utf-8');
    printSummary(updated);
    return;
  }

  const filePath = path.resolve(process.cwd(), args[0]);
  if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
  }
  const rawPackText = fs.readFileSync(filePath, 'utf-8');
  const state = await runFullPlan(rawPackText, 115_000);
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf-8');
  printSummary(state);
}

main().catch((err) => {
  console.error('Agent error:', err instanceof Error ? err.message : err);
  process.exit(1);
});
