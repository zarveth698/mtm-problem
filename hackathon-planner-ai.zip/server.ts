import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { runFullPlan, runIncrementalUpdate } from './src/agent/engine.ts';
import { formatTraceText } from './src/agent/traceFormatter.ts';
import type { AgentSessionState } from './src/agent/types.ts';

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), '.data');
const SESSION_FILE = path.join(DATA_DIR, 'session-state.json');
const SAMPLE_PACK_FILE = path.resolve(process.cwd(), 'sample-packs', 'islamabad-sample-pack.txt');

let activeSession: AgentSessionState | null = null;

function loadPersistedSession(): AgentSessionState | null {
  try {
    if (fs.existsSync(SESSION_FILE)) {
      const raw = fs.readFileSync(SESSION_FILE, 'utf-8');
      return JSON.parse(raw) as AgentSessionState;
    }
  } catch {
    // Ignore corrupt cache file
  }
  return null;
}

function savePersistedSession(state: AgentSessionState | null): void {
  activeSession = state;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (state === null) {
      if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE);
    } else {
      fs.writeFileSync(SESSION_FILE, JSON.stringify(state, null, 2), 'utf-8');
    }
  } catch {
    // Non-fatal persistence error
  }
}

activeSession = loadPersistedSession();

async function createApp(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '4mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, hasSession: Boolean(activeSession) });
  });

  app.get('/api/sample-pack', (_req, res) => {
    if (!fs.existsSync(SAMPLE_PACK_FILE)) {
      res.status(404).json({ error: 'Sample message pack file not found on disk.' });
      return;
    }
    const content = fs.readFileSync(SAMPLE_PACK_FILE, 'utf-8');
    res.json({ filename: 'islamabad-sample-pack.txt', content });
  });

  app.get('/api/session', (_req, res) => {
    if (!activeSession) {
      res.json({ session: null, formattedTrace: '' });
      return;
    }
    res.json({
      session: activeSession,
      formattedTrace: formatTraceText(activeSession.trace, activeSession.traceSummary),
    });
  });

  app.post('/api/plan/run', async (req, res) => {
    try {
      const { rawText } = req.body as { rawText?: string };
      if (!rawText || typeof rawText !== 'string' || rawText.trim().length === 0) {
        res.status(400).json({ error: 'Message pack text is required.' });
        return;
      }

      const nextSession = await runFullPlan(rawText, 115_000);
      savePersistedSession(nextSession);

      res.json({
        session: nextSession,
        formattedTrace: formatTraceText(nextSession.trace, nextSession.traceSummary),
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to execute planning agent.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/plan/update', async (req, res) => {
    try {
      if (!activeSession || !activeSession.plan) {
        res.status(400).json({ error: 'No active plan exists yet. Run a message pack first.' });
        return;
      }
      const { messageText } = req.body as { messageText?: string };
      if (!messageText || typeof messageText !== 'string' || messageText.trim().length === 0) {
        res.status(400).json({ error: 'New message text is required for an update.' });
        return;
      }

      const updatedSession = await runIncrementalUpdate(activeSession, messageText, 55_000);
      savePersistedSession(updatedSession);

      res.json({
        session: updatedSession,
        formattedTrace: formatTraceText(updatedSession.trace, updatedSession.traceSummary),
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update plan.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/plan/reset', (_req, res) => {
    savePersistedSession(null);
    res.json({ ok: true });
  });

  app.get('/api/trace/download', (_req, res) => {
    if (!activeSession) {
      res.status(404).send('No trace available.');
      return;
    }
    const formatted = formatTraceText(activeSession.trace, activeSession.traceSummary);
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="hackathon-agent-trace.txt"');
    res.send(formatted);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`HackPlan Islamabad server listening on http://localhost:${PORT}`);
  });
}

createApp().catch((err) => {
  console.error('Server failed to start:', err);
  process.exit(1);
});
